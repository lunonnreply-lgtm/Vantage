<?php
$adminFooterScripts = $adminFooterScripts ?? [];
?>
    </main>
    <footer class="admin-footer">
        <span>Vantage Institutional</span>
        <span>Operations Console</span>
    </footer>
</div>
<?php foreach ($adminFooterScripts as $script): ?>
<script src="<?= htmlspecialchars($script, ENT_QUOTES, 'UTF-8') ?>"></script>
<?php endforeach; ?>
<script src="/assets/global/js/visitor-tracker.js" defer></script>
</body>
</html>
