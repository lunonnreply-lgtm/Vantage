<?php
declare(strict_types=1);
$pageTitle = $pageTitle ?? 'Admin';
$pageEyebrow = $pageEyebrow ?? 'Vantage Institutional';
$adminName = trim((string)($adminName ?? 'Administrator'));
?>
<!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta name="robots" content="noindex,nofollow,noarchive">
<title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> · Vantage Institutional</title>
<link rel="icon" type="image/svg+xml" href="/assets/branding/favicon.svg">
<link rel="icon" type="image/png" sizes="48x48" href="/assets/branding/favicon-48.png">
<link rel="icon" type="image/png" sizes="32x32" href="/assets/branding/favicon-32.png">
<link rel="icon" type="image/png" sizes="16x16" href="/assets/branding/favicon-16.png">
<link rel="shortcut icon" href="/assets/branding/favicon.ico">
<link rel="apple-touch-icon" sizes="180x180" href="/assets/branding/apple-touch-icon.png">
<link rel="manifest" href="/assets/branding/site.webmanifest">
<meta name="msapplication-TileImage" content="/assets/branding/mstile-270.png">
<meta name="msapplication-config" content="/browserconfig.xml">
<meta name="msapplication-TileColor" content="#0B1F3A">
<meta name="theme-color" content="#0B1F3A">
<link rel="stylesheet" href="/assets/dashboard.css">
<link rel="stylesheet" href="/admin/admin.css">
<link rel="stylesheet" href="/admin/admin-support.css">
<link rel="stylesheet" href="/admin/admin-management.css">
</head>
<body>
<div class="admin-shell">
<header class="admin-header">
<a class="admin-brand" href="/admin/">Vantage Institutional</a>
<div class="admin-header-center">
<span class="eyebrow"><?= htmlspecialchars($pageEyebrow, ENT_QUOTES, 'UTF-8') ?></span>
<h1><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?></h1>
</div>
<div class="admin-header-actions">
<span class="admin-user"><?= htmlspecialchars($adminName, ENT_QUOTES, 'UTF-8') ?></span>
<button type="button" class="admin-button" id="logout-button">Logout</button>
</div>
</header>
<nav class="admin-nav" aria-label="Admin navigation">
<a href="/admin/">Dashboard</a>
<a href="/admin/deposits/">Deposits</a>
<a href="/admin/withdrawals/">Withdrawals</a>
<a href="/admin/users/">Users</a>
<a href="/admin/support/">Support</a>
<a href="/admin/payments/">Payment Methods</a>
<a href="/admin/plans/">Investment Plans</a>
</nav>
<main class="admin-main">
