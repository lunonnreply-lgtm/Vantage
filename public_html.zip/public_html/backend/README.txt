Vantage Institutional PHP/MySQL backend

Setup on a hosted PHP server:

1. Create an empty MySQL database and user.
2. Select that database in phpMyAdmin or your SQL client, then import backend/schema.sql once.
3. Copy backend/config/config.example.php to backend/config/config.php.
4. Put the real database DSN, username, password, and production origin in config.php.
5. Deploy the project so /api and /share are served by the same HTTPS origin.
6. Keep backend/config/config.php outside public web access when the hosting provider supports a private directory.

The backend supports account registration, login, logout, CSRF tokens, password hashing, and session-based identity. It also provides authenticated dashboard balance/summary and transaction endpoints, plus deposit and withdrawal request endpoints. Requests remain pending and do not alter balances; payment processing and administrator approval must be implemented before production use.

API endpoints:

- GET /api/auth/csrf.php
- POST /api/auth/register.php
- POST /api/auth/login.php
- POST /api/auth/logout.php
- POST /api/auth/forgot-password.php
- POST /api/auth/reset-password.php
- GET /api/user/dashboard.php
- GET /api/user/transactions.php
- POST /api/user/financial-request.php with {"type":"deposit"|"withdrawal","amount":"100.00","notes":"optional"}

backend/schema.sql is the single canonical schema for a fresh installation and includes the current application tables, indexes, and constraints. Do not import it over an existing populated database: CREATE TABLE IF NOT EXISTS does not add missing columns or repair existing definitions. For the checked-in existing database, back it up and run backend/run-on-database-sql-to-add-or-delete-on-existing-db.sql after selecting the correct database. Run the latest version of that alignment file before enabling the updated investment cron; it adds the restricted-profit balance and reserves already-paid profits for active investments. That alignment file replaces the older split migrations for this database; do not run the older migration files along with it.

Visitor analytics use the same mail configuration and active administrator accounts. Set `app.visitor_notification_email` in backend/config/config.php to send visitor alerts to one specific inbox; if it is empty, alerts go to active administrator email addresses. `app.visitor_notification_cooldown_minutes` defaults to 30. Back up the database and rerun the current alignment SQL to create the visitor tables before using the feature. Visit records include IP and browser information; restrict admin access and retain these records according to your privacy policy.

Admin:

- Admin access starts at /share/login/. The /admin/login.html route now directs administrators to the shared account login.
- Admin console: /admin/
- Create the first administrator by registering the account normally, then manually promote that account in the selected database with `UPDATE users SET role = 'admin' WHERE email = 'your-admin-email';`.
- After first login, configure investment plans, deposit payment methods, and withdrawal settings in the admin console. The fresh schema intentionally contains no placeholder payment addresses or sample financial terms.
- Never add public admin registration.
- Review requests carefully; approval changes the user's balance and creates a completed ledger entry inside a database transaction.
- All users now use /share/login/. Active administrators see an Admin console link in the user dashboard after signing in.
- Password reset uses PHPMailer over SMTP. Run `composer install` and configure the SMTP values in backend/config/config.php. The password_reset_tokens table is created by schema.sql.
- User dashboard pages are protected PHP routes. Configure the server to execute PHP and do not publish the original captured HTML files.
- Apache clean URLs are configured in the project-root .htaccess. Enable mod_rewrite and allow .htaccess overrides (AllowOverride All) on the hosted domain.
- Public pages use folder URLs such as /about-us/ and /contact/; direct index.html and page.html requests redirect to their clean folder URLs.
- Investment plans and investment records are database-backed at /portal/investments/ and /portal/investments/logs/. The selected main wallet is debited when an investment is confirmed, and the expected return is recorded in the investment log.
- Configure a Hostinger cron job to run `php /home/ACCOUNT/domains/DOMAIN/public_html/cron/release-investments.php` at least hourly. Daily profits from active investments are reserved in the profit wallet and cannot be exchanged into the main wallet; the reserve and any returned principal become available when the investment matures. Matured payouts are recorded once in the unified ledger as `investment_release`.
