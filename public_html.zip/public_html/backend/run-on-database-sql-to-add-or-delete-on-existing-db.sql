-- Data-preserving alignment for databases created before backend/schema.sql
-- was consolidated. Select the existing application database before running.
-- This script is safe to re-run. It intentionally does not drop tables,
-- columns, indexes, or application records.

SET @database_name = DATABASE();
SELECT @database_name AS selected_database;

-- Transfers created before this field existed receive a zero fee.
SET @has_transfer_fee = (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'transfers'
    AND COLUMN_NAME = 'fee'
);
SET @sql = IF(
  @has_transfer_fee = 0,
  'ALTER TABLE transfers ADD COLUMN fee DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER amount',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Ensure each existing user has the profit wallet required by investments.
INSERT INTO accounts (user_id, currency, wallet_type)
SELECT u.id, 'USD', 'profit'
FROM users AS u
LEFT JOIN accounts AS a
  ON a.user_id = u.id
 AND a.currency = 'USD'
 AND a.wallet_type = 'profit'
WHERE a.id IS NULL;

-- Add a reserve balance so active-investment profits cannot be spent early.
SET @has_restricted_balance = (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'accounts'
    AND COLUMN_NAME = 'restricted_balance'
);
SET @sql = IF(
  @has_restricted_balance = 0,
  'ALTER TABLE accounts ADD COLUMN restricted_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00 AFTER available_balance',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Reserve already-paid profits for investments that are still active.
UPDATE accounts AS a
LEFT JOIN (
  SELECT
    i.profit_account_id AS account_id,
    ROUND(SUM(p.profit_amount), 2) AS restricted_total
  FROM investments AS i
  INNER JOIN investment_daily_payouts AS p ON p.investment_id = i.id
  WHERE i.status = 'active'
  GROUP BY i.profit_account_id
) AS active_profits ON active_profits.account_id = a.id
SET a.restricted_balance = COALESCE(active_profits.restricted_total, 0.00)
WHERE a.wallet_type = 'profit';

-- Ensure the default rank exists before tightening users.rank_id.
INSERT IGNORE INTO ranks (id, name, level, description)
VALUES (1, 'Vantage Institutional Member', 1, 'Default member rank');

UPDATE users AS u
LEFT JOIN ranks AS r ON r.id = u.rank_id
SET u.rank_id = 1
WHERE r.id IS NULL;

SET @rank_is_nullable = (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'users'
    AND COLUMN_NAME = 'rank_id'
    AND IS_NULLABLE = 'YES'
);
SET @sql = IF(
  @rank_is_nullable > 0,
  'ALTER TABLE users MODIFY COLUMN rank_id INT UNSIGNED NOT NULL DEFAULT 1',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

SET @has_users_rank_fk = (
  SELECT COUNT(*)
  FROM information_schema.TABLE_CONSTRAINTS
  WHERE CONSTRAINT_SCHEMA = @database_name
    AND TABLE_NAME = 'users'
    AND CONSTRAINT_NAME = 'users_rank_fk'
    AND CONSTRAINT_TYPE = 'FOREIGN KEY'
);
SET @sql = IF(
  @has_users_rank_fk = 0,
  'ALTER TABLE users ADD CONSTRAINT users_rank_fk FOREIGN KEY (rank_id) REFERENCES ranks (id) ON DELETE RESTRICT',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Add the ticket reference column only if an older database lacks it.
SET @has_ticket_reference = (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'support_tickets'
    AND COLUMN_NAME = 'reference'
);
SET @sql = IF(
  @has_ticket_reference = 0,
  'ALTER TABLE support_tickets ADD COLUMN reference VARCHAR(30) NULL AFTER id',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Keep one existing reference when duplicates exist; assign fresh references
-- to blank rows and later duplicate rows before making the column unique.
UPDATE support_tickets AS ticket
LEFT JOIN support_tickets AS earlier
  ON earlier.reference = ticket.reference
 AND earlier.id < ticket.id
SET ticket.reference = CONCAT(
  'LEGACY-',
  LPAD(ticket.id, 20, '0')
)
WHERE ticket.reference IS NULL
   OR TRIM(ticket.reference) = ''
   OR earlier.id IS NOT NULL;

SET @ticket_reference_is_nullable = (
  SELECT COUNT(*)
  FROM information_schema.COLUMNS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'support_tickets'
    AND COLUMN_NAME = 'reference'
    AND IS_NULLABLE = 'YES'
);
SET @sql = IF(
  @ticket_reference_is_nullable > 0,
  'ALTER TABLE support_tickets MODIFY COLUMN reference VARCHAR(30) NOT NULL',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

SET @has_ticket_reference_unique = (
  SELECT COUNT(*)
  FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @database_name
    AND TABLE_NAME = 'support_tickets'
    AND INDEX_NAME = 'support_tickets_reference_unique'
);
SET @sql = IF(
  @has_ticket_reference_unique = 0,
  'ALTER TABLE support_tickets ADD UNIQUE KEY support_tickets_reference_unique (reference)',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Repair legacy withdrawals that stored a destination ID in payment_method_id.
UPDATE financial_requests AS fr
INNER JOIN withdrawal_accounts AS wa ON wa.id = fr.payment_method_id
SET fr.withdrawal_account_id = wa.id
WHERE fr.type = 'withdrawal'
  AND fr.withdrawal_account_id IS NULL;

-- Ensure the FULLTEXT indexes used by admin search exist.
SET @has_users_search = (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @database_name AND TABLE_NAME = 'users'
    AND INDEX_NAME = 'ft_users_admin_search'
);
SET @sql = IF(
  @has_users_search = 0,
  'ALTER TABLE users ADD FULLTEXT KEY ft_users_admin_search (first_name, last_name, username, email, country)',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

SET @has_financial_requests_search = (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @database_name AND TABLE_NAME = 'financial_requests'
    AND INDEX_NAME = 'ft_financial_requests_admin_search'
);
SET @sql = IF(
  @has_financial_requests_search = 0,
  'ALTER TABLE financial_requests ADD FULLTEXT KEY ft_financial_requests_admin_search (reference, gateway, notes)',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

SET @has_support_tickets_search = (
  SELECT COUNT(*) FROM information_schema.STATISTICS
  WHERE TABLE_SCHEMA = @database_name AND TABLE_NAME = 'support_tickets'
    AND INDEX_NAME = 'ft_support_tickets_admin_search'
);
SET @sql = IF(
  @has_support_tickets_search = 0,
  'ALTER TABLE support_tickets ADD FULLTEXT KEY ft_support_tickets_admin_search (reference, subject, category)',
  'SELECT 1'
);
PREPARE migration_statement FROM @sql;
EXECUTE migration_statement;
DEALLOCATE PREPARE migration_statement;

-- Visitor analytics and notification history.
CREATE TABLE IF NOT EXISTS site_visitors (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  first_seen_at DATETIME NOT NULL,
  last_seen_at DATETIME NOT NULL,
  last_notification_at DATETIME NULL,
  visit_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  latest_ip_address VARCHAR(45) NULL,
  latest_device VARCHAR(60) NULL,
  latest_browser VARCHAR(100) NULL,
  latest_operating_system VARCHAR(100) NULL,
  latest_page_path TEXT NULL,
  latest_referrer TEXT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY site_visitors_key_unique (visitor_key),
  KEY site_visitors_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visitor_visits (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_id BIGINT UNSIGNED NOT NULL,
  ip_address VARCHAR(45) NULL,
  device VARCHAR(60) NOT NULL,
  browser VARCHAR(100) NOT NULL,
  operating_system VARCHAR(100) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  page_path TEXT NOT NULL,
  referrer TEXT NULL,
  visitor_status ENUM('new', 'returning') NOT NULL,
  visited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY site_visitor_visits_recent (visited_at),
  KEY site_visitor_visits_visitor_recent (visitor_id, visited_at),
  CONSTRAINT site_visitor_visits_visitor_fk FOREIGN KEY (visitor_id) REFERENCES site_visitors (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visitor_notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_id BIGINT UNSIGNED NOT NULL,
  visit_id BIGINT UNSIGNED NOT NULL,
  recipient_email VARCHAR(255) NULL,
  status ENUM('queued', 'sent', 'failed', 'no_recipient') NOT NULL,
  error_message TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY site_visitor_notifications_recent (created_at),
  KEY site_visitor_notifications_status_recent (status, created_at),
  CONSTRAINT site_visitor_notifications_visitor_fk FOREIGN KEY (visitor_id) REFERENCES site_visitors (id) ON DELETE CASCADE,
  CONSTRAINT site_visitor_notifications_visit_fk FOREIGN KEY (visit_id) REFERENCES site_visitor_visits (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SELECT 'Schema alignment complete. Existing rows and tables were preserved.' AS result;