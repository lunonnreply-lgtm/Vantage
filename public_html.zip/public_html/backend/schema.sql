-- Vantage Institutional application schema
-- Select the target database in your SQL client before importing this file.
-- This is a fresh-install schema; do not import it over a populated database.

SET NAMES utf8mb4;

CREATE TABLE IF NOT EXISTS ranks (
  id INT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(100) NOT NULL,
  level INT UNSIGNED NOT NULL,
  description VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY ranks_level_unique (level)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT IGNORE INTO ranks (id, name, level, description)
VALUES (1, 'Vantage Institutional Member', 1, 'Default member rank');

CREATE TABLE IF NOT EXISTS users (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(255) NOT NULL,
  username VARCHAR(50) NOT NULL,
  country VARCHAR(100) NOT NULL,
  password_hash VARCHAR(255) NOT NULL,
  gender ENUM('male', 'female', 'other') NULL,
  date_of_birth DATE NULL,
  phone VARCHAR(30) NULL,
  city VARCHAR(100) NULL,
  zip_code VARCHAR(30) NULL,
  address VARCHAR(255) NULL,
  photo VARCHAR(500) NULL,
  role ENUM('user', 'admin') NOT NULL DEFAULT 'user',
  rank_id INT UNSIGNED NOT NULL DEFAULT 1,
  referral_code VARCHAR(32) NULL,
  status ENUM('active', 'suspended') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY users_email_unique (email),
  UNIQUE KEY users_username_unique (username),
  UNIQUE KEY users_referral_code_unique (referral_code),
  KEY users_status (status),
  KEY users_role_status (role, status),
  KEY users_created (created_at, id),
  FULLTEXT KEY ft_users_admin_search (first_name, last_name, username, email, country),
  CONSTRAINT users_rank_fk FOREIGN KEY (rank_id) REFERENCES ranks (id) ON DELETE RESTRICT
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS referrals (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  referrer_user_id BIGINT UNSIGNED NOT NULL,
  referred_user_id BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY referrals_unique (referrer_user_id, referred_user_id),
  KEY referrals_referred_user (referred_user_id),
  CONSTRAINT referrals_referrer_fk FOREIGN KEY (referrer_user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT referrals_referred_fk FOREIGN KEY (referred_user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS password_reset_tokens (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  token_hash CHAR(64) NOT NULL,
  expires_at DATETIME NOT NULL,
  used_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY password_reset_token_hash_unique (token_hash),
  KEY password_reset_user_expiry (user_id, expires_at),
  CONSTRAINT password_reset_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS accounts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  wallet_type ENUM('main', 'profit') NOT NULL DEFAULT 'main',
  available_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  restricted_balance DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY accounts_user_currency_wallet_unique (user_id, currency, wallet_type),
  KEY accounts_user_id (user_id),
  CONSTRAINT accounts_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS payment_methods (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  code VARCHAR(60) NOT NULL,
  name VARCHAR(120) NOT NULL,
  wallet_address VARCHAR(500) NULL,
  qr_code LONGTEXT NULL,
  charge DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
  charge_type ENUM('fixed', 'percentage') NOT NULL DEFAULT 'fixed',
  minimum_deposit DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  maximum_deposit DECIMAL(14,2) NOT NULL DEFAULT 999999.99,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY payment_methods_code_unique (code),
  KEY payment_methods_status (status),
  KEY payment_methods_name (name, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS withdrawal_settings (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  method VARCHAR(120) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  minimum_amount DECIMAL(14,2) NOT NULL,
  maximum_amount DECIMAL(14,2) NOT NULL,
  fee_type ENUM('fixed', 'percentage') NOT NULL DEFAULT 'fixed',
  fee DECIMAL(10,4) NOT NULL DEFAULT 0.0000,
  processing_time VARCHAR(120) NOT NULL,
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY withdrawal_settings_method_currency_unique (method, currency),
  KEY withdrawal_settings_status (status)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS withdrawal_accounts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  method VARCHAR(120) NOT NULL,
  account_name VARCHAR(150) NOT NULL,
  account_number VARCHAR(150) NULL,
  bank_name VARCHAR(150) NULL,
  bank_code VARCHAR(50) NULL,
  wallet_address VARCHAR(255) NULL,
  network VARCHAR(60) NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY withdrawal_accounts_user_status (user_id, status),
  CONSTRAINT withdrawal_accounts_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investment_plans (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  name VARCHAR(120) NOT NULL,
  description VARCHAR(500) NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  minimum_amount DECIMAL(14,2) NOT NULL,
  maximum_amount DECIMAL(14,2) NULL,
  return_rate DECIMAL(8,4) NOT NULL,
  term_days INT UNSIGNED NOT NULL,
  cancel_minutes INT UNSIGNED NOT NULL DEFAULT 60,
  capital_back TINYINT(1) NOT NULL DEFAULT 1,
  status ENUM('active', 'inactive') NOT NULL DEFAULT 'active',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY investment_plans_name_unique (name),
  KEY investment_plans_status (status),
  KEY investment_plans_created (created_at, id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS financial_requests (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  type ENUM('deposit', 'withdrawal') NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  fee DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  gateway VARCHAR(120) NULL,
  payment_method_id BIGINT UNSIGNED NULL,
  withdrawal_account_id BIGINT UNSIGNED NULL,
  status ENUM('pending', 'approved', 'rejected', 'cancelled') NOT NULL DEFAULT 'pending',
  reference VARCHAR(32) NOT NULL,
  notes VARCHAR(500) NULL,
  screenshot_path VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY financial_requests_reference_unique (reference),
  KEY financial_requests_user_created (user_id, created_at),
  KEY financial_requests_status (status),
  KEY financial_requests_type_created (type, created_at, id),
  KEY financial_requests_type_status_created (type, status, created_at, id),
  KEY financial_requests_type_reference (type, reference, id),
  KEY financial_requests_payment_method (payment_method_id),
  KEY financial_requests_withdrawal_account (withdrawal_account_id),
  FULLTEXT KEY ft_financial_requests_admin_search (reference, gateway, notes),
  CONSTRAINT financial_requests_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT financial_requests_account_fk FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE CASCADE,
  CONSTRAINT financial_requests_payment_method_fk FOREIGN KEY (payment_method_id) REFERENCES payment_methods (id) ON DELETE SET NULL,
  CONSTRAINT financial_requests_withdrawal_account_fk FOREIGN KEY (withdrawal_account_id) REFERENCES withdrawal_accounts (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  plan_id BIGINT UNSIGNED NOT NULL,
  source_account_id BIGINT UNSIGNED NOT NULL,
  profit_account_id BIGINT UNSIGNED NOT NULL,
  principal DECIMAL(14,2) NOT NULL,
  expected_return DECIMAL(14,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  starts_at DATETIME NOT NULL,
  matures_at DATETIME NOT NULL,
  status ENUM('active', 'released', 'cancelled') NOT NULL DEFAULT 'active',
  reference VARCHAR(32) NOT NULL,
  released_at DATETIME NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY investments_reference_unique (reference),
  KEY investments_user_status (user_id, status),
  KEY investments_maturity (status, matures_at),
  CONSTRAINT investments_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT investments_plan_fk FOREIGN KEY (plan_id) REFERENCES investment_plans (id),
  CONSTRAINT investments_source_account_fk FOREIGN KEY (source_account_id) REFERENCES accounts (id),
  CONSTRAINT investments_profit_account_fk FOREIGN KEY (profit_account_id) REFERENCES accounts (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS investment_daily_payouts (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  investment_id BIGINT UNSIGNED NOT NULL,
  period_number INT UNSIGNED NOT NULL,
  profit_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  principal_amount DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY investment_daily_payout_period_unique (investment_id, period_number),
  KEY investment_daily_payout_created (created_at),
  CONSTRAINT investment_daily_payout_investment_fk FOREIGN KEY (investment_id) REFERENCES investments (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS ledger_transactions (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  account_id BIGINT UNSIGNED NOT NULL,
  type VARCHAR(40) NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  status ENUM('pending', 'completed', 'failed') NOT NULL DEFAULT 'pending',
  description VARCHAR(255) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY ledger_transactions_user_created (user_id, created_at),
  KEY ledger_transactions_type (type),
  CONSTRAINT ledger_transactions_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT ledger_transactions_account_fk FOREIGN KEY (account_id) REFERENCES accounts (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS transfers (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  sender_user_id BIGINT UNSIGNED NOT NULL,
  recipient_user_id BIGINT UNSIGNED NOT NULL,
  sender_account_id BIGINT UNSIGNED NOT NULL,
  recipient_account_id BIGINT UNSIGNED NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  fee DECIMAL(14,2) NOT NULL DEFAULT 0.00,
  currency CHAR(3) NOT NULL DEFAULT 'USD',
  status ENUM('completed', 'failed') NOT NULL DEFAULT 'completed',
  reference VARCHAR(32) NOT NULL,
  note VARCHAR(500) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY transfers_reference_unique (reference),
  KEY transfers_sender_created (sender_user_id, created_at),
  KEY transfers_recipient_created (recipient_user_id, created_at),
  KEY transfers_sender_account (sender_account_id),
  KEY transfers_recipient_account (recipient_account_id),
  CONSTRAINT transfers_sender_user_fk FOREIGN KEY (sender_user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT transfers_recipient_user_fk FOREIGN KEY (recipient_user_id) REFERENCES users (id) ON DELETE CASCADE,
  CONSTRAINT transfers_sender_account_fk FOREIGN KEY (sender_account_id) REFERENCES accounts (id) ON DELETE CASCADE,
  CONSTRAINT transfers_recipient_account_fk FOREIGN KEY (recipient_account_id) REFERENCES accounts (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_tickets (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  reference VARCHAR(30) NOT NULL,
  user_id BIGINT UNSIGNED NOT NULL,
  subject VARCHAR(180) NOT NULL,
  category VARCHAR(60) NOT NULL DEFAULT 'general',
  status ENUM('open', 'in_progress', 'resolved', 'closed') NOT NULL DEFAULT 'open',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  UNIQUE KEY support_tickets_reference_unique (reference),
  KEY support_tickets_user_updated (user_id, updated_at),
  KEY support_tickets_status_updated (status, updated_at, id),
  FULLTEXT KEY ft_support_tickets_admin_search (reference, subject, category),
  CONSTRAINT support_tickets_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_ticket_messages (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id BIGINT UNSIGNED NOT NULL,
  author_user_id BIGINT UNSIGNED NOT NULL,
  message TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY support_messages_ticket_created (ticket_id, created_at, id),
  KEY support_messages_author (author_user_id),
  CONSTRAINT support_messages_ticket_fk FOREIGN KEY (ticket_id) REFERENCES support_tickets (id) ON DELETE CASCADE,
  CONSTRAINT support_messages_author_fk FOREIGN KEY (author_user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS support_ticket_attachments (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  ticket_id BIGINT UNSIGNED NOT NULL,
  message_id BIGINT UNSIGNED NOT NULL,
  uploaded_by_user_id BIGINT UNSIGNED NOT NULL,
  original_name VARCHAR(255) NOT NULL,
  stored_name VARCHAR(255) NOT NULL,
  file_path VARCHAR(500) NOT NULL,
  mime_type VARCHAR(100) NOT NULL,
  file_size BIGINT UNSIGNED NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY support_attachments_ticket (ticket_id),
  KEY support_attachments_message (message_id),
  KEY support_attachments_uploader (uploaded_by_user_id),
  CONSTRAINT support_attachments_ticket_fk FOREIGN KEY (ticket_id) REFERENCES support_tickets (id) ON DELETE CASCADE,
  CONSTRAINT support_attachments_message_fk FOREIGN KEY (message_id) REFERENCES support_ticket_messages (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS bonuses (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  user_id BIGINT UNSIGNED NOT NULL,
  type ENUM('referral', 'deposit', 'investment') NOT NULL,
  amount DECIMAL(14,2) NOT NULL,
  status ENUM('pending', 'credited', 'rejected') NOT NULL DEFAULT 'pending',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY bonuses_user_status (user_id, status),
  CONSTRAINT bonuses_user_fk FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visitors (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_key CHAR(64) CHARACTER SET ascii COLLATE ascii_bin NOT NULL,
  first_seen_at DATETIME NOT NULL,
  last_seen_at DATETIME NOT NULL,
  last_notification_at DATETIME NULL,
  visit_count BIGINT UNSIGNED NOT NULL DEFAULT 0,
  latest_ip_address VARCHAR(45) NULL,
  latest_device VARCHAR(60) NULL,
  latest_browser VARCHAR(100) NULL,
  latest_operating_system VARCHAR(100) NULL,
  latest_page_path TEXT NULL,
  latest_referrer TEXT NULL,
  PRIMARY KEY (id),
  UNIQUE KEY site_visitors_key_unique (visitor_key),
  KEY site_visitors_last_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visitor_visits (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_id BIGINT UNSIGNED NOT NULL,
  ip_address VARCHAR(45) NULL,
  device VARCHAR(60) NOT NULL,
  browser VARCHAR(100) NOT NULL,
  operating_system VARCHAR(100) NOT NULL,
  user_agent VARCHAR(512) NOT NULL,
  page_path TEXT NOT NULL,
  referrer TEXT NULL,
  visitor_status ENUM('new', 'returning') NOT NULL,
  visited_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (id),
  KEY site_visitor_visits_recent (visited_at),
  KEY site_visitor_visits_visitor_recent (visitor_id, visited_at),
  CONSTRAINT site_visitor_visits_visitor_fk FOREIGN KEY (visitor_id) REFERENCES site_visitors (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE IF NOT EXISTS site_visitor_notifications (
  id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
  visitor_id BIGINT UNSIGNED NOT NULL,
  visit_id BIGINT UNSIGNED NOT NULL,
  recipient_email VARCHAR(255) NULL,
  status ENUM('queued', 'sent', 'failed', 'no_recipient') NOT NULL,
  error_message TEXT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  completed_at DATETIME NULL,
  PRIMARY KEY (id),
  KEY site_visitor_notifications_recent (created_at),
  KEY site_visitor_notifications_status_recent (status, created_at),
  CONSTRAINT site_visitor_notifications_visitor_fk FOREIGN KEY (visitor_id) REFERENCES site_visitors (id) ON DELETE CASCADE,
  CONSTRAINT site_visitor_notifications_visit_fk FOREIGN KEY (visit_id) REFERENCES site_visitor_visits (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;