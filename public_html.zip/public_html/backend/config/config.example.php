<?php

declare(strict_types=1);

return [
    'db' => [
        'dsn' => 'mysql:host=localhost;dbname=your_database_name;charset=utf8mb4',
        'username' => 'your_database_user',
        'password' => 'replace_with_database_password',
    ],
    'app' => [
        'session_name' => 'vantageinstitutional_session',
        'allowed_origin' => 'https://vantageinstitutional.pro',
        'base_url' => 'https://vantageinstitutional.pro',
        'mail_from' => 'no-reply@vantageinstitutional.pro',
        'mail_from_name' => 'Vantage Institutional',
        'reset_url_path' => '/share/reset-password/',
        'visitor_notification_email' => '',
        'visitor_notification_cooldown_minutes' => 30,
    ],
    'smtp' => [
        'host' => 'smtp.example.com',
        'port' => 587,
        'username' => 'smtp-user@example.com',
        'password' => 'replace_with_smtp_password',
        'encryption' => 'tls',
    ],
];
