<?php

declare(strict_types=1);

return [
    'db' => [
        'dsn' => 'mysql:host=localhost;dbname=u273486254_Vantageins;charset=utf8mb4',
        'username' => 'u273486254_Vantagein',
        'password' => 'A123456llllll@',
    ],
    'app' => [
        'session_name' => 'vantageinstitutional_session',
        'allowed_origin' => 'https://vantageinstitutional.com',
        'base_url' => 'https://vantageinstitutional.com',

        'mail_from' => 'no-reply@meredianexchange.com',


        'mail_from_name' => 'Vantage Institutional',
        'reset_url_path' => '/share/reset-password/',
        'visitor_notification_email' => 'rexxwurld@gmail.com',
        'visitor_notification_cooldown_minutes' => 30,
    ],
    'smtp' => [
        'host' => 'smtp.hostinger.com',
        'port' => 587,
        'username' => 'no-reply@meredianexchange.com',
        'password' => 'A123456llllll@',
        'encryption' => 'tls',
    ],
];
