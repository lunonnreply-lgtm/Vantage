<?php

declare(strict_types=1);

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception as MailException;

$autoload = __DIR__ . '/../../vendor/autoload.php';
if (!is_file($autoload)) {
    throw new RuntimeException('Composer dependencies are missing. Run composer install.');
}
require_once $autoload;

function send_password_reset_email(array $config, string $recipient, string $recipientName, string $resetUrl): void
{
    $mail = new PHPMailer(true);
    try {
        $mail->isSMTP();
        $mail->Host = $config['smtp']['host'];
        $mail->SMTPAuth = true;
        $mail->Username = $config['smtp']['username'];
        $mail->Password = $config['smtp']['password'];
        $mail->Port = (int) $config['smtp']['port'];
        $mail->SMTPSecure = $config['smtp']['encryption'];
        $mail->setFrom($config['app']['mail_from'], $config['app']['mail_from_name']);
        $mail->addAddress($recipient, $recipientName);
        $mail->isHTML(true);
        $mail->Subject = 'Reset your Vantage Institutional password';
        $mail->Body = '<p>Hello ' . htmlspecialchars($recipientName, ENT_QUOTES, 'UTF-8') . ',</p><p>Use the button below to reset your password. This link expires in 60 minutes.</p><p><a href="' . htmlspecialchars($resetUrl, ENT_QUOTES, 'UTF-8') . '">Reset password</a></p><p>If you did not request this, you can ignore this email.</p>';
        $mail->AltBody = "Reset your password: {$resetUrl}\nThis link expires in 60 minutes.";
        $mail->send();
    } catch (MailException $exception) {
        throw new RuntimeException('Password reset email could not be sent.', 0, $exception);
    }
}

function send_notification_email(
    array $config,
    string $recipient,
    string $recipientName,
    string $subject,
    string $message,
    array $details = []
): void {
    $mail = new PHPMailer(true);
    $safeName = htmlspecialchars($recipientName, ENT_QUOTES, 'UTF-8');
    $safeMessage = htmlspecialchars($message, ENT_QUOTES, 'UTF-8');
    $rows = '';
    $plainDetails = [];

    foreach ($details as $label => $value) {
        $safeLabel = htmlspecialchars((string)$label, ENT_QUOTES, 'UTF-8');
        $safeValue = htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
        $rows .= '<tr><th style="padding:8px 12px;text-align:left;border-bottom:1px solid #e5e9ef">'
            . $safeLabel . '</th><td style="padding:8px 12px;border-bottom:1px solid #e5e9ef">'
            . $safeValue . '</td></tr>';
        $plainDetails[] = (string)$label . ': ' . (string)$value;
    }

    $mail->isSMTP();
    $mail->Host = $config['smtp']['host'];
    $mail->SMTPAuth = true;
    $mail->Username = $config['smtp']['username'];
    $mail->Password = $config['smtp']['password'];
    $mail->Port = (int)$config['smtp']['port'];
    $mail->SMTPSecure = $config['smtp']['encryption'];
    $mail->setFrom($config['app']['mail_from'], $config['app']['mail_from_name']);
    $mail->addAddress($recipient, $recipientName);
    $mail->isHTML(true);
    $mail->Subject = $subject;
    $mail->Body = '<div style="max-width:600px;margin:0 auto;font:15px/1.6 Arial,sans-serif;color:#243247">'
        . '<h2 style="color:#003049">Vantage Institutional</h2>'
        . '<p>Hello ' . $safeName . ',</p><p>' . $safeMessage . '</p>'
        . ($rows !== '' ? '<table style="width:100%;border-collapse:collapse">' . $rows . '</table>' : '')
        . '<p style="margin-top:24px;color:#64748b">This is an automated notification. Please do not reply to this email.</p></div>';
    $mail->AltBody = 'Hello ' . $recipientName . ",\n\n" . $message
        . ($plainDetails ? "\n\n" . implode("\n", $plainDetails) : '')
        . "\n\nThis is an automated notification. Please do not reply to this email.";
    $mail->send();
}
