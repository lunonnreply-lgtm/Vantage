<?php

declare(strict_types=1);

require_once __DIR__ . '/mailer.php';

function send_email_best_effort(
    array $config,
    string $recipient,
    string $recipientName,
    string $subject,
    string $message,
    array $details = []
): void {
    if (!filter_var($recipient, FILTER_VALIDATE_EMAIL)) {
        return;
    }

    try {
        send_notification_email(
            $config,
            $recipient,
            $recipientName,
            $subject,
            $message,
            $details
        );
    } catch (Throwable $exception) {
        error_log('[email-notification] ' . $exception->getMessage());
    }
}

function notify_user_of_event(
    PDO $pdo,
    array $config,
    int $userId,
    string $subject,
    string $message,
    array $details = []
): void {
    try {
        $query = $pdo->prepare(
            'SELECT first_name, last_name, email FROM users WHERE id = :id LIMIT 1'
        );
        $query->execute(['id' => $userId]);
        $user = $query->fetch();
        if (!$user) {
            return;
        }

        $name = trim((string)$user['first_name'] . ' ' . (string)$user['last_name']);
        send_email_best_effort(
            $config,
            (string)$user['email'],
            $name !== '' ? $name : 'Vantage Institutional member',
            $subject,
            $message,
            $details
        );
    } catch (Throwable $exception) {
        error_log('[email-notification] Could not load user recipient: ' . $exception->getMessage());
    }
}

function notify_admins_of_event(
    PDO $pdo,
    array $config,
    int $userId,
    string $subject,
    string $message,
    array $details = []
): void {
    try {
        $userQuery = $pdo->prepare(
            'SELECT first_name, last_name, email FROM users WHERE id = :id LIMIT 1'
        );
        $userQuery->execute(['id' => $userId]);
        $user = $userQuery->fetch();
        if (!$user) {
            return;
        }

        $userName = trim((string)$user['first_name'] . ' ' . (string)$user['last_name']);
        $adminQuery = $pdo->query(
            "SELECT first_name, last_name, email
             FROM users
             WHERE role = 'admin' AND status = 'active'
             ORDER BY id"
        );

        $adminDetails = [
            'User' => $userName !== '' ? $userName : 'Vantage Institutional member',
            'User email' => (string)$user['email'],
        ] + $details;

        foreach ($adminQuery->fetchAll() as $admin) {
            $adminName = trim((string)$admin['first_name'] . ' ' . (string)$admin['last_name']);
            send_email_best_effort(
                $config,
                (string)$admin['email'],
                $adminName !== '' ? $adminName : 'Administrator',
                $subject,
                $message,
                $adminDetails
            );
        }
    } catch (Throwable $exception) {
        error_log('[email-notification] Could not notify administrators: ' . $exception->getMessage());
    }
}