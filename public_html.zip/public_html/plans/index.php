<?php
require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();
$userId = (int)($_SESSION['user_id'] ?? 0);
$adminQuery = $pdo->prepare('SELECT first_name,last_name,email FROM users WHERE id=:id LIMIT 1');
$adminQuery->execute(['id'=>$userId]);
$admin = $adminQuery->fetch() ?: [];
$adminName = trim((string)($admin['first_name'] ?? '').' '.(string)($admin['last_name'] ?? '')) ?: 'Administrator';

$pageTitle='Investment Plans'; $pageEyebrow='Investment Configuration'; $adminFooterScripts=[];
require __DIR__.'/../../includes/header.php';
?>
<div class="management-grid"><section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Configuration</span><h2>Add / edit investment plan</h2><p>Manage the plans displayed to clients.</p></div></div><form id="form" class="management-form"><input type="hidden" id="id"><div class="field"><label>Name</label><input id="name" required maxlength="120"></div><div class="field"><label>Minimum amount</label><input id="min_amount" type="number" step="0.01" min="0" required></div><div class="field"><label>Maximum amount</label><input id="max_amount" type="number" step="0.01" min="0"></div><div class="field"><label>Return rate (%)</label><input id="return_rate" type="number" step="0.01" min="0"></div><div class="field"><label>Duration (days)</label><input id="duration_days" type="number" min="1"></div><div class="field"><label>Active</label><select id="active"><option value="1">Yes</option><option value="0">No</option></select></div><div class="field full"><label>Description</label><textarea id="description"></textarea></div><div class="management-actions full"><button class="admin-button" type="submit">Save plan</button><button class="admin-button secondary" type="button" onclick="resetForm()">Clear</button></div></form></section>
<section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Available plans</span><h2>Investment plans</h2></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>Name</th><th>Min</th><th>Max</th><th>Return</th><th>Duration</th><th>Active</th><th>Action</th></tr></thead><tbody id="rows"></tbody></table></div></section></div>
<script>
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function csrf(){const r=await fetch('/api/auth/csrf',{credentials:'same-origin'});const d=await r.json();return d.token||d.csrfToken||''}
async function load(){const r=await fetch('/api/admin/investment-plans.php',{credentials:'same-origin'});const d=await r.json();if(!r.ok)throw Error(d.error||'Failed');$('rows').innerHTML=(d.items||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.min_amount)}</td><td>${esc(x.max_amount)}</td><td>${esc(x.return_rate)}%</td><td>${esc(x.duration_days)} days</td><td>${x.active?'Yes':'No'}</td><td><button class="admin-button secondary" onclick='edit(${JSON.stringify(x)})'>Edit</button> <button class="admin-button danger-button" onclick="del(${x.id})">Delete</button></td></tr>`).join('')||'<tr><td colspan="7">No plans.</td></tr>'}
function edit(x){['id','name','min_amount','max_amount','return_rate','duration_days','description','active'].forEach(k=>$(k).value=x[k]??'');scrollTo(0,0)}
function resetForm(){$('form').reset();$('id').value='';$('active').value='1'}
$('form').onsubmit=async e=>{e.preventDefault();const body={id:$('id').value||null,name:$('name').value,min_amount:$('min_amount').value,max_amount:$('max_amount').value,return_rate:$('return_rate').value,duration_days:$('duration_days').value,description:$('description').value,active:$('active').value};const r=await fetch('/api/admin/investment-plans.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)return alert(d.error||'Save failed');resetForm();load()}
async function del(id){if(!confirm('Delete this plan? If existing investments reference it, deletion may be refused.'))return;const r=await fetch('/api/admin/investment-plans.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify({delete:id})});const d=await r.json();if(!r.ok)alert(d.error||'Delete failed');load()} load();
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
