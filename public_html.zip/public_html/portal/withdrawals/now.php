<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_once __DIR__ . '/../../backend/src/notifications.php';

$userId = require_page_auth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /portal/withdrawals');
    exit;
}

if (!isset($_SESSION['csrf_token'])) {
    header(
        'Location: /portal/withdrawals?error=' .
        urlencode('Security token expired. Please try again.')
    );
    exit;
}

$csrfToken = isset($_POST['csrf_token'])
    ? (string) $_POST['csrf_token']
    : '';

if (!hash_equals($_SESSION['csrf_token'], $csrfToken)) {
    header(
        'Location: /portal/withdrawals?error=' .
        urlencode('Security token expired. Please try again.')
    );
    exit;
}

$withdrawalAccountId = isset($_POST['withdraw_account'])
    ? (int) $_POST['withdraw_account']
    : 0;

$amountInput = isset($_POST['amount'])
    ? trim((string) $_POST['amount'])
    : '';

if ($withdrawalAccountId <= 0) {
    header(
        'Location: /portal/withdrawals?error=' .
        urlencode('Please select a withdrawal account.')
    );
    exit;
}

if (
    $amountInput === ''
    || !preg_match('/^\d+(?:\.\d{1,2})?$/', $amountInput)
) {
    header(
        'Location: /portal/withdrawals?error=' .
        urlencode('Please enter a valid withdrawal amount.')
    );
    exit;
}

$amount = (float) $amountInput;

if ($amount <= 0) {
    header(
        'Location: /portal/withdrawals?error=' .
        urlencode('Withdrawal amount must be greater than zero.')
    );
    exit;
}

try {
    $pdo->beginTransaction();

    /*
     * Lock the selected withdrawal account and verify
     * that it belongs to the logged-in user.
     */
    $withdrawalQuery = $pdo->prepare(
        "SELECT
            id,
            method,
            account_name,
            account_number,
            bank_name,
            bank_code,
            wallet_address,
            network,
            currency,
            status
         FROM withdrawal_accounts
         WHERE id = :id
           AND user_id = :user_id
           AND status = 'active'
         LIMIT 1
         FOR UPDATE"
    );

    $withdrawalQuery->execute([
        ':id' => $withdrawalAccountId,
        ':user_id' => $userId
    ]);

    $withdrawalAccount = $withdrawalQuery->fetch();

    if (!$withdrawalAccount) {
        throw new RuntimeException(
            'The selected withdrawal account is not available.'
        );
    }

    $method = (string) $withdrawalAccount['method'];

    if ($method !== 'Crypto') {
        throw new RuntimeException(
            'Crypto is the only available withdrawal method.'
        );
    }

    $currency = strtoupper((string) $withdrawalAccount['currency']);

    /*
     * Load all withdrawal rules from the database.
     */
    $settingsQuery = $pdo->prepare(
        "SELECT
            method,
            currency,
            minimum_amount,
            maximum_amount,
            fee_type,
            fee,
            processing_time
         FROM withdrawal_settings
         WHERE method = :method
           AND currency = :currency
           AND status = 'active'
         LIMIT 1
         FOR UPDATE"
    );

    $settingsQuery->execute([
        ':method' => $method,
        ':currency' => $currency
    ]);

    $settings = $settingsQuery->fetch();

    if (!$settings) {
        throw new RuntimeException(
            'Withdrawal settings are not available for this method.'
        );
    }

    $minimumAmount = (float) $settings['minimum_amount'];
    $maximumAmount = (float) $settings['maximum_amount'];
    $feeType = (string) $settings['fee_type'];
    $feeValue = (float) $settings['fee'];

    if ($amount < $minimumAmount) {
        throw new RuntimeException(
            'Minimum withdrawal amount is ' .
            $currency . ' ' .
            number_format($minimumAmount, 2)
        );
    }

    if ($amount > $maximumAmount) {
        throw new RuntimeException(
            'Maximum withdrawal amount is ' .
            $currency . ' ' .
            number_format($maximumAmount, 2)
        );
    }

    /*
     * Calculate the withdrawal fee from database settings.
     */
    if ($feeType === 'percentage') {
        $fee = ($amount * $feeValue) / 100;
    } else {
        $fee = $feeValue;
    }

    $fee = round($fee, 2);
    $totalDebit = round($amount + $fee, 2);

    /*
     * Find and lock the user's main account.
     */
    $accountQuery = $pdo->prepare(
        "SELECT
            id,
            currency,
            wallet_type,
            available_balance
         FROM accounts
         WHERE user_id = :user_id
           AND currency = :currency
           AND wallet_type = 'main'
         LIMIT 1
         FOR UPDATE"
    );

    $accountQuery->execute([
        ':user_id' => $userId,
        ':currency' => $currency
    ]);

    $account = $accountQuery->fetch();

    if (!$account) {
        throw new RuntimeException(
            'Your main ' . $currency . ' account could not be found.'
        );
    }

    $availableBalance = (float) $account['available_balance'];

    if ($availableBalance < $totalDebit) {
        throw new RuntimeException(
            'Insufficient available balance. Your available balance is ' .
            $currency . ' ' .
            number_format($availableBalance, 2)
        );
    }

    /*
     * Generate a unique withdrawal reference.
     */
    do {
        $reference = 'WDR-' . strtoupper(bin2hex(random_bytes(8)));

        $referenceQuery = $pdo->prepare(
            "SELECT id
             FROM financial_requests
             WHERE reference = :reference
             LIMIT 1"
        );

        $referenceQuery->execute([
            ':reference' => $reference
        ]);

        $referenceExists = $referenceQuery->fetch();

    } while ($referenceExists);

    /*
     * Deduct/reserve the funds immediately.
     */
    $newBalance = round(
        $availableBalance - $totalDebit,
        2
    );

    $updateAccount = $pdo->prepare(
        "UPDATE accounts
         SET available_balance = :available_balance,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = :id
           AND user_id = :user_id"
    );

    $updateAccount->execute([
        ':available_balance' => number_format(
            $newBalance,
            2,
            '.',
            ''
        ),
        ':id' => (int) $account['id'],
        ':user_id' => $userId
    ]);

    if ($updateAccount->rowCount() !== 1) {
        throw new RuntimeException(
            'Unable to update your account balance.'
        );
    }

    /*
     * Create the pending withdrawal request.
     *
    * Keep withdrawal destinations separate from deposit payment methods.
     */
    $gateway = strtolower($method);

    $requestQuery = $pdo->prepare(
        "INSERT INTO financial_requests (
            user_id,
            account_id,
            type,
            amount,
            fee,
            currency,
            gateway,
            withdrawal_account_id,
            status,
            reference,
            notes
         ) VALUES (
            :user_id,
            :account_id,
            'withdrawal',
            :amount,
            :fee,
            :currency,
            :gateway,
            :withdrawal_account_id,
            'pending',
            :reference,
            NULL
         )"
    );

    $requestQuery->execute([
        ':user_id' => $userId,
        ':account_id' => (int) $account['id'],
        ':amount' => number_format(
            $amount,
            2,
            '.',
            ''
        ),
        ':fee' => number_format(
            $fee,
            2,
            '.',
            ''
        ),
        ':currency' => $currency,
        ':gateway' => $gateway,
        ':withdrawal_account_id' => $withdrawalAccountId,
        ':reference' => $reference
    ]);

    /*
     * Record the withdrawal in the ledger.
     */
    $ledgerQuery = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
         ) VALUES (
            :user_id,
            :account_id,
            'withdrawal',
            :amount,
            :currency,
            'completed',
            :description
         )"
    );

    $ledgerQuery->execute([
        ':user_id' => $userId,
        ':account_id' => (int) $account['id'],
        ':amount' => number_format(
            -$totalDebit,
            2,
            '.',
            ''
        ),
        ':currency' => $currency,
        ':description' => 'Withdrawal request ' . $reference
    ]);

    $pdo->commit();

    notify_admins_of_event(
        $pdo,
        $config,
        $userId,
        'New withdrawal request placed',
        'A user has submitted a Crypto withdrawal request for review.',
        [
            'Reference' => $reference,
            'Amount' => number_format($amount, 2, '.', '') . ' ' . $currency,
            'Fee' => number_format($fee, 2, '.', '') . ' ' . $currency,
            'Method' => $method,
            'Account name' => (string)$withdrawalAccount['account_name'],
            'Wallet address' => (string)$withdrawalAccount['wallet_address'],
            'Network' => (string)$withdrawalAccount['network'],
        ]
    );

    header(
        'Location: /portal/withdrawals?success=1&reference=' .
        urlencode($reference)
    );
    exit;

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log('[withdrawal-request] ' . $e->getMessage());

    $message = $e instanceof RuntimeException
        ? $e->getMessage()
        : 'Unable to process your withdrawal right now. Please try again.';

    header(
        'Location: /portal/withdrawals?error=' .
        urlencode($message)
    );
    exit;
}