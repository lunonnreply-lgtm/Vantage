<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Withdraw Money';
$activeMenu = 'withdrawals';
$canonicalPath = '/portal/withdrawals';

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$success = isset($_GET['success']) && $_GET['success'] === '1';
$requestError = isset($_GET['error']) && is_string($_GET['error'])
    ? trim(substr($_GET['error'], 0, 300))
    : '';
$reference = isset($_GET['reference'])
    ? trim((string) $_GET['reference'])
    : '';

$successTransaction = null;

if ($success && $reference !== '') {
    $successQuery = $pdo->prepare(
        "SELECT
            fr.id,
            fr.amount,
            fr.fee,
            fr.currency,
            fr.status,
            fr.reference,
            fr.created_at,
            wa.method,
            wa.account_name,
            wa.account_number,
            wa.bank_name,
            wa.wallet_address,
            wa.network
         FROM financial_requests fr
         LEFT JOIN withdrawal_accounts wa
                ON wa.id = fr.withdrawal_account_id
         WHERE fr.user_id = :user_id
           AND fr.type = 'withdrawal'
           AND fr.reference = :reference
         LIMIT 1"
    );

    $successQuery->execute([
        'user_id' => $userId,
        'reference' => $reference
    ]);

    $successTransaction = $successQuery->fetch();
}

$accountsQuery = $pdo->prepare(
    "SELECT
                wa.id,
                wa.method,
                wa.account_name,
                wa.account_number,
                wa.bank_name,
                wa.bank_code,
                wa.wallet_address,
                wa.network,
                wa.currency
         FROM withdrawal_accounts wa
         INNER JOIN accounts a
             ON a.user_id = wa.user_id
            AND a.currency = wa.currency
            AND a.wallet_type = 'main'
         WHERE wa.user_id = :user_id
             AND wa.method = 'Crypto'
             AND wa.status = 'active'
         ORDER BY wa.id DESC"
);

$accountsQuery->execute([
    'user_id' => $userId
]);

$withdrawalAccounts = $accountsQuery->fetchAll();

$extraStyles = <<<'HTML'
<style>
.withdraw-success {
    display: none;
}

.withdraw-success.show {
    display: block;
}

.withdraw-pending-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 25px;
    border: 3px solid #28a745;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
    line-height: 1;
    color: #28a745;
}

.withdraw-pending-message {
    text-align: center;
    margin-bottom: 30px;
}

.withdraw-no-account {
    text-align: center;
    padding: 35px 15px;
}

.withdraw-no-account p {
    margin-bottom: 20px;
}

.withdraw-account-summary {
    margin-top: 10px;
}

.withdraw-account-summary td:first-child {
    width: 45%;
}

.withdraw-account-summary td:last-child {
    word-break: break-word;
}

.withdraw-error {
    display: none;
    padding: 12px 15px;
    margin-bottom: 20px;
    border-radius: 5px;
    background: rgba(220, 53, 69, 0.12);
    border: 1px solid rgba(220, 53, 69, 0.35);
    color: #dc3545;
}

.withdraw-error.show {
    display: block;
}
</style>
HTML;

$extraScripts = <<<'HTML'
<script>
    "use strict";

    var withdrawalInfo = {
        range: '',
        processing_time: '',
        charge_type: 'fixed',
        charge: 0,
        fee: 0,
        currency: 'USD'
    };

    var withdrawalDetailsLoaded = false;

    function escapeHtml(value) {
        return String(value)
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;')
            .replace(/"/g, '&quot;')
            .replace(/'/g, '&#039;');
    }

    function showWithdrawalError(message) {
        $('#withdrawError')
            .text(message)
            .addClass('show');
    }

    function hideWithdrawalError() {
        $('#withdrawError')
            .removeClass('show')
            .text('');
    }

    function getWithdrawalAmount() {
        var value = $('.withdrawAmount').val();

        if (value === undefined || value === null) {
            return 0;
        }

        value = String(value).replace(/,/g, '');

        var amount = parseFloat(value);

        return isNaN(amount) ? 0 : amount;
    }

    function updateWithdrawalPreview() {
        var amount = getWithdrawalAmount();

        var fee = withdrawalInfo.charge_type === 'percentage'
            ? (amount * parseFloat(withdrawalInfo.charge || 0) / 100)
            : parseFloat(withdrawalInfo.charge || 0);

        if (!isFinite(fee)) {
            fee = 0;
        }

        withdrawalInfo.fee = fee;

        var currency = withdrawalInfo.currency || 'USD';

        $('.withdrawAmountPreview').text(
            currency + ' ' + amount.toFixed(2)
        );

        $('.withdrawFee').text(
            currency + ' ' + fee.toFixed(2)
        );

        $('.processing-time').text(
            withdrawalInfo.processing_time || ''
        );

        $('.withdrawAmountRange').text(
            withdrawalInfo.range || ''
        );
    }

    function loadWithdrawalDetails() {
        hideWithdrawalError();

        var accountId = $('#withdrawAccountId').val();
        var amount = $('.withdrawAmount').val();

        withdrawalDetailsLoaded = false;

        $('.selectDetailsTbody')
            .find('tr.withdraw-dynamic-detail')
            .remove();

        if (!accountId) {
            withdrawalInfo = {
                range: '',
                processing_time: '',
                charge_type: 'fixed',
                charge: 0,
                fee: 0,
                currency: 'USD'
            };

            $('.processing-time').text('');
            $('.withdrawAmountRange').text('');
            $('.withdrawAmountPreview').text('USD 0.00');
            $('.withdrawFee').text('USD 0.00');

            return;
        }

        $.ajax({
            url: '/portal/withdrawals/details',
            method: 'GET',
            dataType: 'json',
            data: {
                account_id: accountId,
                amount: amount
            },
            success: function (data) {
                if (!data || data.success !== true) {
                    showWithdrawalError(
                        data && data.message
                            ? data.message
                            : 'Unable to load withdrawal account details.'
                    );

                    return;
                }

                withdrawalInfo = data.info || withdrawalInfo;

                $(data.html)
                    .addClass('withdraw-dynamic-detail')
                    .insertAfter('.detailsCol');

                withdrawalDetailsLoaded = true;

                updateWithdrawalPreview();
            },
            error: function (xhr) {
                var message = 'Unable to load withdrawal account details.';

                if (
                    xhr.responseJSON &&
                    xhr.responseJSON.message
                ) {
                    message = xhr.responseJSON.message;
                }

                showWithdrawalError(message);
            }
        });
    }

    $('#withdrawAccountId').on('change', function () {
        loadWithdrawalDetails();
    });

    $('.withdrawAmount').on('input keyup change', function () {
        hideWithdrawalError();

        if ($('#withdrawAccountId').val()) {
            var accountId = $('#withdrawAccountId').val();
            var amount = $('.withdrawAmount').val();

            $.ajax({
                url: '/portal/withdrawals/details',
                method: 'GET',
                dataType: 'json',
                data: {
                    account_id: accountId,
                    amount: amount
                },
                success: function (data) {
                    if (data && data.success === true) {
                        withdrawalInfo = data.info || withdrawalInfo;

                        $('.selectDetailsTbody')
                            .find('.withdraw-dynamic-detail')
                            .remove();

                        $(data.html)
                            .addClass('withdraw-dynamic-detail')
                            .insertAfter('.detailsCol');

                        withdrawalDetailsLoaded = true;

                        updateWithdrawalPreview();
                    }
                }
            });
        } else {
            updateWithdrawalPreview();
        }
    });

    $('#withdrawForm').on('submit', function (e) {
        hideWithdrawalError();

        var accountId = $('#withdrawAccountId').val();
        var amount = getWithdrawalAmount();

        if (!accountId) {
            e.preventDefault();
            showWithdrawalError('Please select a withdrawal account.');
            return false;
        }

        if (amount <= 0) {
            e.preventDefault();
            showWithdrawalError('Please enter a valid withdrawal amount.');
            return false;
        }

        return true;
    });

    updateWithdrawalPreview();
</script>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <?php if ($success && $successTransaction): ?>

            <div class="site-card withdraw-success show">
                <div class="site-card-body">

                    <div class="progress-steps-form">

                        <div class="progress-steps">
                            <div class="single-step">
                                <div class="number">01</div>
                                <div class="content">
                                    <h4>Withdrawal Details</h4>
                                    <p>Enter your withdrawal details</p>
                                </div>
                            </div>

                            <div class="single-step current">
                                <div class="number">02</div>
                                <div class="content">
                                    <h4>Request Submitted</h4>
                                    <p>Pending processing</p>
                                </div>
                            </div>
                        </div>

                        <div class="withdraw-pending-message">

                            <div class="withdraw-pending-icon">
                                <i class="anticon anticon-check"></i>
                            </div>

                            <h3>Success</h3>

                            <p>
                                Your withdrawal request has been submitted successfully.
                            </p>

                            <p>
                                Your withdrawal is now pending processing.
                            </p>

                        </div>

                        <div class="transaction-list table-responsive">

                            <div class="user-panel-title">
                                <h3>Withdrawal Details</h3>
                            </div>

                            <table class="table">
                                <tbody>

                                    <tr>
                                        <td>
                                            <strong>Transaction ID</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) $successTransaction['reference'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Withdrawal Amount</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) $successTransaction['currency'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                            <?= number_format(
                                                (float) $successTransaction['amount'],
                                                2
                                            ) ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Fee</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) $successTransaction['currency'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                            <?= number_format(
                                                (float) $successTransaction['fee'],
                                                2
                                            ) ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Withdrawal Method</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) (
                                                    $successTransaction['method']
                                                    ?: 'Withdrawal Account'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Account Name</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) (
                                                    $successTransaction['account_name']
                                                    ?: '—'
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>
                                    </tr>

                                    <?php if (
                                        !empty($successTransaction['bank_name'])
                                    ): ?>

                                        <tr>
                                            <td>
                                                <strong>Bank Name</strong>
                                            </td>
                                            <td>
                                                <?= htmlspecialchars(
                                                    (string) $successTransaction['bank_name'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>
                                        </tr>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty($successTransaction['account_number'])
                                    ): ?>

                                        <tr>
                                            <td>
                                                <strong>Account Number</strong>
                                            </td>
                                            <td>
                                                <?= htmlspecialchars(
                                                    (string) $successTransaction['account_number'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>
                                        </tr>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty($successTransaction['wallet_address'])
                                    ): ?>

                                        <tr>
                                            <td>
                                                <strong>Wallet Address</strong>
                                            </td>
                                            <td>
                                                <?= htmlspecialchars(
                                                    (string) $successTransaction['wallet_address'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>
                                        </tr>

                                    <?php endif; ?>

                                    <?php if (
                                        !empty($successTransaction['network'])
                                    ): ?>

                                        <tr>
                                            <td>
                                                <strong>Network</strong>
                                            </td>
                                            <td>
                                                <?= htmlspecialchars(
                                                    (string) $successTransaction['network'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>
                                        </tr>

                                    <?php endif; ?>

                                    <tr>
                                        <td>
                                            <strong>Status</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                ucfirst(
                                                    (string) $successTransaction['status']
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Date</strong>
                                        </td>
                                        <td>
                                            <?= htmlspecialchars(
                                                (string) $successTransaction['created_at'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>
                                        </td>
                                    </tr>

                                </tbody>
                            </table>

                        </div>

                        <div class="buttons">
                            <a
                                href="/portal/withdrawals"
                                class="site-btn blue-btn"
                            >
                                Withdraw Again
                                <i class="anticon anticon-double-right"></i>
                            </a>
                        </div>

                    </div>

                </div>
            </div>

        <?php else: ?>

            <div class="site-card">

                <div class="site-card-header">

                    <h3 class="title">Withdraw Money</h3>

                    <div class="card-header-links">
                        <a
                            href="/portal/withdrawals/account"
                            class="card-header-link"
                        >
                            Withdraw Account
                        </a>
                    </div>

                </div>

                <div class="site-card-body">

                    <?php if (empty($withdrawalAccounts)): ?>

                        <?php if ($requestError !== ''): ?>
                            <div class="withdraw-error show" role="alert">
                                <?= htmlspecialchars($requestError, ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>

                        <div class="withdraw-no-account">

                            <div class="user-panel-title">
                                <h3>No Withdrawal Account</h3>
                            </div>

                            <p>
                                You need to add a withdrawal account before
                                you can request a withdrawal.
                            </p>

                            <a
                                href="/portal/withdrawals/account"
                                class="site-btn blue-btn"
                            >
                                Add Withdrawal Account
                                <i class="anticon anticon-double-right"></i>
                            </a>

                        </div>

                    <?php else: ?>

                        <?php if ($requestError !== ''): ?>
                            <div class="withdraw-error show" role="alert">
                                <?= htmlspecialchars($requestError, ENT_QUOTES, 'UTF-8') ?>
                            </div>
                        <?php endif; ?>

                        <div class="progress-steps-form">

                            <form
                                id="withdrawForm"
                                action="/portal/withdrawals/now"
                                method="post"
                            >

                                <input
                                    type="hidden"
                                    name="csrf_token"
                                    value="<?= htmlspecialchars(
                                        $_SESSION['csrf_token'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                                <div class="progress-steps">

                                    <div class="single-step current">
                                        <div class="number">01</div>
                                        <div class="content">
                                            <h4>Withdrawal Details</h4>
                                            <p>Enter your withdrawal details</p>
                                        </div>
                                    </div>

                                    <div class="single-step">
                                        <div class="number">02</div>
                                        <div class="content">
                                            <h4>Request Submitted</h4>
                                            <p>Pending processing</p>
                                        </div>
                                    </div>

                                </div>

                                <div
                                    id="withdrawError"
                                    class="withdraw-error"
                                ></div>

                                <div class="row">

                                    <div class="col-xl-6 col-md-12 mb-3">

                                        <label
                                            class="form-label"
                                            for="withdrawAccountId"
                                        >
                                            Withdraw Account
                                        </label>

                                        <div class="input-group">

                                            <select
                                                name="withdraw_account"
                                                id="withdrawAccountId"
                                                class="site-nice-select"
                                                required
                                            >

                                                <option
                                                    value=""
                                                    selected
                                                    disabled
                                                >
                                                    Withdraw Method
                                                </option>

                                                <?php foreach (
                                                    $withdrawalAccounts
                                                    as $account
                                                ): ?>

                                                    <?php
                                                    $accountLabel =
                                                        (string) $account['method']
                                                        . ' - '
                                                        . (string) $account['account_name'];

                                                    if (
                                                        $account['method']
                                                        === 'Bank Transfer'
                                                        &&
                                                        !empty(
                                                            $account['bank_name']
                                                        )
                                                    ) {
                                                        $accountLabel .=
                                                            ' - '
                                                            . (string) $account['bank_name'];
                                                    }

                                                    if (
                                                        $account['method']
                                                        === 'Crypto'
                                                        &&
                                                        !empty(
                                                            $account['network']
                                                        )
                                                    ) {
                                                        $accountLabel .=
                                                            ' - '
                                                            . (string) $account['network'];
                                                    }
                                                    ?>

                                                    <option
                                                        value="<?= (int) $account['id'] ?>"
                                                    >
                                                        <?= htmlspecialchars(
                                                            $accountLabel,
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </option>

                                                <?php endforeach; ?>

                                            </select>

                                        </div>

                                        <div class="input-info-text processing-time"></div>

                                    </div>

                                    <div class="col-xl-6 col-md-12">

                                        <label
                                            class="form-label"
                                            for="withdrawAmount"
                                        >
                                            Amount
                                        </label>

                                        <div class="input-group">

                                            <input
                                                type="text"
                                                name="amount"
                                                id="withdrawAmount"
                                                class="form-control withdrawAmount"
                                                placeholder="Enter Amount"
                                                inputmode="decimal"
                                                autocomplete="off"
                                                required
                                            >

                                        </div>

                                        <div class="input-info-text withdrawAmountRange"></div>

                                    </div>

                                </div>

                                <div class="transaction-list table-responsive">

                                    <div class="user-panel-title">
                                        <h3>Withdraw Details</h3>
                                    </div>

                                    <table class="table">

                                        <tbody class="selectDetailsTbody">

                                            <tr class="detailsCol">

                                                <td>
                                                    <strong>
                                                        Withdraw Amount
                                                    </strong>
                                                </td>

                                                <td>
                                                    <span class="withdrawAmountPreview">
                                                        USD 0.00
                                                    </span>
                                                </td>

                                            </tr>

                                            <tr>

                                                <td>
                                                    <strong>
                                                        Withdrawal Fee
                                                    </strong>
                                                </td>

                                                <td>
                                                    <span class="withdrawFee">
                                                        USD 0.00
                                                    </span>
                                                </td>

                                            </tr>

                                        </tbody>

                                    </table>

                                </div>

                                <div class="buttons">

                                    <button
                                        type="submit"
                                        class="site-btn blue-btn"
                                    >
                                        Withdraw Money
                                        <i class="anticon anticon-double-right"></i>
                                    </button>

                                </div>

                            </form>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        <?php endif; ?>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>