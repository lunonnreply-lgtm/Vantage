<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $csrfToken = isset($_POST['csrf_token'])
        ? (string) $_POST['csrf_token']
        : '';

    if (!hash_equals($_SESSION['csrf_token'], $csrfToken)) {
        $message = 'Security token expired. Please try again.';
        $messageType = 'error';
    } else {
        $action = isset($_POST['action'])
            ? trim((string) $_POST['action'])
            : '';

        try {
            if ($action === 'add') {
                $method = isset($_POST['method'])
                    ? trim((string) $_POST['method'])
                    : '';

                $methodSelection = explode('|', $method, 2);
                $method = $methodSelection[0] ?? '';
                $requestedCurrency = strtoupper(trim($methodSelection[1] ?? ''));

                $accountName = isset($_POST['account_name'])
                    ? trim((string) $_POST['account_name'])
                    : '';

                $accountNumber = isset($_POST['account_number'])
                    ? trim((string) $_POST['account_number'])
                    : '';

                $bankName = isset($_POST['bank_name'])
                    ? trim((string) $_POST['bank_name'])
                    : '';

                $bankCode = isset($_POST['bank_code'])
                    ? trim((string) $_POST['bank_code'])
                    : '';

                $walletAddress = isset($_POST['wallet_address'])
                    ? trim((string) $_POST['wallet_address'])
                    : '';

                $network = isset($_POST['network'])
                    ? trim((string) $_POST['network'])
                    : '';

                if ($method === '') {
                    throw new RuntimeException(
                        'Please select a withdrawal method.'
                    );
                }

                if ($method !== 'Crypto') {
                    throw new RuntimeException(
                        'Crypto is the only available withdrawal method.'
                    );
                }

                if (!preg_match('/^[A-Z]{3}$/', $requestedCurrency)) {
                    throw new RuntimeException(
                        'Please select a supported withdrawal currency.'
                    );
                }

                $methodQuery = $pdo->prepare(
                    "SELECT ws.method, ws.currency
                     FROM withdrawal_settings ws
                     WHERE ws.method = :method
                       AND ws.currency = :currency
                       AND ws.status = 'active'
                       AND EXISTS (
                           SELECT 1
                           FROM accounts a
                           WHERE a.user_id = :user_id
                             AND a.currency = ws.currency
                             AND a.wallet_type = 'main'
                       )
                     LIMIT 1"
                );

                $methodQuery->execute([
                    ':method' => $method,
                    ':currency' => $requestedCurrency,
                    ':user_id' => $userId,
                ]);

                $methodSettings = $methodQuery->fetch();

                if (!$methodSettings) {
                    throw new RuntimeException(
                        'The selected withdrawal method is not available.'
                    );
                }

                if ($accountName === '') {
                    throw new RuntimeException(
                        'Please enter the account name.'
                    );
                }

                if ($method === 'Bank Transfer') {
                    if ($accountNumber === '') {
                        throw new RuntimeException(
                            'Please enter the account number.'
                        );
                    }

                    if ($bankName === '') {
                        throw new RuntimeException(
                            'Please enter the bank name.'
                        );
                    }

                    $duplicateQuery = $pdo->prepare(
                        "SELECT id
                         FROM withdrawal_accounts
                         WHERE user_id = :user_id
                           AND method = :method
                                                     AND currency = :currency
                           AND account_number = :account_number
                           AND status = 'active'
                         LIMIT 1"
                    );

                    $duplicateQuery->execute([
                        ':user_id' => $userId,
                        ':method' => $method,
                        ':currency' => $requestedCurrency,
                        ':account_number' => $accountNumber
                    ]);
                } else {
                    if ($walletAddress === '') {
                        throw new RuntimeException(
                            'Please enter the wallet address.'
                        );
                    }

                    if ($network === '') {
                        throw new RuntimeException(
                            'Please enter the network.'
                        );
                    }

                    $duplicateQuery = $pdo->prepare(
                        "SELECT id
                         FROM withdrawal_accounts
                         WHERE user_id = :user_id
                           AND method = :method
                                                     AND currency = :currency
                           AND wallet_address = :wallet_address
                           AND status = 'active'
                         LIMIT 1"
                    );

                    $duplicateQuery->execute([
                        ':user_id' => $userId,
                        ':method' => $method,
                        ':currency' => $requestedCurrency,
                        ':wallet_address' => $walletAddress
                    ]);
                }

                if ($duplicateQuery->fetch()) {
                    throw new RuntimeException(
                        'This withdrawal account has already been added.'
                    );
                }

                $insertQuery = $pdo->prepare(
                    "INSERT INTO withdrawal_accounts (
                        user_id,
                        method,
                        account_name,
                        account_number,
                        bank_name,
                        bank_code,
                        wallet_address,
                        network,
                        currency,
                        status
                     ) VALUES (
                        :user_id,
                        :method,
                        :account_name,
                        :account_number,
                        :bank_name,
                        :bank_code,
                        :wallet_address,
                        :network,
                        :currency,
                        'active'
                     )"
                );

                $insertQuery->execute([
                    ':user_id' => $userId,
                    ':method' => $method,
                    ':account_name' => $accountName,
                    ':account_number' => $accountNumber !== ''
                        ? $accountNumber
                        : null,
                    ':bank_name' => $bankName !== ''
                        ? $bankName
                        : null,
                    ':bank_code' => $bankCode !== ''
                        ? $bankCode
                        : null,
                    ':wallet_address' => $walletAddress !== ''
                        ? $walletAddress
                        : null,
                    ':network' => $network !== ''
                        ? $network
                        : null,
                    ':currency' => strtoupper(
                        (string) $methodSettings['currency']
                    )
                ]);

                $message = 'Withdrawal account added successfully.';
                $messageType = 'success';

            } elseif ($action === 'delete') {
                $accountId = isset($_POST['account_id'])
                    ? (int) $_POST['account_id']
                    : 0;

                if ($accountId <= 0) {
                    throw new RuntimeException(
                        'Invalid withdrawal account.'
                    );
                }

                $deleteQuery = $pdo->prepare(
                    "UPDATE withdrawal_accounts
                     SET status = 'inactive',
                         updated_at = CURRENT_TIMESTAMP
                     WHERE id = :id
                       AND user_id = :user_id
                       AND status = 'active'"
                );

                $deleteQuery->execute([
                    ':id' => $accountId,
                    ':user_id' => $userId
                ]);

                if ($deleteQuery->rowCount() !== 1) {
                    throw new RuntimeException(
                        'Withdrawal account could not be removed.'
                    );
                }

                $message = 'Withdrawal account removed successfully.';
                $messageType = 'success';
            }

        } catch (Throwable $e) {
            $message = $e instanceof RuntimeException
                ? $e->getMessage()
                : 'Unable to process your request right now.';

            $messageType = 'error';
        }
    }
}

$methodsQuery = $pdo->prepare(
        "SELECT DISTINCT ws.method, ws.currency
         FROM withdrawal_settings ws
         INNER JOIN accounts a
             ON a.user_id = :user_id
            AND a.currency = ws.currency
            AND a.wallet_type = 'main'
         WHERE ws.method = 'Crypto'
             AND ws.status = 'active'
         ORDER BY ws.currency"
);
$methodsQuery->execute(['user_id' => $userId]);

$withdrawalMethods = $methodsQuery->fetchAll();

$accountsQuery = $pdo->prepare(
    "SELECT
        id,
        method,
        account_name,
        account_number,
        bank_name,
        bank_code,
        wallet_address,
        network,
        currency,
        status,
        created_at
     FROM withdrawal_accounts
     WHERE user_id = :user_id
             AND method = 'Crypto'
       AND status = 'active'
     ORDER BY id DESC"
);

$accountsQuery->execute([
    ':user_id' => $userId
]);

$withdrawalAccounts = $accountsQuery->fetchAll();

$pageTitle = 'Withdrawal Accounts';
$activeMenu = 'withdrawals';
$canonicalPath = '/portal/withdrawals/account';

$extraStyles = <<<'HTML'
<style>

.withdrawal-form-card {
    overflow: hidden;
}

.withdrawal-form-heading {
    display: flex;
    align-items: center;
    gap: 15px;
    padding-bottom: 24px;
    margin-bottom: 25px;
    border-bottom: 1px solid rgba(255,255,255,.07);
}

.withdrawal-form-icon {
    width: 46px;
    height: 46px;
    flex: 0 0 46px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 10px;
    background: rgba(251,191,36,.10);
    border: 1px solid rgba(251,191,36,.18);
    color: #fbbf24;
    font-size: 22px;
}

.withdrawal-form-heading h2 {
    margin: 0 0 5px;
    font-size: 20px;
}

.withdrawal-form-heading p {
    margin: 0;
    font-size: 13px;
    opacity: .62;
    line-height: 1.5;
}

.withdrawal-account-form {
    width: 100%;
}

.withdrawal-form-section {
    padding: 2px 0;
}

.withdrawal-section-title {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-bottom: 22px;
}

.withdrawal-section-title > span {
    width: 30px;
    height: 30px;
    flex: 0 0 30px;
    display: flex;
    align-items: center;
    justify-content: center;
    border-radius: 50%;
    background: rgba(251,191,36,.10);
    border: 1px solid rgba(251,191,36,.18);
    color: #fbbf24;
    font-size: 13px;
    font-weight: 600;
}

.withdrawal-section-title strong {
    display: block;
    margin-bottom: 3px;
    font-size: 14px;
}

.withdrawal-section-title small {
    display: block;
    font-size: 12px;
    opacity: .55;
}

.withdrawal-form-divider {
    height: 1px;
    margin: 25px 0;
    background: rgba(255,255,255,.07);
}

.withdrawal-fields-grid {
    display: grid;
    grid-template-columns: 1fr 1fr;
    gap: 18px;
}

.withdrawal-account-form .form-group {
    margin-bottom: 18px;
}

.withdrawal-account-form label {
    display: block;
    margin-bottom: 8px;
    font-size: 13px;
    font-weight: 500;
}

.withdrawal-account-form .form-control {
    width: 100%;
    min-height: 46px;
    box-sizing: border-box;
}

.withdrawal-account-form .form-control::placeholder {
    opacity: .42;
}

.optional-label {
    margin-left: 5px;
    font-size: 11px;
    font-weight: 400;
    opacity: .45;
}

.withdrawal-form-footer {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    margin-top: 28px;
    padding-top: 22px;
    border-top: 1px solid rgba(255,255,255,.07);
}

.withdrawal-security-note {
    display: flex;
    align-items: flex-start;
    gap: 10px;
    max-width: 420px;
}

.withdrawal-security-note > span {
    font-size: 15px;
    opacity: .7;
}

.withdrawal-security-note strong {
    display: block;
    margin-bottom: 3px;
    font-size: 12px;
}

.withdrawal-security-note small {
    display: block;
    font-size: 11px;
    line-height: 1.5;
    opacity: .48;
}

.withdrawal-submit-btn {
    white-space: nowrap;
    min-width: 190px;
}

.withdraw-alert {
    padding: 14px 16px;
    border-radius: 8px;
    margin-bottom: 22px;
    font-size: 14px;
}

.withdraw-alert-success {
    background: rgba(40,167,69,.10);
    color: #28a745;
    border: 1px solid rgba(40,167,69,.25);
}

.withdraw-alert-error {
    background: rgba(220,53,69,.10);
    color: #dc3545;
    border: 1px solid rgba(220,53,69,.25);
}

.withdraw-method-fields {
    display: none;
}

.withdraw-account-list {
    margin-top: 25px;
}

.withdraw-account-list-header {
    padding-bottom: 20px;
    margin-bottom: 20px;
    border-bottom: 1px solid rgba(255,255,255,.07);
}

.withdraw-account-list-header h2 {
    margin: 0 0 5px;
    font-size: 20px;
}

.withdraw-account-list-header p {
    margin: 0;
    font-size: 13px;
    opacity: .62;
}

.withdraw-account-item {
    position: relative;
    padding: 20px;
    margin-bottom: 15px;
    border: 1px solid rgba(255,255,255,.08);
    border-radius: 10px;
    background: rgba(255,255,255,.02);
}

.withdraw-account-item:last-child {
    margin-bottom: 0;
}

.withdraw-account-top {
    display: flex;
    align-items: flex-start;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 18px;
}

.withdraw-account-method {
    font-size: 16px;
    font-weight: 600;
}

.withdraw-account-currency {
    display: inline-block;
    margin-top: 5px;
    font-size: 12px;
    opacity: .6;
}

.withdraw-account-details {
    display: grid;
    grid-template-columns: repeat(2, minmax(0, 1fr));
    gap: 14px 20px;
}

.withdraw-account-detail {
    min-width: 0;
}

.withdraw-account-detail-label {
    display: block;
    margin-bottom: 5px;
    font-size: 12px;
    opacity: .55;
}

.withdraw-account-detail-value {
    display: block;
    font-size: 14px;
    word-break: break-word;
}

.withdraw-account-actions {
    margin-top: 18px;
    padding-top: 15px;
    border-top: 1px solid rgba(255,255,255,.06);
}

.withdraw-remove-btn {
    border: 0;
    background: transparent;
    color: #dc3545;
    padding: 0;
    cursor: pointer;
    font-size: 13px;
}

.withdraw-remove-btn:hover {
    opacity: .8;
}

.withdraw-empty {
    text-align: center;
    padding: 35px 20px;
    border: 1px dashed rgba(255,255,255,.12);
    border-radius: 10px;
    opacity: .7;
}

@media (max-width: 700px) {

    .withdrawal-fields-grid {
        grid-template-columns: 1fr;
        gap: 0;
    }

    .withdrawal-form-footer {
        align-items: stretch;
        flex-direction: column;
    }

    .withdrawal-submit-btn {
        width: 100%;
    }

    .withdraw-account-details {
        grid-template-columns: 1fr;
    }

    .withdraw-account-top {
        flex-direction: column;
        gap: 5px;
    }
}

@media (max-width: 480px) {

    .withdrawal-form-heading {
        align-items: flex-start;
    }

    .withdrawal-form-icon {
        width: 40px;
        height: 40px;
        flex-basis: 40px;
    }

    .withdrawal-form-heading h2 {
        font-size: 18px;
    }
}

.withdrawal-form-card {
    overflow: hidden;
    padding: 30px;
}

.withdraw-account-list {
    margin-top: 25px;
    padding: 30px;
}

@media (max-width: 700px) {
    .withdrawal-form-card,
    .withdraw-account-list {
        padding: 20px;
    }
}

</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="site-card withdrawal-form-card">

    <div class="withdrawal-form-heading">

        <div class="withdrawal-form-icon">
            <span>↗</span>
        </div>

        <div>
            <h2>Add Withdrawal Account</h2>

            <p>
                Add a bank account or wallet where you want to receive your withdrawals.
            </p>
        </div>

    </div>

    <?php if ($message !== ''): ?>

        <div class="withdraw-alert <?php echo $messageType === 'success'
            ? 'withdraw-alert-success'
            : 'withdraw-alert-error'; ?>">

            <?php
            echo htmlspecialchars(
                $message,
                ENT_QUOTES,
                'UTF-8'
            );
            ?>

        </div>

    <?php endif; ?>

    <form
        method="post"
        class="withdrawal-account-form"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?php echo htmlspecialchars(
                $_SESSION['csrf_token'],
                ENT_QUOTES,
                'UTF-8'
            ); ?>"
        >

        <input
            type="hidden"
            name="action"
            value="add"
        >

        <div class="withdrawal-form-section">

            <div class="withdrawal-section-title">

                <span>1</span>

                <div>
                    <strong>Withdrawal Method</strong>

                    <small>
                        Choose where your withdrawal should be sent.
                    </small>
                </div>

            </div>

            <div class="form-group">

                <label for="withdrawMethod">
                    Withdrawal Method
                </label>

                <select
                    name="method"
                    id="withdrawMethod"
                    class="form-control"
                    required
                >
                    <option value="">
                        Select withdrawal method
                    </option>

                    <?php foreach ($withdrawalMethods as $method): ?>

                        <option
                            value="<?php echo htmlspecialchars(
                                $method['method'] . '|' . $method['currency'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                        >
                            <?php
                            echo htmlspecialchars(
                                $method['method'],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>
                            —
                            <?php
                            echo htmlspecialchars(
                                $method['currency'],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>
                        </option>

                    <?php endforeach; ?>

                </select>

                <?php if (empty($withdrawalMethods)): ?>
                    <div class="input-info-text">
                        No active crypto withdrawal setting matches your main-wallet currency.
                    </div>
                <?php endif; ?>

            </div>

        </div>

        <div class="withdrawal-form-divider"></div>

        <div class="withdrawal-form-section">

            <div class="withdrawal-section-title">

                <span>2</span>

                <div>
                    <strong>Account Information</strong>

                    <small>
                        Enter the details of your withdrawal destination.
                    </small>
                </div>

            </div>

            <div class="form-group">

                <label for="accountName">
                    Account Name
                </label>

                <input
                    type="text"
                    name="account_name"
                    id="accountName"
                    class="form-control"
                    maxlength="150"
                    autocomplete="name"
                    placeholder="Enter account name"
                    required
                >

            </div>

            <div
                id="bankFields"
                class="withdraw-method-fields"
            >

                <div class="withdrawal-fields-grid">

                    <div class="form-group">

                        <label for="bankName">
                            Bank Name
                        </label>

                        <input
                            type="text"
                            name="bank_name"
                            id="bankName"
                            class="form-control"
                            maxlength="150"
                            placeholder="Enter bank name"
                        >

                    </div>

                    <div class="form-group">

                        <label for="accountNumber">
                            Account Number
                        </label>

                        <input
                            type="text"
                            name="account_number"
                            id="accountNumber"
                            class="form-control"
                            maxlength="150"
                            placeholder="Enter account number"
                        >

                    </div>

                </div>

                <div class="form-group">

                    <label for="bankCode">
                        Bank Code
                        <span class="optional-label">
                            Optional
                        </span>
                    </label>

                    <input
                        type="text"
                        name="bank_code"
                        id="bankCode"
                        class="form-control"
                        maxlength="50"
                        placeholder="Enter bank code"
                    >

                </div>

            </div>

            <div
                id="cryptoFields"
                class="withdraw-method-fields"
            >

                <div class="form-group">

                    <label for="walletAddress">
                        Wallet Address
                    </label>

                    <input
                        type="text"
                        name="wallet_address"
                        id="walletAddress"
                        class="form-control"
                        maxlength="255"
                        placeholder="Enter wallet address"
                    >

                </div>

                <div class="form-group">

                    <label for="network">
                        Network
                    </label>

                    <input
                        type="text"
                        name="network"
                        id="network"
                        class="form-control"
                        maxlength="60"
                        placeholder="Enter network"
                    >

                </div>

            </div>

        </div>

        <div class="withdrawal-form-footer">

            <div class="withdrawal-security-note">

                <span>🔒</span>

                <div>

                    <strong>
                        Your information is secure
                    </strong>

                    <small>
                        Your withdrawal details are stored securely and can only be used by you.
                    </small>

                </div>

            </div>

            <button
                type="submit"
                class="site-btn withdrawal-submit-btn"
            >
                Add Withdrawal Account
            </button>

        </div>

    </form>

</div>

<div class="site-card withdraw-account-list">

    <div class="withdraw-account-list-header">

        <h2>Saved Withdrawal Accounts</h2>

        <p>
            Your active withdrawal destinations.
        </p>

    </div>

    <?php if (empty($withdrawalAccounts)): ?>

        <div class="withdraw-empty">
            No withdrawal accounts have been added yet.
        </div>

    <?php else: ?>

        <?php foreach ($withdrawalAccounts as $account): ?>

            <div class="withdraw-account-item">

                <div class="withdraw-account-top">

                    <div>

                        <div class="withdraw-account-method">

                            <?php
                            echo htmlspecialchars(
                                $account['method'],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>

                        </div>

                        <span class="withdraw-account-currency">

                            <?php
                            echo htmlspecialchars(
                                $account['currency'],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>

                        </span>

                    </div>

                </div>

                <div class="withdraw-account-details">

                    <div class="withdraw-account-detail">

                        <span class="withdraw-account-detail-label">
                            Account Name
                        </span>

                        <span class="withdraw-account-detail-value">

                            <?php
                            echo htmlspecialchars(
                                $account['account_name'],
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>

                        </span>

                    </div>

                    <?php if ($account['method'] === 'Bank Transfer'): ?>

                        <div class="withdraw-account-detail">

                            <span class="withdraw-account-detail-label">
                                Bank Name
                            </span>

                            <span class="withdraw-account-detail-value">

                                <?php
                                echo htmlspecialchars(
                                    (string) $account['bank_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>

                            </span>

                        </div>

                        <div class="withdraw-account-detail">

                            <span class="withdraw-account-detail-label">
                                Account Number
                            </span>

                            <span class="withdraw-account-detail-value">

                                <?php
                                echo htmlspecialchars(
                                    (string) $account['account_number'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>

                            </span>

                        </div>

                        <?php if (!empty($account['bank_code'])): ?>

                            <div class="withdraw-account-detail">

                                <span class="withdraw-account-detail-label">
                                    Bank Code
                                </span>

                                <span class="withdraw-account-detail-value">

                                    <?php
                                    echo htmlspecialchars(
                                        $account['bank_code'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                    ?>

                                </span>

                            </div>

                        <?php endif; ?>

                    <?php else: ?>

                        <div class="withdraw-account-detail">

                            <span class="withdraw-account-detail-label">
                                Wallet Address
                            </span>

                            <span class="withdraw-account-detail-value">

                                <?php
                                echo htmlspecialchars(
                                    (string) $account['wallet_address'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                );
                                ?>

                            </span>

                        </div>

                        <?php if (!empty($account['network'])): ?>

                            <div class="withdraw-account-detail">

                                <span class="withdraw-account-detail-label">
                                    Network
                                </span>

                                <span class="withdraw-account-detail-value">

                                    <?php
                                    echo htmlspecialchars(
                                        $account['network'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                    ?>

                                </span>

                            </div>

                        <?php endif; ?>

                    <?php endif; ?>

                </div>

                <div class="withdraw-account-actions">

                    <form
                        method="post"
                        onsubmit="return confirm('Remove this withdrawal account?');"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?php echo htmlspecialchars(
                                $_SESSION['csrf_token'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                        >

                        <input
                            type="hidden"
                            name="action"
                            value="delete"
                        >

                        <input
                            type="hidden"
                            name="account_id"
                            value="<?php echo (int) $account['id']; ?>"
                        >

                        <button
                            type="submit"
                            class="withdraw-remove-btn"
                        >
                            Remove withdrawal account
                        </button>

                    </form>

                </div>

            </div>

        <?php endforeach; ?>

    <?php endif; ?>

</div>

<script>
(function () {
    var method = document.getElementById('withdrawMethod');
    var bankFields = document.getElementById('bankFields');
    var cryptoFields = document.getElementById('cryptoFields');

    if (!method || !bankFields || !cryptoFields) {
        return;
    }

    function updateFields() {
        var value = method.value.split('|')[0];

        bankFields.style.display = value === 'Bank Transfer'
            ? 'block'
            : 'none';

        cryptoFields.style.display = value === 'Crypto'
            ? 'block'
            : 'none';

        var bankInputs = bankFields.querySelectorAll('input');
        var cryptoInputs = cryptoFields.querySelectorAll('input');

        for (var i = 0; i < bankInputs.length; i++) {
            bankInputs[i].required = value === 'Bank Transfer';

            if (value !== 'Bank Transfer') {
                bankInputs[i].value = '';
            }
        }

        for (var j = 0; j < cryptoInputs.length; j++) {
            cryptoInputs[j].required = value === 'Crypto';

            if (value !== 'Crypto') {
                cryptoInputs[j].value = '';
            }
        }
    }

    method.addEventListener('change', updateFields);

    updateFields();
})();
</script>

<?php require __DIR__ . '/../_footer.php'; ?>