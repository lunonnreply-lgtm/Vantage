<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

header('Content-Type: application/json; charset=utf-8');

$accountId = isset($_GET['account_id'])
    ? (int) $_GET['account_id']
    : (isset($_GET['accountId']) ? (int) $_GET['accountId'] : 0);

$amountInput = isset($_GET['amount'])
    ? trim((string) $_GET['amount'])
    : '';

if ($accountId <= 0) {
    respond([
        'success' => false,
        'message' => 'Invalid withdrawal account.'
    ], 400);
}

if (
    $amountInput !== ''
    && !preg_match('/^\d+(?:\.\d{1,2})?$/', $amountInput)
) {
    respond([
        'success' => false,
        'message' => 'Invalid withdrawal amount.'
    ], 400);
}

$amount = $amountInput === ''
    ? 0.00
    : (float) $amountInput;

try {
    $accountQuery = $pdo->prepare(
        "SELECT
            id,
            method,
            account_name,
            account_number,
            bank_name,
            bank_code,
            wallet_address,
            network,
            currency,
            status
         FROM withdrawal_accounts
         WHERE id = :id
           AND user_id = :user_id
           AND status = 'active'
         LIMIT 1"
    );

    $accountQuery->execute([
        ':id' => $accountId,
        ':user_id' => $userId
    ]);

    $account = $accountQuery->fetch();

    if (!$account) {
        respond([
            'success' => false,
            'message' => 'Withdrawal account not found.'
        ], 404);
    }

    $method = (string) $account['method'];
    $currency = strtoupper((string) $account['currency']);

    $settingsQuery = $pdo->prepare(
        "SELECT
            method,
            currency,
            minimum_amount,
            maximum_amount,
            fee_type,
            fee,
            processing_time
         FROM withdrawal_settings
         WHERE method = :method
           AND currency = :currency
           AND status = 'active'
         LIMIT 1"
    );

    $settingsQuery->execute([
        ':method' => $method,
        ':currency' => $currency
    ]);

    $settings = $settingsQuery->fetch();

    if (!$settings) {
        respond([
            'success' => false,
            'message' => 'Withdrawal settings are not available for this method.'
        ], 400);
    }

    $minimumAmount = (float) $settings['minimum_amount'];
    $maximumAmount = (float) $settings['maximum_amount'];
    $feeType = (string) $settings['fee_type'];
    $feeValue = (float) $settings['fee'];

    $fee = 0.00;

    if ($amount > 0) {
        if ($feeType === 'percentage') {
            $fee = ($amount * $feeValue) / 100;
        } else {
            $fee = $feeValue;
        }
    }

    $total = $amount + $fee;

    $accountDetails = [];

    $accountDetails[] = [
        'label' => 'Account Name',
        'value' => (string) $account['account_name']
    ];

    if ($method === 'Bank Transfer') {
        $accountDetails[] = [
            'label' => 'Bank Name',
            'value' => (string) $account['bank_name']
        ];

        $accountDetails[] = [
            'label' => 'Account Number',
            'value' => (string) $account['account_number']
        ];

        if (!empty($account['bank_code'])) {
            $accountDetails[] = [
                'label' => 'Bank Code',
                'value' => (string) $account['bank_code']
            ];
        }
    } else {
        $accountDetails[] = [
            'label' => 'Wallet Address',
            'value' => (string) $account['wallet_address']
        ];

        if (!empty($account['network'])) {
            $accountDetails[] = [
                'label' => 'Network',
                'value' => (string) $account['network']
            ];
        }
    }

    $accountDetails[] = [
        'label' => 'Currency',
        'value' => $currency
    ];

    $html = '';

    foreach ($accountDetails as $detail) {
        $html .= '<tr>';
        $html .= '<td class="detailsCol">' .
            htmlspecialchars(
                $detail['label'],
                ENT_QUOTES,
                'UTF-8'
            ) .
            '</td>';
        $html .= '<td>' .
            htmlspecialchars(
                $detail['value'],
                ENT_QUOTES,
                'UTF-8'
            ) .
            '</td>';
        $html .= '</tr>';
    }

    respond([
        'success' => true,
        'html' => $html,
        'info' => [
            'range' => $currency . ' ' .
                number_format($minimumAmount, 2) .
                ' - ' .
                $currency . ' ' .
                number_format($maximumAmount, 2),

            'processing_time' => (string) $settings['processing_time'],

            'charge_type' => $feeType,

            'charge' => $feeValue,

            'fee' => number_format($fee, 2, '.', ''),

            'total' => number_format($total, 2, '.', ''),

            'currency' => $currency
        ],
        'account' => [
            'id' => (int) $account['id'],
            'method' => $method,
            'account_name' => (string) $account['account_name']
        ]
    ]);

} catch (Throwable $e) {
    respond([
        'success' => false,
        'message' => 'Unable to load withdrawal details.'
    ], 500);
}