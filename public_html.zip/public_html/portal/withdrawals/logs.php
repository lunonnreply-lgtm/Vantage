<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Withdraw Log';
$activeMenu = 'withdrawals-logs';
$canonicalPath = '/portal/withdrawals/logs';

$extraStyles = <<<'HTML'
    <style>

        .withdrawal-log-search {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .withdrawal-log-search input {
            min-height: 45px;
            padding: 0 15px;
            border: 1px solid rgba(128, 128, 128, 0.25);
            border-radius: 5px;
            background: transparent;
        }

        .withdrawal-log-search .apply-btn {
            min-height: 45px;
            padding: 0 25px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
        }

        .withdrawal-log-empty {
            text-align: center;
            padding: 35px 15px !important;
        }

    </style>
HTML;

/*
|--------------------------------------------------------------------------
| Withdrawal log filters
|--------------------------------------------------------------------------
*/
$search = trim((string) ($_GET['query'] ?? ''));
$date = trim((string) ($_GET['date'] ?? ''));

$sql = '
    SELECT
        reference,
        amount,
        currency,
        status,
        created_at
    FROM financial_requests
    WHERE user_id = :user_id
      AND type = :type
';

$params = [
    'user_id' => $userId,
    'type' => 'withdrawal'
];

if ($search !== '') {
    $sql .= ' AND (reference LIKE :search OR status LIKE :search)';
    $params['search'] = '%' . $search . '%';
}

if ($date !== '') {
    $sql .= ' AND DATE(created_at) = :request_date';
    $params['request_date'] = $date;
}

$sql .= ' ORDER BY created_at DESC LIMIT 250';

$withdrawalQuery = $pdo->prepare($sql);
$withdrawalQuery->execute($params);

$withdrawals = $withdrawalQuery->fetchAll();

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="site-card">

            <div class="site-card-header">
                <h3 class="title">All Withdraw Log</h3>
            </div>

            <div class="site-card-body">

                <div class="site-table">

                    <form action="/portal/withdrawals/logs" method="get">
                        <div class="withdrawal-log-search">

                            <input
                                type="text"
                                name="query"
                                placeholder="Search reference or status"
                                value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
                            >

                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars($date, ENT_QUOTES, 'UTF-8') ?>"
                            >

                            <button type="submit" class="apply-btn">Search</button>

                        </div>
                    </form>


                    <div class="table-responsive">

                        <table class="table table-hover">

                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Transaction ID</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>

                            <tbody>

                            <?php if ($withdrawals): ?>

                                <?php foreach ($withdrawals as $withdrawal): ?>

                                    <tr>

                                        <td>
                                            <div class="table-description">

                                                <div class="icon">
                                                    <i class="anticon anticon-arrow-up"></i>
                                                </div>

                                                <div class="description">
                                                    <strong>Withdrawal request</strong>
                                                </div>

                                            </div>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= htmlspecialchars((string) $withdrawal['reference'], ENT_QUOTES, 'UTF-8') ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= htmlspecialchars((string) $withdrawal['currency'], ENT_QUOTES, 'UTF-8') ?>
                                                <?= number_format((float) $withdrawal['amount'], 2) ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <div class="site-badge">
                                                <?= htmlspecialchars(ucfirst((string) $withdrawal['status']), ENT_QUOTES, 'UTF-8') ?>
                                            </div>
                                        </td>

                                        <td>
                                            <?= htmlspecialchars((string) $withdrawal['created_at'], ENT_QUOTES, 'UTF-8') ?>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <tr class="centered">
                                    <td colspan="5" class="withdrawal-log-empty">
                                        No withdrawal records found.
                                    </td>
                                </tr>

                            <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>