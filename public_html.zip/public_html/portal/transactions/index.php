<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'All Transactions';
$activeMenu = 'transactions';
$canonicalPath = '/portal/transactions';

$transactionQuery = $pdo->prepare(
    'SELECT
        l.type,
        l.amount,
        l.currency,
        l.status,
        l.description,
        l.created_at,
        a.wallet_type
     FROM ledger_transactions l
     JOIN accounts a ON a.id = l.account_id
     WHERE l.user_id = :user_id
     ORDER BY l.created_at DESC
     LIMIT 250'
);
$transactionQuery->execute(['user_id' => $userId]);
$transactions = $transactionQuery->fetchAll();

$extraStyles = <<<'HTML'
    <style>

        .transactions-page-card {
            width: 100%;
            overflow: hidden;
        }

        .transactions-table-wrapper {
            width: 100%;
            overflow-x: auto;
            -webkit-overflow-scrolling: touch;
        }

        .transactions-table {
            width: 100% !important;
            min-width: 850px;
            border-collapse: separate !important;
            border-spacing: 0;
            margin: 0 !important;
        }

        .transactions-table thead th {
            padding: 16px 18px !important;
            font-size: 13px;
            font-weight: 600;
            text-transform: uppercase;
            letter-spacing: 0.3px;
            white-space: nowrap;
            border-bottom: 1px solid rgba(128, 128, 128, 0.2) !important;
        }

        .transactions-table tbody td {
            padding: 17px 18px !important;
            font-size: 14px;
            vertical-align: middle !important;
            border-bottom: 1px solid rgba(128, 128, 128, 0.12) !important;
            white-space: nowrap;
        }

        .transactions-table tbody tr:last-child td {
            border-bottom: 0 !important;
        }

        .transactions-table tbody tr {
            transition: background-color 0.2s ease;
        }

        .transactions-table tbody tr:hover {
            background: rgba(128, 128, 128, 0.06);
        }

        .transactions-table td:first-child {
            font-size: 13px;
            opacity: 0.8;
            min-width: 155px;
        }

        .transactions-table td:nth-child(2) {
            font-weight: 600;
            min-width: 135px;
        }

        .transaction-description {
            white-space: normal !important;
            min-width: 220px;
            max-width: 320px;
            line-height: 1.5;
        }

        .transactions-table td:nth-child(4) {
            min-width: 110px;
            text-transform: capitalize;
        }

        .transactions-table td:nth-child(5) {
            min-width: 130px;
            font-weight: 700;
        }

        .transaction-status {
            display: inline-flex;
            align-items: center;
            justify-content: center;
            min-width: 82px;
            padding: 6px 12px;
            border-radius: 5px;
            font-size: 12px;
            font-weight: 600;
            line-height: 1;
            text-transform: capitalize;
            border: 1px solid transparent;
        }

        .transaction-status.completed,
        .transaction-status.success,
        .transaction-status.approved,
        .transaction-status.settled {
            background: rgba(40, 167, 69, 0.12);
            color: #28a745;
            border-color: rgba(40, 167, 69, 0.18);
        }

        .transaction-status.pending {
            background: rgba(255, 193, 7, 0.12);
            color: #ffc107;
            border-color: rgba(255, 193, 7, 0.18);
        }

        .transaction-status.failed,
        .transaction-status.rejected,
        .transaction-status.cancelled {
            background: rgba(220, 53, 69, 0.12);
            color: #dc3545;
            border-color: rgba(220, 53, 69, 0.18);
        }

        .transaction-status.processing {
            background: rgba(0, 123, 255, 0.12);
            color: #007bff;
            border-color: rgba(0, 123, 255, 0.18);
        }

        .empty-transactions {
            text-align: center !important;
            padding: 55px 20px !important;
            font-size: 14px;
            opacity: 0.7;
        }

        @media (max-width: 767px) {

            .transactions-page-card {
                border-radius: 8px;
            }

            .transactions-table-wrapper {
                margin: 0 -5px;
                padding-bottom: 5px;
            }

            .transactions-table {
                min-width: 780px;
            }

            .transactions-table thead th {
                padding: 13px 14px !important;
                font-size: 11px;
            }

            .transactions-table tbody td {
                padding: 14px !important;
                font-size: 13px;
            }

            .transaction-description {
                min-width: 190px;
                max-width: 260px;
            }

            .transaction-status {
                min-width: 75px;
                padding: 5px 9px;
                font-size: 11px;
            }

        }

    </style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">

    <div class="col-xl-12">

        <div class="site-card transactions-page-card">

            <div class="site-card-header">
                <h3 class="title">All Transactions</h3>
            </div>

            <div class="site-card-body">

                <div class="transactions-table-wrapper">

                    <table class="display data-table transactions-table">

                        <thead>
                            <tr>
                                <th>Date</th>
                                <th>Type</th>
                                <th>Description</th>
                                <th>Wallet</th>
                                <th>Amount</th>
                                <th>Status</th>
                            </tr>
                        </thead>

                        <tbody>

                        <?php if ($transactions): ?>

                            <?php foreach ($transactions as $transaction): ?>

                                <?php

                                $transactionType = ucwords(str_replace('_', ' ', (string) $transaction['type']));
                                $walletType = ucfirst((string) $transaction['wallet_type']);
                                $status = strtolower((string) $transaction['status']);
                                $statusLabel = ucfirst((string) $transaction['status']);

                                ?>

                                <tr>
                                    <td><?= htmlspecialchars((string) $transaction['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= htmlspecialchars($transactionType, ENT_QUOTES, 'UTF-8') ?></td>
                                    <td class="transaction-description"><?= htmlspecialchars((string) $transaction['description'], ENT_QUOTES, 'UTF-8') ?></td>
                                    <td><?= htmlspecialchars($walletType, ENT_QUOTES, 'UTF-8') ?></td>
                                    <td>
                                        <?= htmlspecialchars((string) $transaction['currency'], ENT_QUOTES, 'UTF-8') ?>
                                        <?= number_format((float) $transaction['amount'], 2) ?>
                                    </td>
                                    <td>
                                        <span class="transaction-status <?= htmlspecialchars($status, ENT_QUOTES, 'UTF-8') ?>">
                                            <?= htmlspecialchars($statusLabel, ENT_QUOTES, 'UTF-8') ?>
                                        </span>
                                    </td>
                                </tr>

                            <?php endforeach; ?>

                        <?php else: ?>

                            <tr>
                                <td colspan="6" class="empty-transactions">No transactions found.</td>
                            </tr>

                        <?php endif; ?>

                        </tbody>

                    </table>

                </div>

            </div>

        </div>

    </div>

</div>

<?php require __DIR__ . '/../_footer.php'; ?>