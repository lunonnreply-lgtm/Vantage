<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Wallet Exchange';
$activeMenu = 'wallet-exchange';
$canonicalPath = '/portal/wallet/exchange';

$success = isset($_GET['success']) && $_GET['success'] === '1';
$reference = isset($_GET['reference'])
    ? trim((string) $_GET['reference'])
    : '';

$successAmount = '0.00';
$successFromWallet = '-';
$successToWallet = '-';
$successStatus = 'Completed';

if ($success && $reference !== '') {
    $successQuery = $pdo->prepare(
        "SELECT
            lt.amount,
            lt.account_id,
            lt.description,
            a.wallet_type
         FROM ledger_transactions lt
         INNER JOIN accounts a
             ON a.id = lt.account_id
         WHERE lt.user_id = :user_id
           AND lt.type = 'wallet_exchange'
           AND lt.currency = 'USD'
           AND lt.description LIKE :reference_search
         ORDER BY lt.id ASC"
    );

    $successQuery->execute([
        'user_id' => $userId,
        'reference_search' => '%' . $reference
    ]);

    $exchangeEntries = $successQuery->fetchAll();

    foreach ($exchangeEntries as $entry) {
        $entryAmount = (float) $entry['amount'];

        if ($entryAmount < 0) {
            $successAmount = number_format(
                abs($entryAmount),
                2,
                '.',
                ','
            );

            $successFromWallet =
                ucfirst((string) $entry['wallet_type']) . ' Wallet';
        }

        if ($entryAmount > 0) {
            $successToWallet =
                ucfirst((string) $entry['wallet_type']) . ' Wallet';
        }
    }
}

$walletQuery = $pdo->prepare(
    "SELECT
        id,
        wallet_type,
        available_balance,
        restricted_balance,
        currency
     FROM accounts
     WHERE user_id = :user_id
       AND currency = 'USD'
       AND wallet_type IN ('main', 'profit')
     ORDER BY id ASC"
);

$walletQuery->execute([
    'user_id' => $userId
]);

$wallets = $walletQuery->fetchAll();

$mainWallet = null;
$profitWallet = null;

foreach ($wallets as $wallet) {
    if ($wallet['wallet_type'] === 'main') {
        $mainWallet = $wallet;
    }

    if ($wallet['wallet_type'] === 'profit') {
        $profitWallet = $wallet;
    }
}

$mainWalletId = $mainWallet !== null
    ? (int) $mainWallet['id']
    : 0;

$profitWalletId = $profitWallet !== null
    ? (int) $profitWallet['id']
    : 0;

$mainBalance = $mainWallet !== null
    ? number_format(
        max(0, (float) $mainWallet['available_balance'] - (float) $mainWallet['restricted_balance']),
        2,
        '.',
        ','
    )
    : '0.00';

$profitBalance = $profitWallet !== null
    ? number_format(
        max(0, (float) $profitWallet['available_balance'] - (float) $profitWallet['restricted_balance']),
        2,
        '.',
        ','
    )
    : '0.00';

$profitLockedBalance = $profitWallet !== null
    ? number_format(
        (float) $profitWallet['restricted_balance'],
        2,
        '.',
        ','
    )
    : '0.00';

$extraStyles = <<<'HTML'
<style>
.wallet-exchange-success {
    display: block;
}

.wallet-exchange-success-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 25px;
    border: 3px solid #28a745;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
    line-height: 1;
    color: #28a745;
}

.wallet-exchange-success-message {
    text-align: center;
    margin-bottom: 30px;
}

.wallet-exchange-error {
    margin-bottom: 20px;
}
</style>
HTML;

$extraScripts = <<<'HTML'
<script>
(function () {
    "use strict";

    var amountInput = document.getElementById('amount');

    if (!amountInput) {
        return;
    }

    var currency = "USD";
    var chargeType = "percentage";
    var charge = "0";

    function updateReview() {
        var amount = parseFloat(amountInput.value) || 0;

        var finalCharge =
            chargeType === 'percentage'
                ? calPercentage(amount, charge)
                : parseFloat(charge) || 0;

        var amountElement =
            document.querySelector('.amount');

        var currencyElements =
            document.querySelectorAll('.currency');

        var chargeElement =
            document.querySelector('.charge2');

        var totalElement =
            document.querySelector('.total');

        var chargeInfo =
            document.querySelector('.charge');

        if (amountElement) {
            amountElement.textContent =
                Number(amount).toFixed(2);
        }

        currencyElements.forEach(function (element) {
            element.textContent = currency;
        });

        if (chargeElement) {
            chargeElement.textContent =
                Number(finalCharge).toFixed(2) +
                ' ' +
                currency;
        }

        if (totalElement) {
            totalElement.textContent =
                (
                    Number(amount) +
                    Number(finalCharge)
                ).toFixed(2) +
                ' ' +
                currency;
        }

        if (chargeInfo) {
            chargeInfo.textContent =
                'Charge ' +
                charge +
                (
                    chargeType === 'percentage'
                        ? ' % '
                        : ' ' + currency
                );
        }
    }

    amountInput.addEventListener(
        'input',
        updateReview
    );

    updateReview();
})();
</script>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="site-card">

            <div class="site-card-header">

                <h3 class="title">
                    Wallet Exchange
                </h3>

            </div>

            <div class="site-card-body">

                <?php if ($success): ?>

                    <div class="wallet-exchange-success">

                        <div class="progress-steps">

                            <div class="single-step">

                                <div class="number">
                                    01
                                </div>

                                <div class="content">

                                    <h4>
                                        Wallet Details
                                    </h4>

                                    <p>
                                        Enter your Wallet details
                                    </p>

                                </div>

                            </div>

                            <div class="single-step current">

                                <div class="number">
                                    02
                                </div>

                                <div class="content">

                                    <h4>
                                        Success
                                    </h4>

                                    <p>
                                        Successfully Exchanged
                                    </p>

                                </div>

                            </div>

                        </div>

                        <div class="progress-steps-form">

                            <div class="wallet-exchange-success-icon">
                                ✓
                            </div>

                            <div class="wallet-exchange-success-message">

                                <h2>
                                    Successfully Exchanged
                                </h2>

                                <p>
                                    Your wallet exchange has been completed successfully.
                                </p>

                            </div>

                            <div class="transaction-list table-responsive">

                                <div class="user-panel-title">

                                    <h3>
                                        Transaction ID:
                                    </h3>

                                </div>

                                <table class="table">

                                    <tbody>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Transaction ID
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $reference,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Amount
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $successAmount,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                                USD
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    From Wallet
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $successFromWallet,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    To Wallet
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $successToWallet,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Status
                                                </strong>
                                            </td>

                                            <td>
                                                <?= htmlspecialchars(
                                                    $successStatus,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </td>

                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                            <div class="user-panel-title">

                                <h3>
                                    Success
                                </h3>

                                <p>
                                    Your wallet exchange was processed successfully.
                                </p>

                            </div>

                            <div class="buttons">

                                <a
                                    href="/portal/wallet/exchange"
                                    class="site-btn blue-btn"
                                >
                                    Exchange Again
                                </a>

                            </div>

                        </div>

                    </div>

                <?php else: ?>

                    <div class="progress-steps">

                        <div class="single-step current">

                            <div class="number">
                                01
                            </div>

                            <div class="content">

                                <h4>
                                    Wallet Details
                                </h4>

                                <p>
                                    Enter your Wallet details
                                </p>

                            </div>

                        </div>

                        <div class="single-step">

                            <div class="number">
                                02
                            </div>

                            <div class="content">

                                <h4>
                                    Success
                                </h4>

                                <p>
                                    Successfully Exchanged
                                </p>

                            </div>

                        </div>

                    </div>

                    <div class="progress-steps-form">

                        <form
                            action="/portal/wallet/exchange-now"
                            method="post"
                        >

                            <input
                                type="hidden"
                                name="csrf_token"
                                value="<?= htmlspecialchars(
                                    $_SESSION['csrf_token'] ?? '',
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                            <div class="row">

                                <div class="col-xl-4 col-md-12">

                                    <label class="form-label">
                                        From Wallet:
                                    </label>

                                    <div class="input-group">

                                        <select
                                            name="from_wallet"
                                            class="site-nice-select"
                                            required
                                        >

                                            <option
                                                value="<?= $mainWalletId ?>"
                                                <?= $mainWalletId > 0 ? '' : 'disabled' ?>
                                            >
                                                Main Wallet
                                                (<?= $mainBalance ?> USD)
                                            </option>

                                            <option
                                                value="<?= $profitWalletId ?>"
                                                <?= $profitWalletId > 0 ? 'selected' : 'disabled' ?>
                                            >
                                                Profit Wallet
                                                (<?= $profitBalance ?> USD available, <?= $profitLockedBalance ?> USD locked)
                                            </option>

                                        </select>

                                    </div>

                                </div>

                                <div class="col-xl-4 col-md-12">

                                    <label
                                        for="amount"
                                        class="form-label"
                                    >
                                        Enter Amount:
                                    </label>

                                    <div class="input-group">

                                        <input
                                            type="text"
                                            name="amount"
                                            class="form-control"
                                            oninput="this.value = validateDouble(this.value)"
                                            aria-label="Amount"
                                            id="amount"
                                            aria-describedby="basic-addon1"
                                            required
                                        >

                                        <span
                                            class="input-group-text"
                                            id="basic-addon1"
                                        >
                                            USD
                                        </span>

                                    </div>

                                    <div class="input-info-text charge"></div>

                                </div>

                                <div class="col-xl-4 col-md-12">

                                    <label class="form-label">
                                        To Wallet:
                                    </label>

                                    <div class="input-group">

                                        <select
                                            name="to_wallet"
                                            class="site-nice-select"
                                            required
                                        >

                                            <option
                                                selected
                                                value="<?= $mainWalletId ?>"
                                                <?= $mainWalletId > 0 ? '' : 'disabled' ?>
                                            >
                                                Main Wallet
                                                (<?= $mainBalance ?> USD)
                                            </option>

                                            <option
                                                value="<?= $profitWalletId ?>"
                                                <?= $profitWalletId > 0 ? '' : 'disabled' ?>
                                            >
                                                Profit Wallet
                                                (<?= $profitBalance ?> USD available, <?= $profitLockedBalance ?> USD locked)
                                            </option>

                                        </select>

                                    </div>

                                </div>

                            </div>

                            <div class="transaction-list table-responsive">

                                <div class="user-panel-title">

                                    <h3>
                                        Review Details:
                                    </h3>

                                </div>

                                <table class="table">

                                    <tbody>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Amount
                                                </strong>
                                            </td>

                                            <td>
                                                <span class="amount">
                                                    0.00
                                                </span>

                                                <span class="currency">
                                                    USD
                                                </span>
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Charge
                                                </strong>
                                            </td>

                                            <td class="charge2">
                                                0.00 USD
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Total
                                                </strong>
                                            </td>

                                            <td class="total">
                                                0.00 USD
                                            </td>

                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                            <div class="buttons">

                                <button
                                    type="submit"
                                    class="site-btn blue-btn"
                                >
                                    Proceed to Exchange
                                    <i class="anticon anticon-double-right"></i>
                                </button>

                            </div>

                        </form>

                    </div>

                <?php endif; ?>

            </div>

        </div>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>