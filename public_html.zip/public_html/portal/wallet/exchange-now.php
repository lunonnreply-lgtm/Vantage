<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /portal/wallet/exchange');
    exit;
}

$sessionToken = $_SESSION['csrf_token'] ?? '';
$requestToken = isset($_POST['csrf_token'])
    ? (string) $_POST['csrf_token']
    : '';

if (
    !is_string($sessionToken) ||
    $sessionToken === '' ||
    $requestToken === '' ||
    !hash_equals($sessionToken, $requestToken)
) {
    http_response_code(419);
    exit('Invalid security token. Refresh the page and try again.');
}

$fromWalletId = filter_var(
    $_POST['from_wallet'] ?? null,
    FILTER_VALIDATE_INT
);

$toWalletId = filter_var(
    $_POST['to_wallet'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$fromWalletId || !$toWalletId) {
    header('Location: /portal/wallet/exchange?error=invalid-wallet');
    exit;
}

if ($fromWalletId === $toWalletId) {
    header('Location: /portal/wallet/exchange?error=same-wallet');
    exit;
}

$rawAmount = trim((string) ($_POST['amount'] ?? ''));

if (
    $rawAmount === '' ||
    !preg_match(
        '/^(?:0|[1-9]\d{0,11})(?:\.\d{1,2})?$/',
        $rawAmount
    )
) {
    header('Location: /portal/wallet/exchange?error=invalid-amount');
    exit;
}

$amount = number_format(
    (float) $rawAmount,
    2,
    '.',
    ''
);

if ((float) $amount <= 0) {
    header('Location: /portal/wallet/exchange?error=invalid-amount');
    exit;
}

$currency = 'USD';

$chargeType = 'percentage';
$charge = 0.00;

try {

    $pdo->beginTransaction();

    $fromQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            wallet_type,
            available_balance,
            restricted_balance,
            currency
         FROM accounts
         WHERE id = :from_wallet_id
           AND user_id = :from_user_id
           AND currency = 'USD'
           AND wallet_type IN ('main', 'profit')
         FOR UPDATE"
    );

    $fromQuery->execute([
        'from_wallet_id' => $fromWalletId,
        'from_user_id' => $userId
    ]);

    $fromWallet = $fromQuery->fetch();

    if (!$fromWallet) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=invalid-source-wallet'
        );

        exit;
    }

    $toQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            wallet_type,
            available_balance,
            restricted_balance,
            currency
         FROM accounts
         WHERE id = :to_wallet_id
           AND user_id = :to_user_id
           AND currency = 'USD'
           AND wallet_type IN ('main', 'profit')
         FOR UPDATE"
    );

    $toQuery->execute([
        'to_wallet_id' => $toWalletId,
        'to_user_id' => $userId
    ]);

    $toWallet = $toQuery->fetch();

    if (!$toWallet) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=invalid-destination-wallet'
        );

        exit;
    }

    $availableBalance = max(
        0,
        (float) $fromWallet['available_balance'] - (float) $fromWallet['restricted_balance']
    );

    $exchangeAmount =
        (float) $amount;

    if ($availableBalance < $exchangeAmount) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=insufficient-balance'
        );

        exit;
    }

    if ($chargeType === 'percentage') {

        $exchangeCharge = round(
            $exchangeAmount * ($charge / 100),
            2
        );

    } else {

        $exchangeCharge = round(
            $charge,
            2
        );
    }

    $totalDebit = round(
        $exchangeAmount + $exchangeCharge,
        2
    );

    if ($availableBalance < $totalDebit) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=insufficient-balance'
        );

        exit;
    }

    $debitQuery = $pdo->prepare(
        "UPDATE accounts
         SET available_balance =
             available_balance - :debit_amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type IN ('main', 'profit')
                     AND available_balance - restricted_balance >= :required_balance"
    );

    $debitQuery->execute([
        'debit_amount' => number_format(
            $totalDebit,
            2,
            '.',
            ''
        ),
        'account_id' => $fromWalletId,
        'user_id' => $userId,
        'required_balance' => number_format(
            $totalDebit,
            2,
            '.',
            ''
        )
    ]);

    if ($debitQuery->rowCount() !== 1) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=balance-changed'
        );

        exit;
    }

    $creditQuery = $pdo->prepare(
        "UPDATE accounts
         SET available_balance =
             available_balance + :credit_amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type IN ('main', 'profit')"
    );

    $creditQuery->execute([
        'credit_amount' => number_format(
            $exchangeAmount,
            2,
            '.',
            ''
        ),
        'account_id' => $toWalletId,
        'user_id' => $userId
    ]);

    if ($creditQuery->rowCount() !== 1) {

        $pdo->rollBack();

        header(
            'Location: /portal/wallet/exchange?error=credit-failed'
        );

        exit;
    }

    $reference = 'EXC-' . strtoupper(
        bin2hex(random_bytes(8))
    );

    $debitLedger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'wallet_exchange',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $debitLedger->execute([
        'user_id' => $userId,
        'account_id' => $fromWalletId,
        'amount' => '-' . number_format(
            $totalDebit,
            2,
            '.',
            ''
        ),
        'description' =>
            'Wallet exchange debit ' . $reference
    ]);

    $creditLedger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'wallet_exchange',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $creditLedger->execute([
        'user_id' => $userId,
        'account_id' => $toWalletId,
        'amount' => number_format(
            $exchangeAmount,
            2,
            '.',
            ''
        ),
        'description' =>
            'Wallet exchange credit ' . $reference
    ]);

    if ($exchangeCharge > 0) {

        $chargeLedger = $pdo->prepare(
            "INSERT INTO ledger_transactions (
                user_id,
                account_id,
                type,
                amount,
                currency,
                status,
                description
            ) VALUES (
                :user_id,
                :account_id,
                'wallet_exchange_charge',
                :amount,
                'USD',
                'completed',
                :description
            )"
        );

        $chargeLedger->execute([
            'user_id' => $userId,
            'account_id' => $fromWalletId,
            'amount' => '-' . number_format(
                $exchangeCharge,
                2,
                '.',
                ''
            ),
            'description' =>
                'Wallet exchange charge ' . $reference
        ]);
    }

    $pdo->commit();

    header(
        'Location: /portal/wallet/exchange?success=1' .
        '&reference=' .
        urlencode($reference)
    );

    exit;

} catch (Throwable $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    header(
        'Location: /portal/wallet/exchange?error=exchange-failed'
    );

    exit;
}