<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Schema Logs';
$activeMenu = 'investments-logs';
$canonicalPath = '/portal/investments/logs';

$extraStyles = <<<'HTML'
<style>
.schema-log-table {
    width: 100%;
    min-width: 980px;
}

.schema-log-table th,
.schema-log-table td {
    vertical-align: middle;
    white-space: nowrap;
}

.schema-name {
    white-space: normal !important;
    min-width: 170px;
}

.schema-status {
    display: inline-block;
    padding: 5px 10px;
    border-radius: 5px;
    font-size: 12px;
    text-transform: capitalize;
}

.schema-status.active,
.schema-status.completed,
.schema-status.matured,
.schema-status.released,
.schema-status.success {
    background: rgba(40, 167, 69, 0.15);
    color: #28a745;
}

.schema-status.pending,
.schema-status.processing {
    background: rgba(255, 193, 7, 0.15);
    color: #ffc107;
}

.schema-status.failed,
.schema-status.cancelled,
.schema-status.rejected {
    background: rgba(220, 53, 69, 0.15);
    color: #dc3545;
}

.empty-schema-logs {
    text-align: center;
    padding: 40px 20px !important;
}

.released-date {
    display: block;
    margin-top: 4px;
    font-size: 11px;
    opacity: 0.75;
}

.schema-cancel-cell {
    min-width: 150px;
}

.schema-cancel-wrap {
    display: flex;
    flex-direction: column;
    align-items: flex-start;
    gap: 5px;
}

.schema-cancel-btn {
    border: 1px solid rgba(220, 53, 69, 0.45);
    background: rgba(220, 53, 69, 0.08);
    color: #dc3545;
    padding: 6px 12px;
    border-radius: 5px;
    font-size: 12px;
    line-height: 1.2;
    cursor: pointer;
    transition: all 0.2s ease;
}

.schema-cancel-btn:hover {
    background: rgba(220, 53, 69, 0.16);
    border-color: rgba(220, 53, 69, 0.7);
}

.schema-cancel-btn:disabled {
    opacity: 0.55;
    cursor: not-allowed;
}

.schema-cancel-time {
    font-size: 11px;
    opacity: 0.7;
}

.schema-cancel-expired {
    font-size: 11px;
    opacity: 0.55;
}

.schema-cancel-message {
    display: none;
    margin-bottom: 18px;
    padding: 10px 14px;
    border-radius: 5px;
    font-size: 13px;
}

.schema-cancel-message.success {
    display: block;
    background: rgba(40, 167, 69, 0.12);
    color: #28a745;
}

.schema-cancel-message.error {
    display: block;
    background: rgba(220, 53, 69, 0.12);
    color: #dc3545;
}
</style>
HTML;

$query = $pdo->prepare(
    'SELECT
        i.id,
        i.reference,
        i.principal,
        i.expected_return,
        i.currency,
        i.starts_at,
        i.matures_at,
        i.status,
        i.released_at,
        i.created_at,
        p.name AS plan_name,
        p.return_rate,
        p.term_days,
        p.cancel_minutes,
        p.capital_back
     FROM investments i
     INNER JOIN investment_plans p
        ON p.id = i.plan_id
     WHERE i.user_id = :user_id
       AND i.currency = \'USD\'
     ORDER BY i.created_at DESC'
);

$query->execute([
    'user_id' => $userId
]);

$investments = $query->fetchAll();

require __DIR__ . '/../_header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4">

    <h2>
        Schema Logs
    </h2>

    <a
        class="user-sidebar-btn"
        href="/portal/investments"
    >
        Invest Now
    </a>

</div>

<div
    id="schemaCancelMessage"
    class="schema-cancel-message"
></div>

<div class="site-card">

    <div class="site-card-header">

        <h3 class="title">
            All Invested Schemas
        </h3>

    </div>

    <div class="site-card-body">

        <div class="table-responsive">

            <table class="display data-table schema-log-table">

                <thead>

                    <tr>

                        <th>
                            Reference
                        </th>

                        <th>
                            Schema
                        </th>

                        <th>
                            Principal
                        </th>

                        <th>
                            Return
                        </th>

                        <th>
                            Matures
                        </th>

                        <th>
                            Status
                        </th>

                        <th>
                            Action
                        </th>

                    </tr>

                </thead>

                <tbody>

                <?php if ($investments): ?>

                    <?php foreach ($investments as $investment): ?>

                        <?php
                        $status = strtolower(
                            (string) $investment['status']
                        );

                        $cancelMinutes = (int) $investment['cancel_minutes'];

                        $startsAtTimestamp = strtotime(
                            (string) $investment['starts_at']
                        );

                        $cancelDeadlineTimestamp = $startsAtTimestamp
                            + ($cancelMinutes * 60);

                        $canCancel = (
                            $status === 'active'
                            && $cancelMinutes > 0
                            && time() <= $cancelDeadlineTimestamp
                        );
                        ?>

                        <tr
                            data-investment-row="<?= (int) $investment['id'] ?>"
                        >

                            <td>
                                <?= htmlspecialchars(
                                    (string) $investment['reference'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </td>

                            <td class="schema-name">

                                <?= htmlspecialchars(
                                    (string) $investment['plan_name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                                
                            </td>

                            <td>

                                USD

                                <?= number_format(
                                    (float) $investment['principal'],
                                    2
                                ) ?>

                            </td>

                            <td>

                                USD

                                <?= number_format(
                                    (float) $investment['expected_return'],
                                    2
                                ) ?>

                            </td>

                            <td>

                                <?= htmlspecialchars(
                                    (string) $investment['matures_at'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </td>

                            <td>

                                <span
                                    class="schema-status <?= htmlspecialchars(
                                        $status,
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                >

                                    <?= htmlspecialchars(
                                        ucfirst($status),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>

                                </span>

                                <?php if ($investment['released_at']): ?>

                                    <small class="released-date">

                                        Released:

                                        <?= htmlspecialchars(
                                            (string) $investment['released_at'],
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ) ?>

                                    </small>

                                <?php endif; ?>

                            </td>

                            <td class="schema-cancel-cell">

                                <?php if ($canCancel): ?>

                                    <div
                                        class="schema-cancel-wrap"
                                        data-cancel-deadline="<?= (int) $cancelDeadlineTimestamp ?>"
                                    >

                                        <button
                                            type="button"
                                            class="schema-cancel-btn"
                                            data-investment-id="<?= (int) $investment['id'] ?>"
                                        >
                                            Cancel Investment
                                        </button>

                                        <span class="schema-cancel-time">
                                            <span class="cancel-countdown">
                                                Calculating...
                                            </span>
                                        </span>

                                    </div>

                                <?php elseif ($status === 'active'): ?>

                                    <span class="schema-cancel-expired">
                                        Cancellation expired
                                    </span>

                                <?php else: ?>

                                    <span class="schema-cancel-expired">
                                        —
                                    </span>

                                <?php endif; ?>

                            </td>

                        </tr>

                    <?php endforeach; ?>

                <?php else: ?>

                    <tr>

                        <td
                            colspan="7"
                            class="empty-schema-logs"
                        >
                            No investments have been created yet.
                        </td>

                    </tr>

                <?php endif; ?>

                </tbody>

            </table>

        </div>

    </div>

</div>

<script>
(function () {
    'use strict';

    var cancelMessage = document.getElementById('schemaCancelMessage');

    function showMessage(message, type) {
        if (!cancelMessage) {
            return;
        }

        cancelMessage.textContent = message;
        cancelMessage.className =
            'schema-cancel-message ' + type;
    }

    function hideMessage() {
        if (!cancelMessage) {
            return;
        }

        cancelMessage.textContent = '';
        cancelMessage.className = 'schema-cancel-message';
    }

    function getCsrfToken() {
        return fetch('/api/auth/csrf.php', {
            method: 'GET',
            credentials: 'same-origin',
            headers: {
                'Accept': 'application/json'
            }
        })
        .then(function (response) {
            return response.json().then(function (data) {
                if (!response.ok || !data.csrfToken) {
                    throw new Error(
                        data.error || 'Unable to obtain security token.'
                    );
                }

                return data.csrfToken;
            });
        });
    }

    function updateCountdowns() {
        var wrappers = document.querySelectorAll(
            '.schema-cancel-wrap'
        );

        var now = Math.floor(Date.now() / 1000);

        wrappers.forEach(function (wrapper) {
            var deadline = parseInt(
                wrapper.getAttribute('data-cancel-deadline'),
                10
            );

            var countdown = wrapper.querySelector(
                '.cancel-countdown'
            );

            var button = wrapper.querySelector(
                '.schema-cancel-btn'
            );

            if (!countdown || !button || !deadline) {
                return;
            }

            var remaining = deadline - now;

            if (remaining <= 0) {
                countdown.textContent = 'Cancellation expired';
                button.disabled = true;
                button.style.display = 'none';

                var expired = document.createElement('span');
                expired.className = 'schema-cancel-expired';
                expired.textContent = 'Cancellation expired';

                wrapper.innerHTML = '';
                wrapper.appendChild(expired);

                return;
            }

            var minutes = Math.floor(
                remaining / 60
            );

            var seconds = remaining % 60;

            countdown.textContent =
                'Available for ' +
                minutes +
                'm ' +
                String(seconds).padStart(2, '0') +
                's';
        });
    }

    document.querySelectorAll(
        '.schema-cancel-btn'
    ).forEach(function (button) {

        button.addEventListener('click', function () {

            var investmentId = button.getAttribute(
                'data-investment-id'
            );

            if (!investmentId) {
                return;
            }

            var confirmed = window.confirm(
                'Cancel this investment and refund the principal to your USD main wallet?'
            );

            if (!confirmed) {
                return;
            }

            hideMessage();

            button.disabled = true;
            button.textContent = 'Cancelling...';

            getCsrfToken()
                .then(function (csrfToken) {

                    return fetch(
                        '/api/user/investment-cancel.php',
                        {
                            method: 'POST',
                            credentials: 'same-origin',
                            headers: {
                                'Content-Type': 'application/json',
                                'Accept': 'application/json',
                                'X-CSRF-Token': csrfToken
                            },
                            body: JSON.stringify({
                                investmentId: parseInt(
                                    investmentId,
                                    10
                                )
                            })
                        }
                    );
                })
                .then(function (response) {

                    return response.json().then(
                        function (data) {

                            if (!response.ok) {
                                throw new Error(
                                    data.error ||
                                    'The investment could not be cancelled.'
                                );
                            }

                            return data;
                        }
                    );
                })
                .then(function (data) {

                    showMessage(
                        data.message ||
                        'Investment cancelled successfully.',
                        'success'
                    );

                    var row = document.querySelector(
                        '[data-investment-row="' +
                        investmentId +
                        '"]'
                    );

                    if (row) {

                        var status = row.querySelector(
                            '.schema-status'
                        );

                        if (status) {
                            status.textContent = 'Cancelled';
                            status.className =
                                'schema-status cancelled';
                        }

                        var actionCell = row.querySelector(
                            '.schema-cancel-cell'
                        );

                        if (actionCell) {
                            actionCell.innerHTML =
                                '<span class="schema-cancel-expired">—</span>';
                        }
                    }

                    window.setTimeout(function () {
                        window.location.reload();
                    }, 900);
                })
                .catch(function (error) {

                    button.disabled = false;
                    button.textContent = 'Cancel Investment';

                    showMessage(
                        error.message ||
                        'The investment could not be cancelled.',
                        'error'
                    );
                });
        });
    });

    updateCountdowns();

    window.setInterval(
        updateCountdowns,
        1000
    );
})();
</script>

<?php require __DIR__ . '/../_footer.php'; ?>