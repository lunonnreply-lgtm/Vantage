<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Investment Plans';
$activeMenu = 'investments';
$canonicalPath = '/portal/investments';

$extraStyles = <<<'HTML'
<style>
.investment-page-header {
    margin-bottom: 25px;
}

.investment-page-header h2 {
    margin: 0;
}

.investment-plans-grid {
    margin-left: -10px;
    margin-right: -10px;
}

.investment-plan-column {
    padding-left: 10px;
    padding-right: 10px;
    margin-bottom: 20px;
}

.investment-plan-card {
    position: relative;
    height: 100%;
    overflow: hidden;
    border: 1px solid rgba(236, 35, 116, 0.55);
    background: #102d38;
}

.investment-plan-card .site-card-body {
    position: relative;
    display: flex;
    flex-direction: column;
    min-height: 475px;
    padding: 28px 20px 30px;
}

.investment-plan-badge {
    position: absolute;
    top: 10px;
    right: 10px;
    padding: 4px 7px;
    border-radius: 5px;
    background: linear-gradient(135deg, #8f42d8, #ed3987);
    color: #fff;
    font-size: 10px;
    font-weight: 700;
    line-height: 1;
    text-transform: uppercase;
}

.investment-plan-icon {
    width: 42px;
    height: 42px;
    margin-bottom: 13px;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 31px;
    line-height: 1;
}

.investment-plan-card h3 {
    margin: 0;
    font-size: 21px;
    font-weight: 600;
}

.investment-plan-rate {
    margin: 3px 0 25px;
    color: #c8a82d;
    font-size: 12px;
    font-weight: 500;
}

.investment-plan-details {
    margin: 0 0 10px;
    padding: 0;
    list-style: none;
}

.investment-plan-details li {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    min-height: 34px;
    padding: 4px 0;
    border: 0;
    font-size: 12px;
}

.investment-plan-details li > span:first-child {
    color: #fff;
}

.investment-plan-details li > strong {
    color: #fff;
    font-weight: 400;
    text-align: right;
}

.investment-range {
    display: inline-block;
    padding: 5px 8px;
    border-radius: 6px;
    background: #237d7a;
    color: #fff !important;
    font-size: 11px;
    white-space: nowrap;
}

.investment-no-holidays {
    margin-top: 3px;
    margin-bottom: 24px;
    color: #c8a82d;
    font-size: 10px;
}

.investment-plan-action {
    margin-top: auto;
}

.investment-invest-button {
    width: 100%;
    min-height: 38px;
    border: 0;
    border-radius: 22px;
    background: linear-gradient(
        90deg,
        #ed2879 0%,
        #f34d52 50%,
        #ff9500 100%
    );
    color: #fff;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
    transition: opacity 0.2s ease, transform 0.2s ease;
}

.investment-invest-button:hover {
    opacity: 0.92;
    transform: translateY(-1px);
}

.investment-invest-button:focus {
    outline: none;
}

.investment-invest-button span {
    margin-right: 3px;
}

.investment-plan-form {
    display: none;
    margin-top: 15px;
    padding: 15px;
    border-radius: 8px;
    background: rgba(0, 0, 0, 0.18);
}

.investment-plan-form.is-open {
    display: block;
}

.investment-plan-form .form-label {
    color: #fff;
    font-size: 12px;
}

.investment-plan-form .form-control {
    font-size: 12px;
}

.investment-plan-form-actions {
    display: flex;
    gap: 8px;
    margin-top: 12px;
}

.investment-plan-form-actions button {
    flex: 1;
}

.investment-confirm-button {
    min-height: 36px;
    border: 0;
    border-radius: 5px;
    background: #ec2878;
    color: #fff;
    font-size: 11px;
    font-weight: 600;
    cursor: pointer;
}

.investment-cancel-button {
    min-height: 36px;
    border: 1px solid rgba(255,255,255,0.25);
    border-radius: 5px;
    background: transparent;
    color: #fff;
    font-size: 11px;
    cursor: pointer;
}

@media (max-width: 575px) {
    .investment-page-header {
        align-items: flex-start !important;
        flex-direction: column;
        gap: 15px;
    }

    .investment-plan-card .site-card-body {
        min-height: 460px;
    }

    .investment-plan-details li {
        min-height: 36px;
    }
}
</style>
HTML;

/*
 * All investment plans must be USD.
 */
$plans = $pdo->query(
    "SELECT
        id,
        name,
        description,
        currency,
        minimum_amount,
        maximum_amount,
        return_rate,
        term_days,
        capital_back,
        cancel_minutes
     FROM investment_plans
     WHERE status = 'active'
       AND currency = 'USD'
     ORDER BY id"
)->fetchAll();

/*
 * Load ONLY the logged-in user's actual USD main wallet.
 */
$walletQuery = $pdo->prepare(
    "SELECT
        id,
        currency,
        available_balance
     FROM accounts
     WHERE user_id = :user_id
       AND currency = 'USD'
       AND wallet_type = 'main'
     ORDER BY id
     LIMIT 1"
);

$walletQuery->execute([
    'user_id' => $userId,
]);

$wallet = $walletQuery->fetch();

require __DIR__ . '/../_header.php';
?><div class="d-flex justify-content-between align-items-center investment-page-header"><h2>
    Investment Plans
</h2>

<a
    class="user-sidebar-btn"
    href="/portal/investments/logs"
>
    Schema Logs
</a>

</div><div class="row investment-plans-grid"><?php foreach ($plans as $plan): ?><?php
$planId = (int) $plan['id'];
$planName = (string) $plan['name'];
$currency = 'USD';

$minimumAmount = (float) $plan['minimum_amount'];

$maximumAmount = $plan['maximum_amount'] !== null
    ? (float) $plan['maximum_amount']
    : null;

$returnRate = (float) $plan['return_rate'];
$termDays = (int) $plan['term_days'];
$cancelMinutes = (int) $plan['cancel_minutes'];

$planNameUpper = strtoupper($planName);

$showBadge = in_array(
    $planNameUpper,
    ['VIP', 'APEX'],
    true
);
?>

<div class="col-xl-6 col-lg-6 col-md-6 investment-plan-column">

    <div class="site-card investment-plan-card">

        <?php if ($showBadge): ?>

            <div class="investment-plan-badge">
                <?= htmlspecialchars(
                    $planName,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </div>

        <?php endif; ?>

        <div class="site-card-body">

            <div class="investment-plan-icon">
                👨‍💼📋
            </div>

            <h3>
                <?= htmlspecialchars(
                    $planName,
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </h3>

            <div class="investment-plan-rate">
                Daily
                <?= number_format(
                    $returnRate,
                    2
                ) ?>%
            </div>

            <ul class="investment-plan-details">

                <li>
                    <span>
                        Investment
                    </span>

                    <strong class="investment-range">
                        USD
                        <?= number_format(
                            $minimumAmount,
                            0
                        ) ?>-<?= $maximumAmount !== null
                            ? 'USD ' . number_format(
                                $maximumAmount,
                                0
                            )
                            : 'No Limit' ?>
                    </strong>
                </li>

                <li>
                    <span>
                        Capital Back
                    </span>

                    <strong>
                        <?= (int) $plan['capital_back'] === 1
                            ? 'Yes'
                            : 'No' ?>
                    </strong>
                </li>

                <li>
                    <span>
                        Return Type
                    </span>

                    <strong>
                        Period
                    </strong>
                </li>

                <li>
                    <span>
                        Number of Period
                    </span>

                    <strong>
                        <?= $termDays ?>
                        Times
                    </strong>
                </li>

                <li>
                    <span>
                        Profit Payout
                    </span>

                    <strong>
                        Daily
                    </strong>
                </li>

                <li>
                    <span>
                        Cancel
                    </span>

                    <strong>
                        Within <?= $cancelMinutes ?> Minute
                    </strong>
                </li>

            </ul>

            <div class="investment-no-holidays">
                * No Profit Holidays
            </div>

            <div class="investment-plan-action">

                <button
                    type="button"
                    class="investment-invest-button"
                    data-investment-open
                    data-plan-id="<?= $planId ?>"
                >
                    <span>✓</span>
                    INVEST NOW
                </button>

                <form
                    class="investment-plan-form"
                    data-investment-form
                    data-return-rate="<?= htmlspecialchars(
                        (string) $returnRate,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                    data-term-days="<?= $termDays ?>"
                    data-currency="USD"
                >

                    <input
                        type="hidden"
                        name="planId"
                        value="<?= $planId ?>"
                    >

                    <label class="form-label">
                        Amount
                    </label>

                    <input
                        class="form-control mb-2"
                        name="amount"
                        type="number"
                        min="<?= htmlspecialchars(
                            (string) $minimumAmount,
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>"
                        <?php if ($maximumAmount !== null): ?>
                            max="<?= htmlspecialchars(
                                (string) $maximumAmount,
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>"
                        <?php endif; ?>
                        step="0.01"
                        required
                    >

                    <label class="form-label">
                        Wallet
                    </label>

                    <select
                        class="form-control"
                        name="accountId"
                        required
                    >

                        <?php if ($wallet): ?>

                            <option
                                value="<?= (int) $wallet['id'] ?>"
                            >
                                USD
                                <?= number_format(
                                    (float) $wallet['available_balance'],
                                    2
                                ) ?>
                            </option>

                        <?php else: ?>

                            <option value="">
                                USD main wallet unavailable
                            </option>

                        <?php endif; ?>

                    </select>

                    <div class="investment-plan-form-actions">

                        <button
                            type="button"
                            class="investment-cancel-button"
                            data-investment-close
                        >
                            Cancel
                        </button>

                        <button
                            type="submit"
                            class="investment-confirm-button"
                            <?php if (!$wallet): ?>
                                disabled
                            <?php endif; ?>
                        >
                            Confirm Investment
                        </button>

                    </div>

                </form>

            </div>

        </div>

    </div>

</div>

<?php endforeach; ?><?php if (!$plans): ?><div class="col-12">

    <div class="site-card">

        <div class="site-card-body">
            No USD investment plans are currently available.
        </div>

    </div>

</div>

<?php endif; ?></div><?php

$extraScripts = <<<'HTML'
<script>
document.addEventListener('DOMContentLoaded', function () {

    document.querySelectorAll('[data-investment-open]').forEach(function (button) {

        button.addEventListener('click', function () {

            var card = button.closest('.investment-plan-card');

            if (!card) {
                return;
            }

            var form = card.querySelector('[data-investment-form]');

            if (!form) {
                return;
            }

            form.classList.add('is-open');

            button.style.display = 'none';

            var amountInput = form.querySelector('[name="amount"]');

            if (amountInput) {
                amountInput.focus();
            }
        });
    });

    document.querySelectorAll('[data-investment-close]').forEach(function (button) {

        button.addEventListener('click', function () {

            var card = button.closest('.investment-plan-card');

            if (!card) {
                return;
            }

            var form = card.querySelector('[data-investment-form]');
            var openButton = card.querySelector('[data-investment-open]');

            if (form) {
                form.classList.remove('is-open');
            }

            if (openButton) {
                openButton.style.display = '';
            }
        });
    });

    document.querySelectorAll('[data-investment-form]').forEach(function (form) {

        form.addEventListener('submit', function (event) {

            event.preventDefault();

            var amountInput = form.querySelector('[name="amount"]');
            var planIdInput = form.querySelector('[name="planId"]');
            var walletSelect = form.querySelector('[name="accountId"]');
            var submitButton = form.querySelector('[type="submit"]');

            var amount = amountInput
                ? amountInput.value.trim()
                : '';

            var planId = planIdInput
                ? planIdInput.value
                : '';

            var accountId = walletSelect
                ? walletSelect.value
                : '';

            if (!planId) {
                alert('Invalid investment plan.');
                return;
            }

            if (!accountId) {
                alert('Your USD main wallet is not available.');
                return;
            }

            if (!amount || parseFloat(amount) <= 0) {
                alert('Enter a valid investment amount.');
                return;
            }

            if (submitButton) {
                submitButton.disabled = true;
                submitButton.textContent = 'Processing...';
            }

            fetch('/api/auth/csrf.php', {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json'
                }
            })
            .then(function (response) {

                return response.json().then(function (data) {

                    if (!response.ok || !data.csrfToken) {
                        throw new Error(
                            data.error ||
                            'Could not obtain the security token.'
                        );
                    }

                    return data.csrfToken;
                });
            })
            .then(function (csrfToken) {

                return fetch('/api/user/investment-create.php', {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Content-Type': 'application/json',
                        'Accept': 'application/json',
                        'X-CSRF-Token': csrfToken
                    },
                    body: JSON.stringify({
                        planId: parseInt(planId, 10),
                        accountId: parseInt(accountId, 10),
                        amount: amount
                    })
                });
            })
            .then(function (response) {

                return response.json().then(function (data) {

                    if (!response.ok) {
                        throw new Error(
                            data.error ||
                            'The investment could not be created.'
                        );
                    }

                    return data;
                });
            })
            .then(function () {

                window.location.href =
                    '/portal/investments/logs/';
            })
            .catch(function (error) {

                alert(
                    error.message ||
                    'The investment could not be created.'
                );

                if (submitButton) {
                    submitButton.disabled = false;
                    submitButton.textContent = 'Confirm Investment';
                }
            });

        });

    });

});
</script>
HTML;

require __DIR__ . '/../_footer.php';
?>