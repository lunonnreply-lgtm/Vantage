<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Deposit Now';
$activeMenu = 'deposits';
$canonicalPath = '/portal/deposits';

$paymentMethodQuery = $pdo->prepare(
    'SELECT
        id,
        code,
        name,
        wallet_address,
        qr_code,
        charge,
        charge_type,
        minimum_deposit,
        maximum_deposit,
        currency
     FROM payment_methods
     WHERE status = "active"
     ORDER BY id ASC'
);

$paymentMethodQuery->execute();

$paymentMethods = $paymentMethodQuery->fetchAll();

$paymentMethodsJson = json_encode(
    $paymentMethods,
    JSON_HEX_TAG |
    JSON_HEX_APOS |
    JSON_HEX_AMP |
    JSON_HEX_QUOT |
    JSON_UNESCAPED_SLASHES
);

if ($paymentMethodsJson === false) {
    $paymentMethodsJson = '[]';
}

$extraStyles = <<<'HTML'
<style>
.site-head-tag {
    margin: 0;
    padding: 0;
}

.deposit-wallet-box {
    margin-top: 20px;
    padding: 20px;
    border: 1px solid rgba(0, 0, 0, 0.08);
    border-radius: 6px;
}

.deposit-wallet-address {
    display: flex;
    align-items: center;
    gap: 10px;
    margin-top: 10px;
}

.deposit-wallet-address input {
    flex: 1;
}

.deposit-qr {
    display: none;
    margin-top: 20px;
    text-align: center;
}

.deposit-qr.show {
    display: block;
}

.deposit-qr img {
    max-width: 220px;
    width: 100%;
    height: auto;
}

.deposit-copy-btn {
    white-space: nowrap;
}

@media (max-width: 480px) {
    .site-btn.deposit-copy-btn {
        box-sizing: border-box;
        min-width: 64px !important;
        min-height: 44px !important;
        padding: 10px 15px !important;
        font-size: 12px !important;
    }
}

.deposit-payment-section {
    display: none;
}

.deposit-payment-section.show {
    display: block;
}

.deposit-error {
    display: none;
    margin-bottom: 20px;
}

.deposit-error.show {
    display: block;
}

.deposit-success {
    display: none;
}

.deposit-success.show {
    display: block;
}

.deposit-loading {
    display: none;
    margin-top: 10px;
}

.deposit-loading.show {
    display: block;
}

.deposit-stage-1.hide {
    display: none;
}

.deposit-pending-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 25px;
    border: 3px solid #28a745;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
    line-height: 1;
    color: #28a745;
}

.deposit-pending-message {
    text-align: center;
    margin-bottom: 30px;
}
</style>
HTML;

$extraScripts = <<<'HTML'
<script type="text/javascript" src="https://vantageinstitutional.pro/assets/vendor/mckenziearts/laravel-notify/js/notify.js"></script>

<script>
(function () {
    "use strict";

    var paymentMethods = __PAYMENT_METHODS__;

    var selectedMethod = null;
    var csrfToken = null;

    var gatewaySelect = document.getElementById('gatewaySelect');
    var amountInput = document.getElementById('amount');
    var screenshotInput = document.getElementById('screenshot');

    var paymentDetails = document.getElementById('paymentDetails');
    var walletAddress = document.getElementById('walletAddress');
    var qrCode = document.getElementById('qrCode');
    var qrCodeImage = document.getElementById('qrCodeImage');
    var copyWalletButton = document.getElementById('copyWalletButton');
    var selectedMethodName = document.getElementById('selectedMethodName');

    var amountReview = document.getElementById('amountReview');
    var chargeReview = document.getElementById('chargeReview');
    var paymentMethodReview = document.getElementById('paymentMethodReview');
    var totalReview = document.getElementById('totalReview');

    var errorBox = document.getElementById('depositError');
    var paymentForm = document.getElementById('depositForm');
    var proceedButton = document.getElementById('proceedButton');
    var loadingText = document.getElementById('depositLoading');

    var stageOne = document.getElementById('depositStageOne');
    var successBox = document.getElementById('depositSuccess');

    var successReference = document.getElementById('successReference');
    var successAmount = document.getElementById('successAmount');

    function showError(message) {
        errorBox.textContent = message;
        errorBox.classList.add('show');
    }

    function hideError() {
        errorBox.textContent = '';
        errorBox.classList.remove('show');
    }

    function showLoading(show) {
        if (show) {
            loadingText.classList.add('show');
            proceedButton.disabled = true;
        } else {
            loadingText.classList.remove('show');
            proceedButton.disabled = false;
        }
    }

    function getAmount() {
        var amount = parseFloat(amountInput.value);

        return Number.isFinite(amount) ? amount : 0;
    }

    function calculateCharge(amount) {
        if (!selectedMethod) {
            return 0;
        }

        var charge = parseFloat(selectedMethod.charge) || 0;

        if (selectedMethod.charge_type === 'percentage') {
            return (amount * charge) / 100;
        }

        return charge;
    }

    function formatMoney(value) {
        return Number(value).toFixed(2);
    }

    function findSelectedMethod() {
        var selectedCode = gatewaySelect.value;

        if (!selectedCode) {
            selectedMethod = null;
            return null;
        }

        selectedMethod = paymentMethods.find(function (method) {
            return String(method.code) === String(selectedCode);
        }) || null;

        return selectedMethod;
    }

    function updateReview() {
        if (!selectedMethod) {
            amountReview.textContent = '0.00 USD';
            chargeReview.textContent = '0.00 USD';
            paymentMethodReview.textContent = '-';
            totalReview.textContent = '0.00 USD';
            return;
        }

        var amount = getAmount();
        var charge = calculateCharge(amount);
        var total = amount + charge;
        var currency = selectedMethod.currency || 'USD';

        amountReview.textContent =
            formatMoney(amount) + ' ' + currency;

        chargeReview.textContent =
            formatMoney(charge) + ' ' + currency;

        paymentMethodReview.textContent =
            selectedMethod.name;

        totalReview.textContent =
            formatMoney(total) + ' ' + currency;
    }

    function updatePaymentInformation() {
        if (!selectedMethod) {
            paymentDetails.classList.remove('show');
            updateReview();
            return;
        }

        var charge = parseFloat(selectedMethod.charge) || 0;
        var currency = selectedMethod.currency || 'USD';

        selectedMethodName.textContent =
            selectedMethod.name;

        if (selectedMethod.charge_type === 'percentage') {
            document.querySelector('.charge').textContent =
                'Charges ' +
                formatMoney(charge) +
                '%';
        } else {
            document.querySelector('.charge').textContent =
                'Charges ' +
                formatMoney(charge) +
                ' ' +
                currency;
        }

        document.querySelector('.min-max').textContent =
            'Minimum ' +
            formatMoney(
                parseFloat(selectedMethod.minimum_deposit)
            ) +
            ' ' +
            currency +
            ' and Maximum ' +
            formatMoney(
                parseFloat(selectedMethod.maximum_deposit)
            ) +
            ' ' +
            currency;

        walletAddress.value =
            selectedMethod.wallet_address || '';

        if (selectedMethod.qr_code) {
            qrCodeImage.src =
                selectedMethod.qr_code;

            qrCode.classList.add('show');
        } else {
            qrCodeImage.removeAttribute('src');
            qrCode.classList.remove('show');
        }

        paymentDetails.classList.add('show');

        updateReview();
    }

    function validateAmount() {
        hideError();

        if (!selectedMethod) {
            showError(
                'Please select a payment method.'
            );

            return false;
        }

        var amount = getAmount();

        var minimum =
            parseFloat(
                selectedMethod.minimum_deposit
            );

        var maximum =
            parseFloat(
                selectedMethod.maximum_deposit
            );

        var currency =
            selectedMethod.currency || 'USD';

        if (amount <= 0) {
            showError(
                'Please enter a valid deposit amount.'
            );

            return false;
        }

        if (amount < minimum) {
            showError(
                'Minimum deposit is ' +
                formatMoney(minimum) +
                ' ' +
                currency +
                '.'
            );

            return false;
        }

        if (amount > maximum) {
            showError(
                'Maximum deposit is ' +
                formatMoney(maximum) +
                ' ' +
                currency +
                '.'
            );

            return false;
        }

        return true;
    }

    function loadCsrfToken() {
        return fetch(
            '/api/auth/csrf.php',
            {
                method: 'GET',
                credentials: 'same-origin',
                headers: {
                    'Accept': 'application/json'
                }
            }
        )
        .then(function (response) {
            if (!response.ok) {
                throw new Error(
                    'Unable to initialize secure payment session.'
                );
            }

            return response.json();
        })
        .then(function (data) {
            if (!data.csrfToken) {
                throw new Error(
                    'Unable to initialize secure payment session.'
                );
            }

            csrfToken = data.csrfToken;
        });
    }

    $(document).on(
        'change',
        '#gatewaySelect',
        function () {
            hideError();

            findSelectedMethod();

            updatePaymentInformation();
        }
    );

    amountInput.addEventListener(
        'input',
        function () {
            if (selectedMethod) {
                updateReview();
            }
        }
    );

    copyWalletButton.addEventListener(
        'click',
        function () {
            if (!walletAddress.value) {
                return;
            }

            if (
                navigator.clipboard &&
                navigator.clipboard.writeText
            ) {
                navigator.clipboard.writeText(
                    walletAddress.value
                )
                .then(function () {
                    copyWalletButton.textContent =
                        'Copied';

                    setTimeout(
                        function () {
                            copyWalletButton.textContent =
                                'Copy';
                        },
                        1500
                    );
                });
            } else {
                walletAddress.select();

                document.execCommand('copy');

                copyWalletButton.textContent =
                    'Copied';

                setTimeout(
                    function () {
                        copyWalletButton.textContent =
                            'Copy';
                    },
                    1500
                );
            }
        }
    );

    /*
     * Proceed to Payment is the actual submission button.
     */
    proceedButton.addEventListener(
        'click',
        function () {
            hideError();

            findSelectedMethod();

            if (!selectedMethod) {
                showError(
                    'Please select a payment method.'
                );

                return;
            }

            if (!validateAmount()) {
                return;
            }

            if (
                !screenshotInput.files ||
                screenshotInput.files.length === 0
            ) {
                showError(
                    'Please upload your payment screenshot.'
                );

                return;
            }

            if (!csrfToken) {
                showError(
                    'Secure session is not ready. Please refresh the page and try again.'
                );

                return;
            }

            var formData = new FormData();

            formData.append(
                'payment_method',
                selectedMethod.code
            );

            formData.append(
                'amount',
                amountInput.value
            );

            formData.append(
                'screenshot',
                screenshotInput.files[0]
            );

            formData.append(
                'csrf_token',
                csrfToken
            );

            showLoading(true);

            fetch(
                '/api/user/deposits.php',
                {
                    method: 'POST',
                    credentials: 'same-origin',
                    headers: {
                        'Accept': 'application/json',
                        'X-CSRF-Token': csrfToken
                    },
                    body: formData
                }
            )
            .then(function (response) {
                return response.text()
                    .then(function (rawText) {

                        var trimmed =
                            rawText.trim();

                        var data;

                        try {
                            data = JSON.parse(trimmed);
                        } catch (parseError) {

                            console.error(
                                'Deposit API raw response:',
                                rawText
                            );

                            throw new Error(
                                'Server returned an invalid response: ' +
                                trimmed.substring(0, 500)
                            );
                        }

                        return {
                            ok: response.ok,
                            status: response.status,
                            data: data
                        };
                    });
            })
            .then(function (result) {
                showLoading(false);

                if (!result.ok) {
                    throw new Error(
                        result.data.error ||
                        'Unable to submit your deposit request.'
                    );
                }

                var currency =
                    result.data.currency ||
                    selectedMethod.currency ||
                    'USD';

                successReference.textContent =
                    result.data.reference || '-';

                successAmount.textContent =
                    (
                        result.data.amount ||
                        formatMoney(getAmount())
                    ) +
                    ' ' +
                    currency;

                stageOne.classList.add('hide');
                successBox.classList.add('show');

                window.scrollTo({
                    top: 0,
                    behavior: 'smooth'
                });
            })
            .catch(function (error) {
                showLoading(false);

                showError(
                    error.message ||
                    'Unable to submit your deposit request.'
                );
            });
        }
    );

    paymentForm.addEventListener(
        'submit',
        function (event) {
            event.preventDefault();

            proceedButton.click();
        }
    );

    loadCsrfToken()
        .catch(function (error) {
            showError(
                error.message ||
                'Unable to initialize secure payment session.'
            );
        });
})();
</script>

<script>
var notify = {
    timeout: "5000",
};
</script>
HTML;

$extraScripts = str_replace(
    '__PAYMENT_METHODS__',
    $paymentMethodsJson,
    $extraScripts
);

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="site-card">

            <div class="site-card-header">

                <h3 class="title">
                    Add Money
                </h3>

                <div class="card-header-links">

                    <a href="/portal/deposits/logs"
                       class="card-header-link">
                        Deposit History
                    </a>

                </div>

            </div>

            <div class="site-card-body">

                <div id="depositError"
                     class="alert alert-danger deposit-error">
                </div>

                <div id="depositStageOne"
                     class="deposit-stage-1">

                    <div class="progress-steps">

                        <div class="single-step current">

                            <div class="number">
                                01
                            </div>

                            <div class="content">

                                <h4>
                                    Deposit Amount
                                </h4>

                                <p>
                                    Enter your deposit details
                                </p>

                            </div>

                        </div>

                        <div class="single-step">

                            <div class="number">
                                02
                            </div>

                            <div class="content">

                                <h4>
                                    Payment
                                </h4>

                                <p>
                                    Review and submit payment
                                </p>

                            </div>

                        </div>

                    </div>

                    <div class="progress-steps-form">

                        <form id="depositForm"
                              method="post"
                              enctype="multipart/form-data">

                            <div class="row">

                                <div class="col-xl-6 col-md-12 mb-3">

                                    <label for="gatewaySelect"
                                           class="form-label">
                                        Payment Method:
                                    </label>

                                    <div class="input-group">

                                        <select name="payment_method"
                                                id="gatewaySelect"
                                                class="site-nice-select"
                                                required>

                                            <option value=""
                                                    selected
                                                    disabled>
                                                --Select Gateway--
                                            </option>

                                            <?php foreach ($paymentMethods as $method): ?>

                                                <option value="<?= htmlspecialchars(
                                                    (string) $method['code'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>">
                                                    <?= htmlspecialchars(
                                                        (string) $method['name'],
                                                        ENT_QUOTES,
                                                        'UTF-8'
                                                    ) ?>
                                                </option>

                                            <?php endforeach; ?>

                                        </select>

                                    </div>

                                    <div class="input-info-text charge">
                                        Charges 0%
                                    </div>

                                </div>

                                <div class="col-xl-6 col-md-12">

                                    <label for="amount"
                                           class="form-label">
                                        Enter Amount:
                                    </label>

                                    <div class="input-group">

                                        <input type="text"
                                               name="amount"
                                               class="form-control"
                                               oninput="this.value = validateDouble(this.value)"
                                               aria-label="Amount"
                                               id="amount"
                                               required>

                                        <span class="input-group-text">
                                            USD
                                        </span>

                                    </div>

                                    <div class="input-info-text min-max">
                                        Minimum 10 USD and Maximum 1000000 USD
                                    </div>

                                </div>

                            </div>

                            <div id="paymentDetails"
                                 class="deposit-payment-section">

                                <div class="deposit-wallet-box">

                                    <div class="user-panel-title">

                                        <h3>
                                            Please make payment to the
                                            <span id="selectedMethodName"></span>
                                            wallet address
                                        </h3>

                                    </div>

                                    <div class="deposit-wallet-address">

                                        <input type="text"
                                               id="walletAddress"
                                               class="form-control"
                                               readonly
                                               value="">

                                        <button type="button"
                                                id="copyWalletButton"
                                                class="site-btn blue-btn deposit-copy-btn">
                                            Copy
                                        </button>

                                    </div>

                                    <div id="qrCode"
                                         class="deposit-qr">

                                        <img id="qrCodeImage"
                                             src=""
                                             alt="Payment QR Code">

                                    </div>

                                </div>

                                <div class="row mt-3">

                                    <div class="col-xl-12">

                                        <label for="screenshot"
                                               class="form-label">
                                            Submit Screenshot
                                        </label>

                                        <div class="input-group">

                                            <input type="file"
                                                   name="screenshot"
                                                   id="screenshot"
                                                   class="form-control"
                                                   accept="image/jpeg,image/png,image/webp"
                                                   required>

                                        </div>

                                        <div class="input-info-text">
                                            JPG, PNG or WEBP. Maximum 5MB.
                                        </div>

                                    </div>

                                </div>

                            </div>

                            <div class="transaction-list table-responsive">

                                <div class="user-panel-title">

                                    <h3>
                                        Review Details:
                                    </h3>

                                </div>

                                <table class="table">

                                    <tbody>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Amount
                                                </strong>
                                            </td>

                                            <td id="amountReview">
                                                0.00 USD
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Charge
                                                </strong>
                                            </td>

                                            <td id="chargeReview">
                                                0.00 USD
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Payment Method
                                                </strong>
                                            </td>

                                            <td id="paymentMethodReview">
                                                -
                                            </td>

                                        </tr>

                                        <tr>

                                            <td>
                                                <strong>
                                                    Total
                                                </strong>
                                            </td>

                                            <td id="totalReview">
                                                0.00 USD
                                            </td>

                                        </tr>

                                    </tbody>

                                </table>

                            </div>

                            <div class="buttons deposit-submit-area">

                                <button type="button"
                                        id="proceedButton"
                                        class="site-btn blue-btn">

                                    Proceed to Payment

                                    <i class="anticon anticon-double-right"></i>

                                </button>

                                <div id="depositLoading"
                                     class="deposit-loading">
                                    Processing your deposit...
                                </div>

                            </div>

                        </form>

                    </div>

                </div>

                <div id="depositSuccess"
                     class="deposit-success">

                    <div class="progress-steps">

                        <div class="single-step">

                            <div class="number">
                                01
                            </div>

                            <div class="content">

                                <h4>
                                    Deposit Amount
                                </h4>

                                <p>
                                    Enter your deposit details
                                </p>

                            </div>

                        </div>

                        <div class="single-step current">

                            <div class="number">
                                02
                            </div>

                            <div class="content">

                                <h4>
                                    Payment
                                </h4>

                                <p>
                                    Review and submit payment
                                </p>

                            </div>

                        </div>

                    </div>

                    <div class="progress-steps-form">

                        <div class="deposit-pending-icon">
                            ✓
                        </div>

                        <div class="deposit-pending-message">

                            <h2>
                                <span id="pendingAmount">
                                    Deposit
                                </span>
                                Deposit Pending
                            </h2>

                            <p>
                                The amount has been Pending added into your account
                            </p>

                        </div>

                        <div class="transaction-list table-responsive">

                            <div class="user-panel-title">

                                <h3>
                                    Transaction ID:
                                </h3>

                            </div>

                            <table class="table">

                                <tbody>

                                    <tr>

                                        <td>
                                            <strong>
                                                Transaction ID
                                            </strong>
                                        </td>

                                        <td id="successReference">
                                            -
                                        </td>

                                    </tr>

                                    <tr>

                                        <td>
                                            <strong>
                                                Amount
                                            </strong>
                                        </td>

                                        <td id="successAmount">
                                            -
                                        </td>

                                    </tr>

                                    <tr>

                                        <td>
                                            <strong>
                                                Status
                                            </strong>
                                        </td>

                                        <td>
                                            Pending
                                        </td>

                                    </tr>

                                </tbody>

                            </table>

                        </div>

                        <div class="user-panel-title">

                            <h3>
                                Success
                            </h3>

                            <p>
                                Pending Your Deposit Proces
                            </p>

                        </div>

                        <div class="buttons">

                            <button type="button"
                                    id="depositAgainButton"
                                    class="site-btn blue-btn">

                                Deposit Again

                            </button>

                        </div>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<script>
document.addEventListener(
    'DOMContentLoaded',
    function () {

        var depositAgainButton =
            document.getElementById('depositAgainButton');

        var depositStageOne =
            document.getElementById('depositStageOne');

        var depositSuccess =
            document.getElementById('depositSuccess');

        if (
            depositAgainButton &&
            depositStageOne &&
            depositSuccess
        ) {
            depositAgainButton.addEventListener(
                'click',
                function () {

                    depositSuccess.classList.remove('show');
                    depositStageOne.classList.remove('hide');

                    window.scrollTo({
                        top: 0,
                        behavior: 'smooth'
                    });

                }
            );
        }

    }
);
</script>

<?php require __DIR__ . '/../_footer.php'; ?>