<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

/*
|--------------------------------------------------------------------------
| Deposit log filters
|--------------------------------------------------------------------------
*/
$search = trim((string) ($_GET['query'] ?? ''));
$date = trim((string) ($_GET['date'] ?? ''));

/*
|--------------------------------------------------------------------------
| Deposit logs
|--------------------------------------------------------------------------
| No status filter is applied.
| All deposit requests belonging to the logged-in user are displayed.
|--------------------------------------------------------------------------
*/
$sql = '
    SELECT
        reference,
        amount,
        currency,
        status,
        created_at
    FROM financial_requests
    WHERE user_id = :user_id
      AND type = :type
';

$params = [
    'user_id' => $userId,
    'type' => 'deposit'
];

if ($search !== '') {
    $sql .= '
        AND (
            reference LIKE :search_reference
            OR status LIKE :search_status
        )
    ';

    $searchValue = '%' . $search . '%';

    $params['search_reference'] = $searchValue;
    $params['search_status'] = $searchValue;
}

if ($date !== '') {
    $sql .= ' AND DATE(created_at) = :request_date';

    $params['request_date'] = $date;
}

$sql .= ' ORDER BY created_at DESC LIMIT 250';

$depositQuery = $pdo->prepare($sql);
$depositQuery->execute($params);

$deposits = $depositQuery->fetchAll();

$pageTitle = 'Add Money Log';
$activeMenu = 'deposits-logs';
$canonicalPath = '/portal/deposits/logs';

$extraStyles = <<<'HTML'
<style>
    .deposit-log-search {
        display: flex;
        gap: 10px;
        flex-wrap: wrap;
        margin-bottom: 25px;
    }

    .deposit-log-search input {
        min-height: 45px;
        padding: 0 15px;
        border: 1px solid rgba(128, 128, 128, 0.25);
        border-radius: 5px;
        background: transparent;
    }

    .deposit-log-search .apply-btn {
        min-height: 45px;
        padding: 0 25px;
        border: 0;
        border-radius: 5px;
        cursor: pointer;
    }

    .deposit-log-empty {
        text-align: center;
        padding: 35px 15px !important;
    }

    .deposit-status {
        display: inline-flex;
        align-items: center;
        justify-content: center;
        padding: 5px 11px;
        border-radius: 5px;
        font-size: 12px;
        font-weight: 500;
        line-height: 1.2;
        text-transform: capitalize;
        white-space: nowrap;
    }

    .deposit-status::before {
        content: '';
        width: 6px;
        height: 6px;
        border-radius: 50%;
        margin-right: 7px;
        background: currentColor;
    }

    .deposit-status.completed,
    .deposit-status.successful,
    .deposit-status.success,
    .deposit-status.approved {
        background: rgba(40, 167, 69, 0.12);
        color: #28a745;
    }

    .deposit-status.pending,
    .deposit-status.processing {
        background: rgba(255, 193, 7, 0.12);
        color: #d39e00;
    }

    .deposit-status.failed,
    .deposit-status.rejected,
    .deposit-status.cancelled {
        background: rgba(220, 53, 69, 0.12);
        color: #dc3545;
    }

    .deposit-status.refunded {
        background: rgba(108, 117, 125, 0.12);
        color: #6c757d;
    }

    .deposit-status.unknown {
        background: rgba(108, 117, 125, 0.12);
        color: #6c757d;
    }
</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="site-card">

            <div class="site-card-header">
                <h3 class="title">All Deposit Log</h3>
            </div>

            <div class="site-card-body">

                <div class="site-table">

                    <form
                        action="/portal/deposits/logs"
                        method="get"
                    >

                        <div class="deposit-log-search">

                            <input
                                type="text"
                                name="query"
                                placeholder="Search reference or status"
                                value="<?= htmlspecialchars(
                                    $search,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars(
                                    $date,
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>"
                            >

                            <button
                                type="submit"
                                class="apply-btn"
                            >
                                Search
                            </button>

                        </div>

                    </form>

                    <div class="table-responsive">

                        <table class="table table-hover">

                            <thead>

                                <tr>
                                    <th>Description</th>
                                    <th>Transaction ID</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>

                            </thead>

                            <tbody>

                            <?php if ($deposits): ?>

                                <?php foreach ($deposits as $deposit): ?>

                                    <?php
                                    $rawStatus = strtolower(
                                        trim((string) $deposit['status'])
                                    );

                                    $statusClass = preg_replace(
                                        '/[^a-z0-9_-]/',
                                        '-',
                                        $rawStatus
                                    );

                                    $knownStatuses = [
                                        'completed',
                                        'successful',
                                        'success',
                                        'approved',
                                        'pending',
                                        'processing',
                                        'failed',
                                        'rejected',
                                        'cancelled',
                                        'refunded'
                                    ];

                                    if (!in_array(
                                        $statusClass,
                                        $knownStatuses,
                                        true
                                    )) {
                                        $statusClass = 'unknown';
                                    }

                                    $displayStatus = ucfirst(
                                        str_replace(
                                            '_',
                                            ' ',
                                            $rawStatus
                                        )
                                    );
                                    ?>

                                    <tr>

                                        <td>

                                            <div class="table-description">

                                                <div class="icon">
                                                    <i class="anticon anticon-arrow-down"></i>
                                                </div>

                                                <div class="description">
                                                    <strong>
                                                        Deposit request
                                                    </strong>
                                                </div>

                                            </div>

                                        </td>

                                        <td>

                                            <strong>
                                                <?= htmlspecialchars(
                                                    (string) $deposit['reference'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </strong>

                                        </td>

                                        <td>

                                            <strong>

                                                <?= htmlspecialchars(
                                                    (string) $deposit['currency'],
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>

                                                <?= number_format(
                                                    (float) $deposit['amount'],
                                                    2
                                                ) ?>

                                            </strong>

                                        </td>

                                        <td>

                                            <span
                                                class="deposit-status <?= htmlspecialchars(
                                                    $statusClass,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>"
                                            >
                                                <?= htmlspecialchars(
                                                    $displayStatus,
                                                    ENT_QUOTES,
                                                    'UTF-8'
                                                ) ?>
                                            </span>

                                        </td>

                                        <td>

                                            <?= htmlspecialchars(
                                                (string) $deposit['created_at'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ) ?>

                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <tr class="centered">

                                    <td
                                        colspan="5"
                                        class="deposit-log-empty"
                                    >
                                        No deposit records found.
                                    </td>

                                </tr>

                            <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>