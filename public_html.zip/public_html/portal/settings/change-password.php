<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Change Password';
$activeMenu = 'settings';
$canonicalPath = '/portal/settings/change-password';

$extraScripts = '<script src="/assets/js/change-password.js"></script>';

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">Change Password</h3>
                <div class="card-header-links">
                    <a href="https://vantageinstitutional.pro/portal/settings" class="card-header-link">Back</a>
                </div>
            </div>
            <div class="site-card-body">
                <div class="progress-steps-form">
                    <form action="/api/auth/change-password.php" method="post">

                        <div class="row">
                            <div class="col-xl-12 col-md-12">
                                <label class="form-label">Current Password</label>
                                <div class="input-group">
                                    <input type="password" name="current_password" class="form-control required>
                                </div>
                            </div>
                            <div class="col-xl-6 col-md-12">
                                <label class="form-label">New Password</label>
                                <div class="input-group">
                                    <input type="password" name="new_password" class="form-control"minlength="6" maxlength="200" required>
                                </div>
                            </div>
                            <div class="col-xl-6 col-md-12">
                                <label class="form-label">Confirm Password</label>
                                <div class="input-group">
                                    <input type="password" name="new_confirm_password" class="form-control"minlength="6" maxlength="200" required>
                                </div>
                            </div>
                            <div class="col-xl-6 col-md-12">
                                <button type="submit" class="site-btn blue-btn">Change Password</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>