<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$pageTitle = 'Settings';
$activeMenu = 'settings';
$canonicalPath = '/portal/settings';

$successMessage = isset($_SESSION['settings_success'])
    ? (string) $_SESSION['settings_success']
    : '';

$errorMessage = isset($_SESSION['settings_error'])
    ? (string) $_SESSION['settings_error']
    : '';

unset($_SESSION['settings_success'], $_SESSION['settings_error']);

$stmt = $pdo->prepare("
    SELECT
        id,
        first_name,
        last_name,
        email,
        username,
        gender,
        date_of_birth,
        phone,
        country,
        city,
        zip_code,
        address,
        photo,
        role,
        status,
        created_at
    FROM users
    WHERE id = :id
    LIMIT 1
");

$stmt->execute([
    ':id' => $userId,
]);

$user = $stmt->fetch();

if (!$user) {
    http_response_code(404);
    exit('User account not found.');
}

$firstName = (string) ($user['first_name'] ?? '');
$lastName = (string) ($user['last_name'] ?? '');
$email = (string) ($user['email'] ?? '');
$username = (string) ($user['username'] ?? '');
$gender = (string) ($user['gender'] ?? '');
$dateOfBirth = (string) ($user['date_of_birth'] ?? '');
$phone = (string) ($user['phone'] ?? '');
$country = (string) ($user['country'] ?? '');
$city = (string) ($user['city'] ?? '');
$zipCode = (string) ($user['zip_code'] ?? '');
$address = (string) ($user['address'] ?? '');
$photo = (string) ($user['photo'] ?? '');
$createdAt = (string) ($user['created_at'] ?? '');

$avatarUrl = $photo;

$joiningDate = '';

if ($createdAt !== '') {
    $timestamp = strtotime($createdAt);

    if ($timestamp !== false) {
        $joiningDate = date('d M Y', $timestamp);
    }
}

$extraStyles = <<<'HTML'
<style>
.settings-page .site-card {
    margin-bottom: 25px;
}

.settings-page .site-card-header {
    padding: 22px 25px;
}

.settings-page .site-card-body {
    padding: 25px;
}

.settings-page .settings-note {
    margin-bottom: 25px;
    padding: 14px 16px;
    border-radius: 8px;
    background: rgba(251, 191, 36, 0.08);
    border: 1px solid rgba(251, 191, 36, 0.18);
    color: #d6d6d6;
    font-size: 14px;
    line-height: 1.6;
}

.settings-page .settings-alert {
    margin-bottom: 25px;
    padding: 14px 16px;
    border-radius: 8px;
    font-size: 14px;
    line-height: 1.5;
}

.settings-page .settings-alert.success {
    background: rgba(34, 197, 94, 0.10);
    border: 1px solid rgba(34, 197, 94, 0.25);
    color: #86efac;
}

.settings-page .settings-alert.error {
    background: rgba(239, 68, 68, 0.10);
    border: 1px solid rgba(239, 68, 68, 0.25);
    color: #fca5a5;
}

.settings-page .profile-avatar-wrap {
    display: flex;
    align-items: center;
    gap: 20px;
    margin-bottom: 30px;
}

.settings-page .profile-avatar {
    width: 86px;
    height: 86px;
    border-radius: 50%;
    overflow: hidden;
    flex: 0 0 86px;
    background: rgba(255,255,255,0.06);
    border: 1px solid rgba(255,255,255,0.10);
    display: flex;
    align-items: center;
    justify-content: center;
}

.settings-page .profile-avatar img {
    width: 100%;
    height: 100%;
    object-fit: cover;
}

.settings-page .profile-avatar-placeholder {
    font-size: 28px;
    font-weight: 700;
    color: #fbbf24;
}

.settings-page .avatar-content h4 {
    margin: 0 0 5px;
}

.settings-page .avatar-content p {
    margin: 0 0 12px;
    font-size: 13px;
    opacity: .7;
}

.settings-page .avatar-content input[type="file"] {
    max-width: 100%;
}

.settings-page .form-control:disabled,
.settings-page select:disabled,
.settings-page textarea:disabled {
    cursor: not-allowed;
    opacity: .65;
}

.settings-page .readonly-field label::after {
    content: ' • Read only';
    font-size: 11px;
    opacity: .5;
}

.settings-page .editable-section {
    margin-top: 30px;
}

.settings-page .editable-section-title {
    margin-bottom: 20px;
}

.settings-page .editable-section-title h4 {
    margin: 0 0 5px;
}

.settings-page .editable-section-title p {
    margin: 0;
    font-size: 13px;
    opacity: .65;
}

.settings-page .settings-actions {
    margin-top: 25px;
}

.settings-page .password-card {
    margin-top: 0;
}

@media (max-width: 700px) {
    .settings-page .site-card-header,
    .settings-page .site-card-body {
        padding: 20px;
    }

    .settings-page .profile-avatar-wrap {
        align-items: flex-start;
    }
}
</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="settings-page">

    <?php if ($successMessage !== ''): ?>
        <div class="settings-alert success">
            <?php echo htmlspecialchars($successMessage, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <?php if ($errorMessage !== ''): ?>
        <div class="settings-alert error">
            <?php echo htmlspecialchars($errorMessage, ENT_QUOTES, 'UTF-8'); ?>
        </div>
    <?php endif; ?>

    <div class="row">
        <div class="col-xl-12">
            <div class="site-card">

                <div class="site-card-header">
                    <h3 class="title">Profile Settings</h3>
                </div>

                <div class="site-card-body">

                    <div class="settings-note">
                        Your registration information cannot be changed from this page.
                        Additional profile information can be updated below.
                    </div>

                    <form
                        id="profile-settings-form"
                        action="/api/user/profile.php"
                        method="post"
                        enctype="multipart/form-data"
                    >

                        <input
                            type="hidden"
                            name="csrf_token"
                            value="<?php echo htmlspecialchars(
                                $_SESSION['csrf_token'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                        >

                        <div class="profile-avatar-wrap">

                            <div class="profile-avatar">

                                <?php if ($avatarUrl !== ''): ?>

                                    <img
                                        src="<?php echo htmlspecialchars($avatarUrl, ENT_QUOTES, 'UTF-8'); ?>"
                                        alt="Profile avatar"
                                    >

                                <?php else: ?>

                                    <span class="profile-avatar-placeholder">
                                        <?php
                                        echo htmlspecialchars(
                                            strtoupper(substr($firstName, 0, 1)),
                                            ENT_QUOTES,
                                            'UTF-8'
                                        );
                                        ?>
                                    </span>

                                <?php endif; ?>

                            </div>

                            <div class="avatar-content">

                                <h4>Profile Avatar</h4>

                                <p>JPG, PNG or GIF. Maximum file size: 2MB.</p>

                                <input
                                    type="file"
                                    name="avatar"
                                    accept="image/jpeg,image/png,image/gif"
                                >

                            </div>

                        </div>

                        <div class="form-grid">

                            <div class="field readonly-field">
                                <label for="first-name">First Name</label>

                                <input
                                    id="first-name"
                                    class="form-control"
                                    type="text"
                                    value="<?php echo htmlspecialchars($firstName, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                            <div class="field readonly-field">
                                <label for="last-name">Last Name</label>

                                <input
                                    id="last-name"
                                    class="form-control"
                                    type="text"
                                    value="<?php echo htmlspecialchars($lastName, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                            <div class="field readonly-field">
                                <label for="username">Username</label>

                                <input
                                    id="username"
                                    class="form-control"
                                    type="text"
                                    value="<?php echo htmlspecialchars($username, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                            <div class="field readonly-field">
                                <label for="email">Email Address</label>

                                <input
                                    id="email"
                                    class="form-control"
                                    type="email"
                                    value="<?php echo htmlspecialchars($email, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                            <div class="field readonly-field">
                                <label for="country">Country</label>

                                <input
                                    id="country"
                                    class="form-control"
                                    type="text"
                                    value="<?php echo htmlspecialchars($country, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                            <div class="field readonly-field">
                                <label for="joining-date">Joining Date</label>

                                <input
                                    id="joining-date"
                                    class="form-control"
                                    type="text"
                                    value="<?php echo htmlspecialchars($joiningDate, ENT_QUOTES, 'UTF-8'); ?>"
                                    disabled
                                >
                            </div>

                        </div>

                        <div class="editable-section">

                            <div class="editable-section-title">
                                <h4>Additional Profile Information</h4>
                                <p>You can update these details whenever necessary.</p>
                            </div>

                            <div class="form-grid">

                                <div class="field">
                                    <label for="gender">Gender</label>

                                    <select
                                        id="gender"
                                        name="gender"
                                        class="form-control"
                                    >
                                        <option value="">Select gender</option>

                                        <option
                                            value="male"
                                            <?php echo $gender === 'male' ? 'selected' : ''; ?>
                                        >
                                            Male
                                        </option>

                                        <option
                                            value="female"
                                            <?php echo $gender === 'female' ? 'selected' : ''; ?>
                                        >
                                            Female
                                        </option>

                                        <option
                                            value="other"
                                            <?php echo $gender === 'other' ? 'selected' : ''; ?>
                                        >
                                            Other
                                        </option>
                                    </select>
                                </div>

                                <div class="field">
                                    <label for="date-of-birth">Date of Birth</label>

                                    <input
                                        id="date-of-birth"
                                        name="date_of_birth"
                                        class="form-control"
                                        type="date"
                                        value="<?php echo htmlspecialchars($dateOfBirth, ENT_QUOTES, 'UTF-8'); ?>"
                                    >
                                </div>

                                <div class="field">
                                    <label for="phone">Phone</label>

                                    <input
                                        id="phone"
                                        name="phone"
                                        class="form-control"
                                        type="tel"
                                        value="<?php echo htmlspecialchars($phone, ENT_QUOTES, 'UTF-8'); ?>"
                                        maxlength="30"
                                    >
                                </div>

                                <div class="field">
                                    <label for="city">City</label>

                                    <input
                                        id="city"
                                        name="city"
                                        class="form-control"
                                        type="text"
                                        value="<?php echo htmlspecialchars($city, ENT_QUOTES, 'UTF-8'); ?>"
                                        maxlength="100"
                                    >
                                </div>

                                <div class="field">
                                    <label for="zip-code">ZIP / Postal Code</label>

                                    <input
                                        id="zip-code"
                                        name="zip_code"
                                        class="form-control"
                                        type="text"
                                        value="<?php echo htmlspecialchars($zipCode, ENT_QUOTES, 'UTF-8'); ?>"
                                        maxlength="30"
                                    >
                                </div>

                                <div class="field full">
                                    <label for="address">Address</label>

                                    <textarea
                                        id="address"
                                        name="address"
                                        class="form-control"
                                        rows="4"
                                        maxlength="255"
                                    ><?php echo htmlspecialchars($address, ENT_QUOTES, 'UTF-8'); ?></textarea>
                                </div>

                            </div>

                        </div>

                        <div class="settings-actions">

                            <button
                                id="profile-save-button"
                                type="submit"
                                class="site-btn blue-btn"
                            >
                                Save Changes
                            </button>

                        </div>

                    </form>

                </div>

            </div>
        </div>
    </div>

    <div class="row">

        <div class="col-xl-6 col-lg-6 col-md-12">

            <div class="site-card password-card">

                <div class="site-card-header">
                    <h3 class="title">Change Password</h3>
                </div>

                <div class="site-card-body">

                    <a
                        href="/portal/settings/change-password"
                        class="site-btn blue-btn"
                    >
                        Change Password
                    </a>

                </div>

            </div>

        </div>

    </div>

</div>

<script>
document.addEventListener('DOMContentLoaded', function () {
    var form = document.getElementById('profile-settings-form');

    if (!form) {
        return;
    }

    form.addEventListener('submit', function (event) {
        event.preventDefault();

        var tokenInput = form.querySelector('input[name="csrf_token"]');
        var saveButton = document.getElementById('profile-save-button');

        if (!tokenInput || !tokenInput.value) {
            window.location.reload();
            return;
        }

        if (saveButton) {
            saveButton.disabled = true;
            saveButton.textContent = 'Saving...';
        }

        var formData = new FormData(form);

        fetch('/api/user/profile.php', {
            method: 'POST',
            headers: {
                'X-CSRF-Token': tokenInput.value
            },
            body: formData,
            credentials: 'same-origin'
        })
        .then(function (response) {
            if (response.redirected) {
                window.location.href = response.url;
                return;
            }

            window.location.href = '/portal/settings';
        })
        .catch(function () {
            window.location.href = '/portal/settings';
        });
    });
});
</script>

<?php require __DIR__ . '/../_footer.php'; ?>