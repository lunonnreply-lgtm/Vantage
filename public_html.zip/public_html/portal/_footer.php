</div>
<!-- /container-fluid -->

</div>
<!-- /section-gap -->

</div>
<!-- /main-content -->

</div>
<!-- /Page Container -->

</div>
<!-- /panel-layout -->


<script src="https://vantageinstitutional.pro/assets/global/js/jquery.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/jquery-migrate.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/bootstrap.bundle.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/scrollUp.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/owl.carousel.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/waypoints.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/jquery.counterup.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/jquery.nice-select.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/lucide.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/magnific-popup.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/aos.js"></script>

<script
    src="https://vantageinstitutional.pro/assets/global/js/datatables.min.js"
    type="text/javascript"
    charset="utf8"
></script>

<script src="https://vantageinstitutional.pro/assets/global/js/simple-notify.min.js"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/main.js?var=5"></script>

<script src="https://vantageinstitutional.pro/assets/frontend/js/cookie.js"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/custom.js?var=5"></script>

<script src="https://vantageinstitutional.pro/assets/global/js/pusher.min.js"></script>


<script>

(function ($) {

    'use strict';

    let pusherAppKey = "";
    let pusherAppCluster = "mt1";
    let soundUrl = "";

    var notification = new Pusher(pusherAppKey, {
        encrypted: true,
        cluster: pusherAppCluster,
    });

    var channel = notification.subscribe(
        'user-notification896'
    );

    channel.bind(
        'notification-event',
        function (result) {

            playSound();

            latestNotification();

            notifyToast(result);

        }
    );

    function latestNotification() {

        $.get(
            '/api/auth/me.php',
            function (data) {

                $('.user-notifications896').html(data);

            }
        );

    }

    function notifyToast(data) {

        new Notify({

            status: 'info',

            title: data.data.title,

            text: data.data.notice,

            effect: 'slide',

            speed: 300,

            customClass: '',

            customIcon:
                '<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" class="lucide lucide-megaphone"><path d="m3 11 18-5v12L3 14v-3z"></path><path d="M11.6 16.8a3 3 0 1 1-5.8-1.6"></path></svg>',

            showIcon: true,

            showCloseButton: true,

            autoclose: true,

            autotimeout: 9000,

            gap: 20,

            distance: 20,

            type: 1,

            position: 'right bottom',

            customWrapper:
                '<div><a href="' +
                data.data.action_url +
                '" class="learn-more-link">Explore<svg xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"><path d="M18 13v6a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V8a2 2 0 0 1 2-2h6"></path><polyline points="15 3 21 3 21 9"></polyline><line x1="10" x2="21" y1="14" y2="3"></line></svg></a></div>',

        });

    }

    function playSound() {

        $.get(
            soundUrl,
            function (data) {

                var audio = new Audio(data);

                audio.play();

                audio.muted = false;

            }
        );

    }

})(jQuery);

</script>



























<script>

(function ($) {

    'use strict';

    AOS.init();

})(jQuery);

</script>


<script>

(function ($) {

    'use strict';

    $.scrollUp({

        scrollText:
            '<i class="fas fa-caret-up"></i>',

        easingType: 'linear',

        scrollSpeed: 500,

        animation: 'fade'

    });

})(jQuery);

</script>


<script
    type="text/javascript"
    src="https://vantageinstitutional.pro/assets/vendor/mckenziearts/laravel-notify/js/notify.js"
></script>


<script>

(function ($) {

    'use strict';

    $(".color-switcher").on(
        'click',
        function () {

            $("body").toggleClass("dark-theme");

            var url = '/api/auth/me.php';

            $.get(url);

        }
    );

})(jQuery);

</script>


<script>
(function () {

    'use strict';

    var csrfToken = <?= json_encode($csrfToken) ?>;

    document.querySelectorAll('.logout-form').forEach(
        function (form) {

            form.addEventListener(
                'submit',
                function (event) {

                    event.preventDefault();

                    fetch('/logout', {
                        method: 'POST',
                        credentials: 'same-origin',
                        headers: {
                            'X-CSRF-Token': csrfToken,
                            'Accept': 'application/json'
                        }
                    })
                    .then(
                        function (response) {

                            return response.json().then(
                                function (data) {

                                    if (!response.ok) {

                                        throw new Error(
                                            data.error ||
                                            'Logout failed.'
                                        );

                                    }

                                    return data;

                                }
                            );

                        }
                    )
                    .then(
                        function () {

                            localStorage.clear();

                            window.location.href = '/auth/login/';

                        }
                    )
                    .catch(
                        function (error) {

                            console.error(
                                'Logout failed:',
                                error
                            );

                            alert(
                                error.message ||
                                'Logout failed. Please try again.'
                            );

                        }
                    );

                }
            );

        }
    );

})();
</script>


<?php if (!empty($extraScripts)): ?>

    <?= $extraScripts ?>

<?php endif; ?>
<script src="/assets/frontend/js/mobile-navigation.js?v=2"></script>

<script src="/assets/global/js/visitor-tracker.js" defer></script>

</body>

</html>