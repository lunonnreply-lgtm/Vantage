<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$referralCodeQuery = $pdo->prepare('SELECT referral_code FROM users WHERE id = :user_id LIMIT 1');
$referralCodeQuery->execute(['user_id' => $userId]);
$referralCode = (string) ($referralCodeQuery->fetchColumn() ?: '');
$referralUrl = 'https://vantageinstitutional.com/auth/register/?ref=' . urlencode($referralCode);

$referralCountQuery = $pdo->prepare('SELECT COUNT(*) FROM referrals WHERE referrer_user_id = :user_id');
$referralCountQuery->execute(['user_id' => $userId]);
$referralCount = (int) $referralCountQuery->fetchColumn();

$referralBonusQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM bonuses WHERE user_id = :user_id AND type = 'referral' AND status = 'credited'");
$referralBonusQuery->execute(['user_id' => $userId]);
$referralBonusTotal = (float) $referralBonusQuery->fetchColumn();

$referralLogsQuery = $pdo->prepare(
    'SELECT u.first_name, u.last_name, r.created_at
     FROM referrals r
     JOIN users u ON u.id = r.referred_user_id
     WHERE r.referrer_user_id = :user_id
     ORDER BY r.created_at DESC
     LIMIT 250'
);
$referralLogsQuery->execute(['user_id' => $userId]);
$referralLogs = $referralLogsQuery->fetchAll();

$pageTitle = 'Referral';
$activeMenu = 'referral';
$canonicalPath = '/portal/referral';

$extraScripts = <<<'HTML'
<script>
    function copyRef() {
        /* Get the text field */
        var copyApi = document.getElementById("refLink");
        /* Select the text field */
        copyApi.select();
        copyApi.setSelectionRange(0, 999999999); /* For mobile devices */
        /* Copy the text inside the text field */
        document.execCommand('copy');
        $('#copy').text($('#copied').val())
    }
</script>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12 col-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">Referral URL                             and Tree
                    </h3>
            </div>
            <div class="site-card-body">
                <div class="referral-link">
                    <div class="referral-link-form">
                        <input type="text" value="<?= htmlspecialchars($referralUrl, ENT_QUOTES, 'UTF-8') ?>" id="refLink"/>
                        <button type="submit" onclick="copyRef()">
                            <i class="anticon anticon-copy"></i>
                            <span id="copy">Copy Url</span>
                            <input id="copied" hidden value="Copied">
                        </button>
                    </div>
                    <p class="referral-joined">
                        <?= $referralCount ?> peoples are joined by using this URL
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="row">
    <div class="col-xl-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">All Referral Logs</h3>
                <div class="card-header-links">
                    <span class="card-header-link rounded-pill"> Referral Profit: <?= number_format($referralBonusTotal, 2) ?> USD</span>
                </div>
            </div>
            <div class="site-card-body table-responsive">

                <div class="site-tab-bars">
                    <ul class="nav nav-pills" id="pills-tab" role="tablist">
                        <li class="nav-item" role="presentation">
                            <a
                                href=""
                                class="nav-link active"
                                id="generalTarget-tab"
                                data-bs-toggle="pill"
                                data-bs-target="#generalTarget"
                                type="button"
                                role="tab"
                                aria-controls="generalTarget"
                                aria-selected="true"
                            ><i icon-name="network"></i>General</a>
                        </li>
                    </ul>
                </div>

                <div class="tab-content" id="pills-tabContent">
                    <div
                        class="tab-pane fade show active"
                        id="generalTarget"
                        role="tabpanel"
                        aria-labelledby="generalTarget-tab"
                    >
                        <div class="row">
                            <div class="col-xl-12 col-lg-12 col-md-12 col-sm-12">
                                <div class="site-datatable">
                                    <div class="row table-responsive">
                                        <div class="col-xl-12">
                                            <table class="display data-table">
                                                <thead>
                                                <tr>
                                                    <th>Description</th>
                                                    <th>Transactions ID</th>
                                                    <th>Amount</th>
                                                    <th>Status</th>
                                                </tr>
                                                </thead>
                                                <tbody>
                                                <?php if ($referralLogs): ?>
                                                    <?php foreach ($referralLogs as $log): ?>
                                                        <tr>
                                                            <td>
                                                                <?= htmlspecialchars(
                                                                    trim($log['first_name'] . ' ' . $log['last_name']),
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                ) ?> joined
                                                            </td>
                                                            <td>—</td>
                                                            <td>—</td>
                                                            <td>
                                                                <?= htmlspecialchars(
                                                                    (string) $log['created_at'],
                                                                    ENT_QUOTES,
                                                                    'UTF-8'
                                                                ) ?>
                                                            </td>
                                                        </tr>
                                                    <?php endforeach; ?>
                                                <?php endif; ?>
                                                </tbody>
                                            </table>

                                            <?php if (!$referralLogs): ?>
                                                <p class="centered">No Data Found</p>
                                            <?php endif; ?>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>