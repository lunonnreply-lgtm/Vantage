<?php

declare(strict_types=1);

// Expects the calling page to have already required bootstrap.php,
// set $userId via require_page_auth(), and defined:
// $pageTitle (string), $activeMenu (string key), $canonicalPath (string, optional)

$userId = isset($userId) ? (int) $userId : require_page_auth();

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = (string) $_SESSION['csrf_token'];

$accountQuery = $pdo->prepare(
    'SELECT currency, available_balance
     FROM accounts
     WHERE user_id = :user_id
       AND wallet_type = :wallet_type
     ORDER BY id
     LIMIT 1'
);
$accountQuery->execute([
    'user_id' => $userId,
    'wallet_type' => 'main',
]);

$account = $accountQuery->fetch() ?: [
    'currency' => 'USD',
    'available_balance' => '0.00'
];

$currency = (string) $account['currency'];
$balance = number_format((float) $account['available_balance'], 2);

$profitBalanceQuery = $pdo->prepare(
    'SELECT
        COALESCE(SUM(available_balance), 0) AS total_balance,
        COALESCE(SUM(restricted_balance), 0) AS locked_balance
     FROM accounts
     WHERE user_id = :user_id
       AND wallet_type = :wallet_type
       AND currency = :currency'
);
$profitBalanceQuery->execute([
    'user_id' => $userId,
    'wallet_type' => 'profit',
    'currency' => $currency,
]);
$profitBalance = $profitBalanceQuery->fetch() ?: [
    'total_balance' => 0,
    'locked_balance' => 0,
];
$profitBalanceTotal = (float) $profitBalance['total_balance'];
$restrictedProfitBalance = (float) $profitBalance['locked_balance'];
$formattedProfitBalance = number_format(
    max(0, $profitBalanceTotal - $restrictedProfitBalance),
    2
);
$formattedRestrictedProfitBalance = number_format($restrictedProfitBalance, 2);

$investedBalanceQuery = $pdo->prepare(
    'SELECT COALESCE(SUM(principal), 0)
     FROM investments
     WHERE user_id = :user_id
       AND status = :status
       AND currency = :currency'
);
$investedBalanceQuery->execute([
    'user_id' => $userId,
    'status' => 'active',
    'currency' => $currency,
]);
$activeInvestmentPrincipal = (float) $investedBalanceQuery->fetchColumn();

$portfolioTotal = number_format(
    (float) $account['available_balance']
    + $profitBalanceTotal
    + $activeInvestmentPrincipal,
    2
);

$userQuery = $pdo->prepare(
    'SELECT role, status
     FROM users
     WHERE id = :user_id
     LIMIT 1'
);
$userQuery->execute(['user_id' => $userId]);

$user = $userQuery->fetch() ?: [];

$isAdmin = ($user['role'] ?? '') === 'admin'
    && ($user['status'] ?? '') === 'active';

$pageTitle = $pageTitle ?? 'Vantage Institutional';
$activeMenu = $activeMenu ?? '';
$canonicalPath = $canonicalPath ?? '';

function nav_active(string $key, string $activeMenu): string
{
    return $key === $activeMenu ? ' active' : '';
}

?>
<!DOCTYPE html>
<html lang="en">

<head>

    <meta charset="UTF-8"/>

    <meta
        http-equiv="X-UA-Compatible"
        content="IE=edge"
    />

    <meta
        name="viewport"
        content="width=device-width, initial-scale=1.0"
    />

    <meta
        name="keywords"
        content="Vantage Institutional"
    >

    <meta
        name="description"
        content="Vantage Institutional"
    >

    <link rel="icon" type="image/svg+xml" href="/assets/branding/favicon.svg">
    <link rel="icon" type="image/png" sizes="48x48" href="/assets/branding/favicon-48.png">
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/branding/favicon-32.png">
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/branding/favicon-16.png">
    <link rel="shortcut icon" href="/assets/branding/favicon.ico">
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/branding/apple-touch-icon.png">
    <link rel="manifest" href="/assets/branding/site.webmanifest">
    <meta name="msapplication-TileImage" content="/assets/branding/mstile-270.png">
    <meta name="msapplication-config" content="/browserconfig.xml">
    <meta name="msapplication-TileColor" content="#0B1F3A">
    <meta name="theme-color" content="#0B1F3A">

    <?php if ($canonicalPath !== ''): ?>
    <link
        rel="canonical"
        href="https://vantageinstitutional.com<?= htmlspecialchars($canonicalPath, ENT_QUOTES, 'UTF-8') ?>"
    />
    <?php endif; ?>

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/global/css/fontawesome.min.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/vendor/bootstrap.min.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/animate.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/owl.carousel.min.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/global/css/nice-select.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/global/css/datatables.min.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/global/css/simple-notify.min.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/vendor/mckenziearts/laravel-notify/css/notify.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/global/css/custom.css?v=7"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/magnific-popup.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/aos.css"
    />

    <link
        rel="stylesheet"
        href="https://vantageinstitutional.com/assets/frontend/css/styles.css?var=5"
    /><link rel="stylesheet" href="/assets/frontend/css/mobile-navigation.css?v=15">

    <?php if (!empty($extraStyles)): ?>
        <?= $extraStyles ?>
    <?php endif; ?>

    <title><?= htmlspecialchars($pageTitle, ENT_QUOTES, 'UTF-8') ?> - Vantage Institutional</title>

</head>



<body class="dark-theme">

<script>
    var notify = {
        timeout: "5000",
    }
</script>

<div class="panel-layout">

    <!-- Header -->
    <div class="panel-header">

        <div class="logo">

            <a href="https://vantageinstitutional.com/share">
                <img src="/assets/logo.png" alt="Vantage Institutional" width="176" height="61" style="width: 176px; height: auto; max-width: 100%;" />
            </a>

        </div>

        <div class="nav-wrap">

            <div class="nav-left">

                <button class="sidebar-toggle">
                    <i class="anticon anticon-arrow-left"></i>
                </button>

                <div class="mob-logo">

                    <a href="https://vantageinstitutional.com/share">
                        <img src="/assets/logo.png" alt="Vantage Institutional" width="145" height="50" style="width: 145px; height: auto; max-width: 100%;" />
                    </a>

                </div>

            </div>

            <div class="nav-right">

                <div class="single-nav-right">

                    <div class="single-right">

                        <div class="color-switcher">

                            <i
                                icon-name="moon"
                                class="dark-icon"
                                data-mode="dark"
                            ></i>

                            <i
                                icon-name="sun"
                                class="light-icon"
                                data-mode="light"
                            ></i>

                        </div>

                    </div>

                    <div class="single-nav-right user-notifications896">

                        <button
                            type="button"
                            class="item notification-dot"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i icon-name="bell-ring"></i>

                            <div class="number">
                                0
                            </div>

                        </button>

                        <div class="dropdown-menu dropdown-menu-end notification-pop">

                            <div class="noti-head">
                                Notifications <span>0</span>
                            </div>

                            <div class="all-noti">
                                <p>
                                    Notification Not Found
                                </p>
                            </div>

                        </div>

                    </div>

                    <div class="single-right">

                        <div id="google_element"></div>

                        <script src="https://translate.google.com/translate_a/element.js?cb=loadGoogleTranslate"></script>

                        <script>
                            function loadGoogleTranslate() {
                                new google.translate.TranslateElement({
                                    pageLanguage: 'en',
                                    layout: google.translate.TranslateElement.InlineLayout.VERTICAL
                                }, 'google_element');
                            }
                        </script>

                    </div>

                    <div class="single-right">

                        <button
                            type="button"
                            class="item"
                            data-bs-toggle="dropdown"
                            aria-expanded="false"
                        >

                            <i class="anticon anticon-user"></i>

                        </button>

                        <ul class="dropdown-menu dropdown-menu-end">

                            <li>

                                <a
                                    href="https://vantageinstitutional.com/portal/settings"
                                    class="dropdown-item"
                                >

                                    <i class="anticon anticon-setting"></i>

                                    Settings

                                </a>

                            </li>

                            <li>

                                <a
                                    href="https://vantageinstitutional.com/portal/settings/change-password"
                                    class="dropdown-item"
                                >

                                    <i class="anticon anticon-lock"></i>

                                    Change Password

                                </a>

                            </li>

                            <li>

                                <a
                                    href="https://vantageinstitutional.com/portal/support"
                                    class="dropdown-item"
                                >

                                    <i class="anticon anticon-customer-service"></i>

                                    Support Tickets

                                </a>

                            </li>

                            <li class="logout">

                                <form
                                    method="POST"
                                    action="/logout"
                                    class="logout-form"
                                >

                                    <button
                                        type="submit"
                                        class="dropdown-item"
                                    >

                                        <i class="anticon anticon-logout"></i>

                                        Logout

                                    </button>

                                </form>

                            </li>

                        </ul>

                    </div>

                </div>

            </div>

        </div>

    </div>
    <!-- /Header -->


    <!-- Smartsupp Live Chat -->
    <script type="text/javascript">

        var _smartsupp = _smartsupp || {};

        _smartsupp.key = 'a382b489081ae0559911d56b7a2750e527ef623d';

        window.smartsupp || (function(d) {

            var s,
                c,
                o = smartsupp = function() {
                    o._.push(arguments)
                };

            o._ = [];

            s = d.getElementsByTagName('script')[0];

            c = d.createElement('script');

            c.type = 'text/javascript';
            c.charset = 'utf-8';
            c.async = true;

            c.src = 'https://www.smartsuppchat.com/loader.js?';

            s.parentNode.insertBefore(c, s);

        })(document);

    </script>

    <noscript>

        Powered by

        <a
            href="https://www.smartsupp.com"
            target="_blank"
        >
            Smartsupp
        </a>

    </noscript>
    
    
    
    
    
    <!-- Mobile Sidebar -->
<div class="mobile-screen-show">

    <div class="mobile-side-nav">

        <div class="side-wallet-box default-wallet mb-0">

            <div class="user-balance-card">

                <div class="wallet-name">

                    <div class="name">
                        Account Balance
                    </div>

                    <div class="default">
                        Wallet
                    </div>

                </div>

                <div class="wallet-info">

                    <div class="wallet-id">
                        <i icon-name="wallet"></i>
                        Main Wallet
                    </div>

                    <div class="balance">
                        <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>
                        <?= htmlspecialchars($balance, ENT_QUOTES, 'UTF-8') ?>
                    </div>

                </div>

                <div class="wallet-info">

                    <div class="wallet-id">
                        <i icon-name="landmark"></i>
                        Profit Wallet Available
                    </div>

                    <div class="balance">
                        <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>
                        <?= htmlspecialchars($formattedProfitBalance, ENT_QUOTES, 'UTF-8') ?>
                    </div>

                </div>

                <div class="wallet-info">

                    <div class="wallet-id">
                        <i icon-name="lock-keyhole"></i>
                        Locked Investment Profit
                    </div>

                    <div class="balance">
                        <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>
                        <?= htmlspecialchars($formattedRestrictedProfitBalance, ENT_QUOTES, 'UTF-8') ?>
                    </div>

                </div>

                <div class="wallet-info portfolio-total-row">

                    <div class="wallet-id">
                        <i icon-name="chart-pie"></i>
                        Portfolio Total
                    </div>

                    <div class="balance">
                        <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>
                        <?= htmlspecialchars($portfolioTotal, ENT_QUOTES, 'UTF-8') ?>
                    </div>

                </div>

            </div>

            <div class="actions">

                <a
                    href="https://vantageinstitutional.com/portal/deposits"
                    class="user-sidebar-btn"
                >
                    <i class="anticon anticon-file-add"></i>
                    Deposit
                </a>

                <a
                    href="/portal/investments"
                    class="user-sidebar-btn red-btn"
                >
                    <i class="anticon anticon-export"></i>
                    Invest Now
                </a>

            </div>

        </div>


        <div class="side-nav-inside">

            <ul class="side-nav-menu">

                <li class="side-nav-item<?= nav_active('dashboard', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/dashboard">
                        <i class="anticon anticon-appstore"></i>
                        <span>Dashboard</span>
                    </a>

                </li>


                <?php if ($isAdmin): ?>

                    <li class="side-nav-item<?= nav_active('admin', $activeMenu) ?>">

                        <a href="/admin/">
                            <i class="anticon anticon-setting"></i>
                            <span>Admin Console</span>
                        </a>

                    </li>

                <?php endif; ?>


                <li class="side-nav-item<?= nav_active('investments', $activeMenu) ?>">

                    <a href="/portal/investments">
                        <i class="anticon anticon-check-square"></i>
                        <span>All Schema</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('investments-logs', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/investments/logs">
                        <i class="anticon anticon-copy"></i>
                        <span>Schema Logs</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('transactions', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/transactions">
                        <i class="anticon anticon-inbox"></i>
                        <span>All Transactions</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('deposits', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/deposits">
                        <i class="anticon anticon-file-add"></i>
                        <span>Add Money</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('deposits-logs', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/deposits/logs">
                        <i class="anticon anticon-folder-add"></i>
                        <span>Add Money Log</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('wallet-exchange', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/wallet/exchange">
                        <i class="anticon anticon-transaction"></i>
                        <span>Wallet Exchange</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('transfers', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/transfers">
                        <i class="anticon anticon-export"></i>
                        <span>Send Money</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('transfers-logs', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/transfers/logs">
                        <i class="anticon anticon-cloud"></i>
                        <span>Send Money Log</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('withdrawals', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/withdrawals">
                        <i class="anticon anticon-bank"></i>
                        <span>Withdraw</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('withdrawals-logs', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/withdrawals/logs">
                        <i class="anticon anticon-credit-card"></i>
                        <span>Withdraw Log</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('referral', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/referral">
                        <i class="anticon anticon-usergroup-add"></i>
                        <span>Referral</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('settings', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/settings">
                        <i class="anticon anticon-setting"></i>
                        <span>Settings</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('support', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/support">
                        <i class="anticon anticon-tool"></i>
                        <span>Support Tickets</span>
                    </a>

                </li>


                <li class="side-nav-item<?= nav_active('notifications', $activeMenu) ?>">

                    <a href="https://vantageinstitutional.com/portal/notifications">
                        <i class="anticon anticon-notification"></i>
                        <span>Notifications</span>
                    </a>

                </li>


                <li class="side-nav-item">

                    <form
                        method="POST"
                        action="/logout"
                        class="logout-form"
                    >

                        <button
                            type="submit"
                            class="site-btn grad-btn w-100"
                        >
                            <i class="anticon anticon-logout"></i>
                            <span>Logout</span>
                        </button>

                    </form>

                </li>

            </ul>

        </div>

    </div>

</div>
<!-- /Mobile Sidebar -->











    <!-- Desktop Sidebar -->
    <div class="desktop-screen-show">

        <div class="side-nav">

            <div class="side-wallet-box default-wallet mb-0">

                <div class="user-balance-card">

                    <div class="wallet-name">

                        <div class="name">
                            Account Balance
                        </div>

                        <div class="default">
                            Wallet
                        </div>

                    </div>

                    <div class="wallet-info">

                        <div class="wallet-id">

                            <i icon-name="wallet"></i>

                            Main Wallet

                        </div>

                        <div class="balance">

                            <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>

                            <?= htmlspecialchars($balance, ENT_QUOTES, 'UTF-8') ?>

                        </div>

                    </div>

                    <div class="wallet-info">

                        <div class="wallet-id">

                            <i icon-name="landmark"></i>

                            Profit Wallet Available

                        </div>

                        <div class="balance">

                            <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>

                            <?= htmlspecialchars($formattedProfitBalance, ENT_QUOTES, 'UTF-8') ?>

                        </div>

                    </div>

                    <div class="wallet-info">

                        <div class="wallet-id">

                            <i icon-name="lock-keyhole"></i>

                            Locked Investment Profit

                        </div>

                        <div class="balance">

                            <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>

                            <?= htmlspecialchars($formattedRestrictedProfitBalance, ENT_QUOTES, 'UTF-8') ?>

                        </div>

                    </div>

                    <div class="wallet-info portfolio-total-row">

                        <div class="wallet-id">

                            <i icon-name="chart-pie"></i>

                            Portfolio Total

                        </div>

                        <div class="balance">

                            <?= htmlspecialchars($currency, ENT_QUOTES, 'UTF-8') ?>

                            <?= htmlspecialchars($portfolioTotal, ENT_QUOTES, 'UTF-8') ?>

                        </div>

                    </div>

                </div>

                <div class="actions">

                    <a
                        href="https://vantageinstitutional.com/portal/deposits"
                        class="user-sidebar-btn"
                    >

                        <i class="anticon anticon-file-add"></i>

                        Deposit

                    </a>

                    <a
                        href="/portal/investments"
                        class="user-sidebar-btn red-btn"
                    >

                        <i class="anticon anticon-export"></i>

                        Invest Now

                    </a>

                </div>

            </div>


            <div class="side-nav-inside">

                <ul class="side-nav-menu">

                    <li class="side-nav-item<?= nav_active('dashboard', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/dashboard">

                            <i class="anticon anticon-appstore"></i>

                            <span>
                                Dashboard
                            </span>

                        </a>

                    </li>

                    <?php if ($isAdmin): ?>

                        <li class="side-nav-item<?= nav_active('admin', $activeMenu) ?>">

                            <a href="/admin/">

                                <i class="anticon anticon-setting"></i>

                                <span>
                                    Admin Console
                                </span>

                            </a>

                        </li>

                    <?php endif; ?>

                    <li class="side-nav-item<?= nav_active('investments', $activeMenu) ?>">

                        <a href="/portal/investments">

                            <i class="anticon anticon-check-square"></i>

                            <span>
                                All Schema
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('investments-logs', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/investments/logs">

                            <i class="anticon anticon-copy"></i>

                            <span>
                                Schema Logs
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('transactions', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/transactions">

                            <i class="anticon anticon-inbox"></i>

                            <span>
                                All Transactions
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('deposits', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/deposits">

                            <i class="anticon anticon-file-add"></i>

                            <span>
                                Add Money
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('deposits-logs', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/deposits/logs">

                            <i class="anticon anticon-folder-add"></i>

                            <span>
                                Add Money Log
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('wallet-exchange', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/wallet/exchange">

                            <i class="anticon anticon-transaction"></i>

                            <span>
                                Wallet Exchange
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('transfers', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/transfers">

                            <i class="anticon anticon-export"></i>

                            <span>
                                Send Money
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('transfers-logs', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/transfers/logs">

                            <i class="anticon anticon-cloud"></i>

                            <span>
                                Send Money Log
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('withdrawals', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/withdrawals">

                            <i class="anticon anticon-bank"></i>

                            <span>
                                Withdraw
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('withdrawals-logs', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/withdrawals/logs">

                            <i class="anticon anticon-credit-card"></i>

                            <span>
                                Withdraw Log
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('referral', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/referral">

                            <i class="anticon anticon-usergroup-add"></i>

                            <span>
                                Referral
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('settings', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/settings">

                            <i class="anticon anticon-setting"></i>

                            <span>
                                Settings
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('support', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/support">

                            <i class="anticon anticon-tool"></i>

                            <span>
                                Support Tickets
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item<?= nav_active('notifications', $activeMenu) ?>">

                        <a href="https://vantageinstitutional.com/portal/notifications">

                            <i class="anticon anticon-notification"></i>

                            <span>
                                Notifications
                            </span>

                        </a>

                    </li>

                    <li class="side-nav-item">

                        <form
                            method="POST"
                            action="/logout"
                            class="logout-form"
                        >

                            <button
                                type="submit"
                                class="site-btn grad-btn w-100"
                            >

                                <i class="anticon anticon-logout"></i>

                                <span>
                                    Logout
                                </span>

                            </button>

                        </form>

                    </li>

                </ul>

            </div>

        </div>

    </div>
    <!-- /Desktop Sidebar -->


    <!-- Page Container -->
    <div class="page-container">

        <div class="main-content">

            <div class="section-gap">

                <div class="container-fluid">