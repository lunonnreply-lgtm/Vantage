<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'All Notifications';
$activeMenu = 'notifications';
$canonicalPath = '/portal/notifications';

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">All Notifications</h3>
            </div>
            <div class="site-card-body">
                <div class="notification-list">
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>