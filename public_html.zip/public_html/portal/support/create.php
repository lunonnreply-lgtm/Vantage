<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Create Support Ticket';
$activeMenu = 'support';
$canonicalPath = '/portal/support/create';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = (string) $_SESSION['csrf_token'];

$formError = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $submittedToken = isset($_POST['csrf_token'])
        ? (string) $_POST['csrf_token']
        : '';

    if (
        $submittedToken === '' ||
        !hash_equals($csrfToken, $submittedToken)
    ) {
        $formError = 'Invalid security token. Refresh the page and try again.';
    } else {

        $subject = trim(
            (string) ($_POST['subject'] ?? '')
        );

        $category = trim(
            (string) ($_POST['category'] ?? 'general')
        );

        $message = trim(
            (string) ($_POST['message'] ?? '')
        );

        if (
            $subject === '' ||
            strlen($subject) > 180 ||
            $category === '' ||
            strlen($category) > 60 ||
            $message === '' ||
            strlen($message) > 5000
        ) {
            $formError = 'Enter a valid subject, category, and message.';
        } else {

            $allowedCategories = [
                'general',
                'deposit',
                'withdrawal',
                'investment',
                'transfer',
                'account',
                'technical'
            ];

            if (!in_array($category, $allowedCategories, true)) {
                $formError = 'Invalid support category.';
            } else {

                $pdo->beginTransaction();

                try {

                    do {
                        $reference = 'SUPT' . str_pad(
                            (string) random_int(0, 999999),
                            6,
                            '0',
                            STR_PAD_LEFT
                        );

                        $referenceCheck = $pdo->prepare("
                            SELECT id
                            FROM support_tickets
                            WHERE reference = :reference
                            LIMIT 1
                        ");

                        $referenceCheck->execute([
                            ':reference' => $reference,
                        ]);

                        $referenceExists = $referenceCheck->fetchColumn();
                    } while ($referenceExists);

                    $ticketQuery = $pdo->prepare("
                        INSERT INTO support_tickets
                            (
                                user_id,
                                reference,
                                subject,
                                category,
                                status
                            )
                        VALUES
                            (
                                :user_id,
                                :reference,
                                :subject,
                                :category,
                                'open'
                            )
                    ");

                    $ticketQuery->execute([
                        ':user_id' => $userId,
                        ':reference' => $reference,
                        ':subject' => $subject,
                        ':category' => $category,
                    ]);

                    $ticketId = (int) $pdo->lastInsertId();

                    if ($ticketId <= 0) {
                        throw new RuntimeException(
                            'Ticket could not be created.'
                        );
                    }

                    $messageQuery = $pdo->prepare("
                        INSERT INTO support_ticket_messages
                            (
                                ticket_id,
                                author_user_id,
                                message
                            )
                        VALUES
                            (
                                :ticket_id,
                                :author_user_id,
                                :message
                            )
                    ");

                    $messageQuery->execute([
                        ':ticket_id' => $ticketId,
                        ':author_user_id' => $userId,
                        ':message' => $message,
                    ]);

                    $pdo->commit();

                    header(
                        'Location: /portal/support/view?id=' . $ticketId,
                        true,
                        303
                    );

                    exit;

                } catch (Throwable $exception) {

                    if ($pdo->inTransaction()) {
                        $pdo->rollBack();
                    }

                    $formError =
                        'Support ticket could not be submitted. Please try again.';
                }
            }
        }
    }
}

$extraStyles = <<<'HTML'
<style>
.support-create-card {
    max-width: 900px;
    margin: 0 auto;
}

.support-form-group {
    margin-bottom: 20px;
}

.support-form-label {
    display: block;
    margin-bottom: 8px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
}

.support-form-control {
    width: 100%;
    padding: 12px 14px;
    border: 1px solid rgba(255, 255, 255, 0.10);
    border-radius: 5px;
    outline: none;
    background: rgba(255, 255, 255, 0.03);
    color: #ffffff;
    font-size: 14px;
}

.support-form-control:focus {
    border-color: rgba(251, 191, 36, 0.55);
}

.support-form-control::placeholder {
    color: rgba(255, 255, 255, 0.40);
}

textarea.support-form-control {
    min-height: 180px;
    resize: vertical;
}

.support-form-actions {
    display: flex;
    align-items: center;
    gap: 12px;
    margin-top: 25px;
}

.support-submit-btn,
.support-cancel-btn {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    min-height: 44px;
    padding: 0 20px;
    border-radius: 5px;
    font-size: 14px;
    font-weight: 500;
    cursor: pointer;
    text-decoration: none;
}

.support-submit-btn {
    border: 0;
    background: #fbbf24;
    color: #111827;
}

.support-cancel-btn {
    border: 1px solid rgba(255, 255, 255, 0.12);
    background: transparent;
    color: rgba(255, 255, 255, 0.75);
}

.support-form-message {
    margin-bottom: 20px;
    padding: 12px 15px;
    border-radius: 5px;
    font-size: 14px;
    border: 1px solid rgba(239, 68, 68, 0.25);
    background: rgba(239, 68, 68, 0.08);
    color: #fca5a5;
}

@media (max-width: 576px) {
    .support-form-actions {
        flex-direction: column;
        align-items: stretch;
    }

    .support-submit-btn,
    .support-cancel-btn {
        width: 100%;
    }
}
</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">
        <div class="site-card support-create-card">

            <div class="site-card-header">
                <h3 class="title">Create Ticket</h3>

                <div class="card-header-links">
                    <a
                        href="/portal/support"
                        class="card-header-link"
                    >
                        Support Tickets
                    </a>
                </div>
            </div>

            <div class="site-card-body">

                <?php if ($formError !== ''): ?>

                    <div class="support-form-message">
                        <?php echo htmlspecialchars(
                            $formError,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>
                    </div>

                <?php endif; ?>

                <form
                    method="POST"
                    action="/portal/support/create"
                >

                    <input
                        type="hidden"
                        name="csrf_token"
                        value="<?php echo htmlspecialchars(
                            $csrfToken,
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>"
                    >

                    <div class="support-form-group">

                        <label
                            for="subject"
                            class="support-form-label"
                        >
                            Subject
                        </label>

                        <input
                            type="text"
                            id="subject"
                            name="subject"
                            class="support-form-control"
                            maxlength="180"
                            placeholder="Enter ticket subject"
                            value="<?php echo htmlspecialchars(
                                (string) ($_POST['subject'] ?? ''),
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>"
                            required
                        >

                    </div>

                    <div class="support-form-group">

                        <label
                            for="category"
                            class="support-form-label"
                        >
                            Category
                        </label>

                        <select
                            id="category"
                            name="category"
                            class="support-form-control"
                            required
                        >

                            <?php
                            $selectedCategory = (string) (
                                $_POST['category'] ?? 'general'
                            );
                            ?>

                            <option
                                value="general"
                                <?php echo $selectedCategory === 'general' ? 'selected' : ''; ?>
                            >
                                General
                            </option>

                            <option
                                value="deposit"
                                <?php echo $selectedCategory === 'deposit' ? 'selected' : ''; ?>
                            >
                                Deposit
                            </option>

                            <option
                                value="withdrawal"
                                <?php echo $selectedCategory === 'withdrawal' ? 'selected' : ''; ?>
                            >
                                Withdrawal
                            </option>

                            <option
                                value="investment"
                                <?php echo $selectedCategory === 'investment' ? 'selected' : ''; ?>
                            >
                                Investment
                            </option>

                            <option
                                value="transfer"
                                <?php echo $selectedCategory === 'transfer' ? 'selected' : ''; ?>
                            >
                                Transfer
                            </option>

                            <option
                                value="account"
                                <?php echo $selectedCategory === 'account' ? 'selected' : ''; ?>
                            >
                                Account
                            </option>

                            <option
                                value="technical"
                                <?php echo $selectedCategory === 'technical' ? 'selected' : ''; ?>
                                >
                                Technical
                            </option>

                        </select>

                    </div>

                    <div class="support-form-group">

                        <label
                            for="message"
                            class="support-form-label"
                        >
                            Message
                        </label>

                        <textarea
                            id="message"
                            name="message"
                            class="support-form-control"
                            maxlength="5000"
                            placeholder="Describe your issue..."
                            required
                        ><?php echo htmlspecialchars(
                            (string) ($_POST['message'] ?? ''),
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?></textarea>

                    </div>

                    <div class="support-form-actions">

                        <button
                            type="submit"
                            class="support-submit-btn"
                        >
                            Submit Ticket
                        </button>

                        <a
                            href="/portal/support"
                            class="support-cancel-btn"
                        >
                            Cancel
                        </a>

                    </div>

                </form>

            </div>

        </div>
    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>