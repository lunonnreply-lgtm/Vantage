<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$ticketId = isset($_GET['id']) ? (int) $_GET['id'] : 0;

if ($ticketId <= 0) {
    header('Location: /portal/support');
    exit;
}

$ticketQuery = $pdo->prepare('
    SELECT
        st.id,
        st.reference,
        st.subject,
        st.category,
        st.status,
        st.created_at,
        st.updated_at,
        u.first_name,
        u.last_name,
        u.email
    FROM support_tickets st
    INNER JOIN users u
        ON u.id = st.user_id
    WHERE st.id = :ticket_id
      AND st.user_id = :user_id
    LIMIT 1
');

$ticketQuery->execute([
    'ticket_id' => $ticketId,
    'user_id' => $userId,
]);

$ticket = $ticketQuery->fetch();

if (!$ticket) {
    header('Location: /portal/support');
    exit;
}

$messageQuery = $pdo->prepare('
    SELECT
        stm.id,
        stm.author_user_id,
        stm.message,
        stm.created_at,
        u.first_name,
        u.last_name,
        u.email,
        u.role
    FROM support_ticket_messages stm
    INNER JOIN users u
        ON u.id = stm.author_user_id
    WHERE stm.ticket_id = :ticket_id
    ORDER BY stm.created_at ASC, stm.id ASC
');

$messageQuery->execute([
    'ticket_id' => $ticketId,
]);

$messages = $messageQuery->fetchAll();

/*
 * Load attachments for this ticket and group them by message.
 */
$attachmentQuery = $pdo->prepare('
    SELECT
        id,
        message_id,
        original_name,
        mime_type,
        file_size,
        created_at
    FROM support_ticket_attachments
    WHERE ticket_id = :ticket_id
    ORDER BY id ASC
');

$attachmentQuery->execute([
    'ticket_id' => $ticketId,
]);

$attachments = $attachmentQuery->fetchAll();

$attachmentsByMessage = [];

foreach ($attachments as $attachment) {
    $messageId = (int) $attachment['message_id'];

    if (!isset($attachmentsByMessage[$messageId])) {
        $attachmentsByMessage[$messageId] = [];
    }

    $attachmentsByMessage[$messageId][] = $attachment;
}

$pageTitle = 'Support Ticket';
$activeMenu = 'support';
$canonicalPath = '/portal/support/view?id=' . $ticketId;

if (!isset($_SESSION['csrf_token']) || !is_string($_SESSION['csrf_token']) || $_SESSION['csrf_token'] === '') {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = $_SESSION['csrf_token'];

$extraStyles = <<<'HTML'
<style>
.support-ticket-view {
    display: flex;
    flex-direction: column;
    gap: 20px;
}

.support-ticket-view-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
}

.support-ticket-view-title {
    margin: 0;
    color: #ffffff;
    font-size: 18px;
    font-weight: 600;
}

.support-ticket-view-reference {
    color: rgba(255, 255, 255, 0.55);
    font-size: 14px;
    font-weight: 400;
}

.support-ticket-view-status {
    color: #22c55e;
    font-size: 14px;
    font-weight: 400;
}

.support-ticket-view-status.closed {
    color: rgba(255, 255, 255, 0.5);
}

.support-ticket-close-button {
    display: inline-flex;
    align-items: center;
    justify-content: center;
    gap: 7px;
    min-height: 36px;
    padding: 0 14px;
    border: 1px solid rgba(34, 197, 94, 0.35);
    border-radius: 4px;
    background: transparent;
    color: #22c55e;
    font-size: 13px;
    cursor: pointer;
    transition: all 0.2s ease;
}

.support-ticket-close-button:hover {
    border-color: #22c55e;
    background: rgba(34, 197, 94, 0.08);
}

.support-ticket-close-button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.support-ticket-close-button svg {
    width: 15px;
    height: 15px;
}

.support-ticket-user {
    margin-bottom: 25px;
}

.support-ticket-user-name {
    margin: 0 0 5px;
    color: #ffffff;
    font-size: 15px;
    font-weight: 500;
}

.support-ticket-user-email {
    margin: 0;
    color: rgba(255, 255, 255, 0.55);
    font-size: 13px;
}

.support-ticket-messages {
    display: flex;
    flex-direction: column;
    gap: 18px;
}

.support-ticket-message {
    padding: 18px;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.02);
}

.support-ticket-message-header {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 15px;
    margin-bottom: 12px;
}

.support-ticket-message-author {
    margin: 0;
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
}

.support-ticket-message-email {
    display: block;
    margin-top: 3px;
    color: rgba(255, 255, 255, 0.45);
    font-size: 12px;
}

.support-ticket-message-date {
    color: rgba(255, 255, 255, 0.4);
    font-size: 12px;
    white-space: nowrap;
}

.support-ticket-message-body {
    margin: 0;
    color: rgba(255, 255, 255, 0.75);
    font-size: 14px;
    line-height: 1.7;
    white-space: pre-wrap;
    word-break: break-word;
}

.support-ticket-attachments {
    margin-top: 25px;
}

.support-ticket-section-title {
    margin: 0 0 12px;
    color: #ffffff;
    font-size: 14px;
    font-weight: 500;
}

.support-ticket-attachment {
    color: rgba(255, 255, 255, 0.65);
    font-size: 13px;
}

.support-ticket-reply {
    margin-top: 25px;
}

.support-ticket-reply textarea {
    width: 100%;
    min-height: 130px;
    resize: vertical;
}

.support-ticket-attachment-input {
    margin-top: 15px;
}

.support-ticket-submit {
    margin-top: 20px;
}

.support-ticket-submit button:disabled {
    opacity: 0.6;
    cursor: not-allowed;
}

.support-ticket-result {
    display: none;
    margin: 12px 0 0;
    font-size: 13px;
}

.support-ticket-result.success {
    display: block;
    color: #22c55e;
}

.support-ticket-result.error {
    display: block;
    color: #ef4444;
}

.support-ticket-back {
    margin-bottom: 20px;
}

.support-ticket-back a {
    color: rgba(255, 255, 255, 0.6);
    text-decoration: none;
    font-size: 13px;
}

.support-ticket-back a:hover {
    color: #ffffff;
}

.support-ticket-message-attachments {
    margin-top: 15px;
    padding-top: 12px;
    border-top: 1px solid rgba(255, 255, 255, 0.06);
}

.support-ticket-message-attachments-title {
    margin-bottom: 8px;
    color: rgba(255, 255, 255, 0.5);
    font-size: 12px;
    font-weight: 500;
}

.support-ticket-message-attachment {
    display: flex;
    align-items: center;
    gap: 7px;
    margin-top: 6px;
    color: rgba(255, 255, 255, 0.7);
    font-size: 13px;
    word-break: break-word;
}

.support-ticket-message-attachment-icon {
    flex: 0 0 auto;
    font-size: 13px;
}


.support-ticket-message-attachment-name {
    min-width: 0;
    color: #60a5fa;
    word-break: break-word;
    text-decoration: none;
}

.support-ticket-message-attachment-name:hover {
    text-decoration: underline;
}
@media (max-width: 576px) {
    .support-ticket-view-header {
        align-items: flex-start;
        flex-direction: column;
    }

    .support-ticket-message-header {
        align-items: flex-start;
        flex-direction: column;
    }
}
</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="support-ticket-back">
            <a href="/portal/support">
                &larr; Back to Support Tickets
            </a>
        </div>

        <div class="site-card">

            <div class="site-card-header">

                <div class="support-ticket-view-header">

                    <h3 class="title">

                        <?php echo htmlspecialchars(
                            (string) $ticket['subject'],
                            ENT_QUOTES,
                            'UTF-8'
                        ); ?>

                        <span class="support-ticket-view-reference">
                            -
                            <?php echo htmlspecialchars(
                                (string) $ticket['reference'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </span>

                        <?php
                        $ticketStatus = strtolower(
                            trim((string) $ticket['status'])
                        );
                        ?>

                        <span
                            class="support-ticket-view-status<?php echo $ticketStatus === 'closed' ? ' closed' : ''; ?>"
                            data-ticket-status
                        >
                            <?php echo $ticketStatus === 'open'
                                ? 'Opened'
                                : htmlspecialchars(
                                    ucwords(
                                        str_replace(
                                            ['_', '-'],
                                            ' ',
                                            $ticketStatus
                                        )
                                    ),
                                    ENT_QUOTES,
                                    'UTF-8'
                                ); ?>
                        </span>

                    </h3>

                    <?php if ($ticketStatus === 'open'): ?>

                        <button
                            type="button"
                            class="support-ticket-close-button"
                            id="ticket-close-button"
                        >
                            <svg
                                viewBox="0 0 24 24"
                                fill="none"
                                stroke="currentColor"
                                stroke-width="2"
                                stroke-linecap="round"
                                stroke-linejoin="round"
                                aria-hidden="true"
                            >
                                <path d="M20 6L9 17l-5-5"></path>
                            </svg>

                            Mark it close
                        </button>

                    <?php endif; ?>

                </div>

            </div>

            <div class="site-card-body">

                <div class="support-ticket-view">

                    <div class="support-ticket-user">

                        <p class="support-ticket-user-name">
                            <?php echo htmlspecialchars(
                                trim(
                                    (string) $ticket['first_name'] . ' ' .
                                    (string) $ticket['last_name']
                                ),
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </p>

                        <p class="support-ticket-user-email">
                            <?php echo htmlspecialchars(
                                (string) $ticket['email'],
                                ENT_QUOTES,
                                'UTF-8'
                            ); ?>
                        </p>

                    </div>

                    <div class="support-ticket-messages">

                        <?php foreach ($messages as $message): ?>

                            <div class="support-ticket-message">

                                <div class="support-ticket-message-header">

                                    <div>

                                        <p class="support-ticket-message-author">
                                            <?php echo htmlspecialchars(
                                                trim(
                                                    (string) $message['first_name'] . ' ' .
                                                    (string) $message['last_name']
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ); ?>
                                        </p>

                                        <span class="support-ticket-message-email">
                                            <?php echo htmlspecialchars(
                                                (string) $message['email'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ); ?>
                                        </span>

                                    </div>

                                    <span class="support-ticket-message-date">
                                        <?php
                                        $messageTime = strtotime(
                                            (string) $message['created_at']
                                        );

                                        echo $messageTime !== false
                                            ? htmlspecialchars(
                                                date(
                                                    'M d Y H:i',
                                                    $messageTime
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            )
                                            : '';
                                        ?>
                                    </span>

                                </div>

                                <p class="support-ticket-message-body">
                                    <?php echo htmlspecialchars(
                                        (string) $message['message'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ); ?>
                                </p>

                                <?php
                                $messageId = (int) $message['id'];
                                $messageAttachments =
                                    $attachmentsByMessage[$messageId] ?? [];
                                ?>

                                <?php if ($messageAttachments): ?>

                                    <div class="support-ticket-message-attachments">

                                        <div class="support-ticket-message-attachments-title">
                                            Attachment<?php echo count($messageAttachments) > 1 ? 's' : ''; ?>
                                        </div>

                                        <?php foreach ($messageAttachments as $attachment): ?>

                                            <div class="support-ticket-message-attachment">
                                                <span
                                                    class="support-ticket-message-attachment-icon"
                                                    aria-hidden="true"
                                                >📎</span>

                                                <a
    class="support-ticket-message-attachment-name"
    href="/api/user/support-attachment.php?id=<?php echo (int) $attachment['id']; ?>"
    target="_blank"
    rel="noopener noreferrer"
>
    <?php echo htmlspecialchars(
        (string) $attachment['original_name'],
        ENT_QUOTES,
        'UTF-8'
    ); ?>
</a>
                                            </div>

                                        <?php endforeach; ?>

                                    </div>

                                <?php endif; ?>

                            </div>

                        <?php endforeach; ?>

                    </div>

                    <?php if ($ticketStatus === 'open'): ?>

                        <div class="support-ticket-reply">

                            <h4 class="support-ticket-section-title">
                                Write Reply
                            </h4>

                            <textarea
                                class="form-control"
                                id="ticket-reply"
                                maxlength="5000"
                                placeholder="Write your reply..."
                            ></textarea>

                            <div class="support-ticket-attachment-input">
                                <input
                                    type="file"
                                    id="ticket-attachment"
                                    accept="image/*"
                                >
                            </div>

                            <div class="support-ticket-submit">

                                <button
                                    type="button"
                                    class="site-btn blue-btn"
                                    id="ticket-reply-submit"
                                >
                                    Submit
                                </button>

                                <p
                                    class="support-ticket-result"
                                    id="ticket-reply-result"
                                    role="status"
                                ></p>

                            </div>

                        </div>

                    <?php endif; ?>

                </div>

            </div>

        </div>

    </div>
</div>

<script>
(function () {
    'use strict';

    var csrfToken = <?php echo json_encode($csrfToken); ?>;
    var ticketId = <?php echo (int) $ticketId; ?>;

    var closeButton = document.getElementById('ticket-close-button');
    var replyButton = document.getElementById('ticket-reply-submit');
    var replyField = document.getElementById('ticket-reply');
    var resultBox = document.getElementById('ticket-reply-result');
    var statusElement = document.querySelector('[data-ticket-status]');

    function showResult(message, type) {
        if (!resultBox) {
            return;
        }

        resultBox.textContent = message;
        resultBox.className = 'support-ticket-result ' + type;
    }

    function parseResponse(response) {
        return response.text().then(function (text) {
            var data = {};

            try {
                data = text ? JSON.parse(text) : {};
            } catch (error) {
                data = {};
            }

            return {
                ok: response.ok,
                status: response.status,
                data: data
            };
        });
    }

    if (replyButton) {
        replyButton.addEventListener('click', function () {
            var message = replyField
                ? replyField.value.trim()
                : '';

            if (message === '') {
                showResult('Write your reply first.', 'error');
                return;
            }

            replyButton.disabled = true;
            showResult('', '');

            var attachmentField = document.getElementById('ticket-attachment');
            var formData = new FormData();

            formData.append('ticketId', String(ticketId));
            formData.append('message', message);

            if (
                attachmentField &&
                attachmentField.files &&
                attachmentField.files.length > 0
            ) {
                var attachmentFile = attachmentField.files[0];

                if (attachmentFile.size > 5 * 1024 * 1024) {
                    showResult(
                        'Attachment must be smaller than 5 MB.',
                        'error'
                    );
                    replyButton.disabled = false;
                    return;
                }

                formData.append('attachment', attachmentFile);
            }

            fetch('/api/user/support-reply.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRF-Token': csrfToken
                },
                body: formData
            })
            .then(parseResponse)
            .then(function (result) {
                if (!result.ok) {
                    throw new Error(
                        result.data.error ||
                        'Reply could not be submitted.'
                    );
                }

                showResult(
                    result.data.message ||
                    'Reply submitted successfully.',
                    'success'
                );

                if (replyField) {
                    replyField.value = '';
                }

                setTimeout(function () {
                    window.location.reload();
                }, 700);
            })
            .catch(function (error) {
                showResult(
                    error.message ||
                    'Reply could not be submitted.',
                    'error'
                );

                replyButton.disabled = false;
            });
        });
    }

    if (closeButton) {
        closeButton.addEventListener('click', function () {
            if (!window.confirm('Mark this ticket as closed?')) {
                return;
            }

            closeButton.disabled = true;

            fetch('/api/user/support-close.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify({
                    ticketId: ticketId
                })
            })
            .then(parseResponse)
            .then(function (result) {
                if (!result.ok) {
                    throw new Error(
                        result.data.error ||
                        'Ticket could not be closed.'
                    );
                }

                if (statusElement) {
                    statusElement.textContent = 'Closed';
                    statusElement.classList.add('closed');
                }

                closeButton.remove();

                var replySection = document.querySelector(
                    '.support-ticket-reply'
                );

                if (replySection) {
                    replySection.remove();
                }
            })
            .catch(function (error) {
                window.alert(
                    error.message ||
                    'Ticket could not be closed.'
                );

                closeButton.disabled = false;
            });
        });
    }
})();
</script>

<?php require __DIR__ . '/../_footer.php'; ?>