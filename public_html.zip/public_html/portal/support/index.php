<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Support Tickets';
$activeMenu = 'support';
$canonicalPath = '/portal/support';

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_start();
}

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$csrfToken = (string) $_SESSION['csrf_token'];

$stmt = $pdo->prepare("
    SELECT
        id,
        reference,
        subject,
        status,
        created_at
    FROM support_tickets
    WHERE user_id = :user_id
    ORDER BY created_at DESC, id DESC
");

$stmt->execute([
    ':user_id' => $userId,
]);

$tickets = $stmt->fetchAll();

$extraStyles = <<<'HTML'
<style>
.support-ticket-list {
    display: flex;
    flex-direction: column;
    gap: 15px;
}

.support-ticket-item {
    display: flex;
    align-items: center;
    justify-content: space-between;
    gap: 20px;
    padding: 18px 20px;
    border: 1px solid rgba(255, 255, 255, 0.08);
    border-radius: 6px;
    background: rgba(255, 255, 255, 0.02);
    transition: all 0.2s ease;
}

.support-ticket-item:hover {
    border-color: rgba(255, 255, 255, 0.14);
    background: rgba(255, 255, 255, 0.035);
}

.support-ticket-content {
    min-width: 0;
    flex: 1;
}

.support-ticket-link {
    color: inherit;
    text-decoration: none;
}

.support-ticket-title {
    margin: 0;
    color: #ffffff;
    font-size: 15px;
    font-weight: 500;
    line-height: 1.5;
}

.support-ticket-status {
    margin-left: 5px;
    color: #22c55e;
}

.support-ticket-status.closed {
    color: rgba(255, 255, 255, 0.45);
}

.support-ticket-actions {
    display: flex;
    align-items: center;
    gap: 8px;
    flex-shrink: 0;
}

.support-ticket-action {
    width: 34px;
    height: 34px;
    display: inline-flex;
    align-items: center;
    justify-content: center;
    border: 1px solid rgba(255, 255, 255, 0.10);
    border-radius: 50%;
    background: transparent;
    color: rgba(255, 255, 255, 0.65);
    text-decoration: none;
    cursor: pointer;
    transition: all 0.2s ease;
}

.support-ticket-action:hover {
    color: #ffffff;
    background: rgba(255, 255, 255, 0.06);
}

.support-ticket-close {
    border-color: rgba(34, 197, 94, 0.25);
    color: #22c55e;
}

.support-ticket-close:hover {
    border-color: rgba(34, 197, 94, 0.45);
    background: rgba(34, 197, 94, 0.08);
}

.support-ticket-close.closed {
    opacity: 0.35;
    cursor: not-allowed;
}

.support-ticket-eye {
    color: rgba(255, 255, 255, 0.60);
}

.support-ticket-message {
    display: none;
    margin-bottom: 15px;
    padding: 12px 15px;
    border-radius: 5px;
    font-size: 14px;
}

.support-ticket-message.error {
    display: block;
    border: 1px solid rgba(239, 68, 68, 0.25);
    background: rgba(239, 68, 68, 0.08);
    color: #fca5a5;
}

@media (max-width: 576px) {
    .support-ticket-item {
        padding: 15px;
    }

    .support-ticket-actions {
        gap: 5px;
    }

    .support-ticket-action {
        width: 32px;
        height: 32px;
    }
}
</style>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">
        <div class="site-card">

            <div class="site-card-header">
                <h3 class="title">Support Tickets</h3>

                <div class="card-header-links">
                    <a href="/portal/support/create" class="card-header-link">
                        Create Ticket
                    </a>
                </div>
            </div>

            <div class="site-card-body">

                <div
                    id="supportTicketMessage"
                    class="support-ticket-message"
                ></div>

                <?php if (empty($tickets)): ?>

                    <div class="site-transactions">
                        <div class="no-data-found">
                            No Data Found
                        </div>
                    </div>

                <?php else: ?>

                    <div class="support-ticket-list">

                        <?php foreach ($tickets as $ticket): ?>

                            <?php
                            $ticketId = (int) ($ticket['id'] ?? 0);

                            $subject = trim(
                                (string) ($ticket['subject'] ?? '')
                            );

                            $reference = trim(
                                (string) ($ticket['reference'] ?? '')
                            );

                            $status = strtolower(
                                trim(
                                    (string) ($ticket['status'] ?? '')
                                )
                            );

                            $isOpen = $status === 'open';

                            $statusLabel = $isOpen
                                ? 'Opened'
                                : ucwords(
                                    str_replace(
                                        ['_', '-'],
                                        ' ',
                                        $status
                                    )
                                );

                            $statusClass = $isOpen
                                ? ''
                                : 'closed';
                            ?>

                            <div
                                class="support-ticket-item"
                                data-ticket-id="<?php echo $ticketId; ?>"
                            >

                                <a
                                    href="/portal/support/view?id=<?php echo $ticketId; ?>"
                                    class="support-ticket-link support-ticket-content"
                                >
                                    <p class="support-ticket-title">

                                        <?php echo htmlspecialchars(
                                            $subject,
                                            ENT_QUOTES,
                                            'UTF-8'
                                        ); ?>

                                        <?php if ($reference !== ''): ?>

                                            -
                                            <?php echo htmlspecialchars(
                                                $reference,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ); ?>

                                        <?php endif; ?>

                                        <span
                                            class="support-ticket-status <?php echo $statusClass; ?>"
                                            data-ticket-status
                                        >
                                            <?php echo htmlspecialchars(
                                                $statusLabel,
                                                ENT_QUOTES,
                                                'UTF-8'
                                            ); ?>
                                        </span>

                                    </p>
                                </a>

                                <div class="support-ticket-actions">

                                    <button
                                        type="button"
                                        class="support-ticket-action support-ticket-close <?php echo $isOpen ? '' : 'closed'; ?>"
                                        data-ticket-close
                                        data-ticket-id="<?php echo $ticketId; ?>"
                                        title="<?php echo $isOpen ? 'Close ticket' : 'Ticket closed'; ?>"
                                        <?php echo $isOpen ? '' : 'disabled'; ?>
                                    >
                                        ✓
                                    </button>

                                    <a
                                        href="/portal/support/view?id=<?php echo $ticketId; ?>"
                                        class="support-ticket-action support-ticket-eye"
                                        title="View ticket"
                                    >
                                        <svg
                                            width="16"
                                            height="16"
                                            viewBox="0 0 24 24"
                                            fill="none"
                                            stroke="currentColor"
                                            stroke-width="2"
                                            stroke-linecap="round"
                                            stroke-linejoin="round"
                                        >
                                            <path d="M2 12s3.5-7 10-7 10 7 10 7-3.5 7-10 7S2 12 2 12z"></path>
                                            <circle cx="12" cy="12" r="3"></circle>
                                        </svg>
                                    </a>

                                </div>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </div>

        </div>
    </div>
</div>

<script>
(function () {
    'use strict';

    var csrfToken = <?php echo json_encode($csrfToken); ?>;
    var messageBox = document.getElementById('supportTicketMessage');

    var closeButtons = document.querySelectorAll(
        '[data-ticket-close]:not([disabled])'
    );

    function showError(message) {
        messageBox.textContent = message;
        messageBox.className = 'support-ticket-message error';
    }

    closeButtons.forEach(function (button) {

        button.addEventListener('click', function (event) {

            event.preventDefault();
            event.stopPropagation();

            var ticketId = parseInt(
                button.getAttribute('data-ticket-id') || '0',
                10
            );

            if (ticketId <= 0) {
                return;
            }

            if (!window.confirm('Close this support ticket?')) {
                return;
            }

            button.disabled = true;
            button.textContent = '...';

            fetch('/api/user/support-close.php', {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'Content-Type': 'application/json',
                    'X-CSRF-Token': csrfToken
                },
                body: JSON.stringify({
                    ticketId: ticketId
                })
            })
            .then(function (response) {
                return response.json().then(function (data) {
                    return {
                        ok: response.ok,
                        data: data
                    };
                });
            })
            .then(function (result) {

                if (!result.ok) {
                    throw new Error(
                        result.data.error ||
                        'Ticket could not be closed.'
                    );
                }

                button.classList.add('closed');
                button.disabled = true;
                button.textContent = '✓';
                button.title = 'Ticket closed';

                var ticketItem = button.closest(
                    '.support-ticket-item'
                );

                if (ticketItem) {

                    var status =
                        ticketItem.querySelector(
                            '[data-ticket-status]'
                        );

                    if (status) {
                        status.textContent = 'Closed';
                        status.classList.add('closed');
                    }
                }

            })
            .catch(function (error) {

                button.disabled = false;
                button.textContent = '✓';

                showError(
                    error.message ||
                    'Ticket could not be closed.'
                );
            });
        });
    });
})();
</script>

<?php require __DIR__ . '/../_footer.php'; ?>