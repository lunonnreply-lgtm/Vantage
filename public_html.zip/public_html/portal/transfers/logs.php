<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$pageTitle = 'Transfer Logs';
$activeMenu = 'transfers-logs';
$canonicalPath = '/portal/transfers/logs';

$extraStyles = <<<'HTML'
    <style>

        .transfer-log-search {
            display: flex;
            gap: 10px;
            flex-wrap: wrap;
            margin-bottom: 25px;
        }

        .transfer-log-search input {
            min-height: 45px;
            padding: 0 15px;
            border: 1px solid rgba(128, 128, 128, 0.25);
            border-radius: 5px;
            background: transparent;
        }

        .transfer-log-search .apply-btn {
            min-height: 45px;
            padding: 0 25px;
            border: 0;
            border-radius: 5px;
            cursor: pointer;
        }

        .transfer-log-empty {
            text-align: center;
            padding: 35px 15px !important;
        }

    </style>
HTML;

/*
|--------------------------------------------------------------------------
| Transfer Logs
|--------------------------------------------------------------------------
*/
$search = trim((string) ($_GET['query'] ?? ''));
$date = trim((string) ($_GET['date'] ?? ''));

$sql = '
    SELECT
        reference,
        amount,
        currency,
        status,
        note,
        created_at
    FROM transfers
    WHERE sender_user_id = :user_id
';

$params = [
    'user_id' => $userId
];

if ($search !== '') {
    $sql .= ' AND (reference LIKE :search OR status LIKE :search)';
    $params['search'] = '%' . $search . '%';
}

if ($date !== '') {
    $sql .= ' AND DATE(created_at) = :transfer_date';
    $params['transfer_date'] = $date;
}

$sql .= ' ORDER BY created_at DESC LIMIT 250';

$query = $pdo->prepare($sql);
$query->execute($params);

$transfers = $query->fetchAll();

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-12">

        <div class="site-card">

            <div class="site-card-header">
                <h3 class="title">All Send Money Log</h3>
            </div>

            <div class="site-card-body">

                <div class="site-table">

                    <form method="get" action="/portal/transfers/logs">

                        <div class="transfer-log-search">

                            <input
                                type="text"
                                name="query"
                                placeholder="Search reference or status"
                                value="<?= htmlspecialchars($search, ENT_QUOTES, 'UTF-8') ?>"
                            >

                            <input
                                type="date"
                                name="date"
                                value="<?= htmlspecialchars($date, ENT_QUOTES, 'UTF-8') ?>"
                            >

                            <button type="submit" class="apply-btn">Search</button>

                        </div>

                    </form>


                    <div class="table-responsive">

                        <table class="table table-hover">

                            <thead>
                                <tr>
                                    <th>Description</th>
                                    <th>Transaction ID</th>
                                    <th>Amount</th>
                                    <th>Status</th>
                                    <th>Date</th>
                                </tr>
                            </thead>

                            <tbody>

                            <?php if ($transfers): ?>

                                <?php foreach ($transfers as $transfer): ?>

                                    <tr>

                                        <td>

                                            <div class="table-description">

                                                <div class="icon">
                                                    <i class="anticon anticon-export"></i>
                                                </div>

                                                <div class="description">
                                                    <strong>
                                                        <?= htmlspecialchars(
                                                            (string) ($transfer['note'] ?: 'Send money'),
                                                            ENT_QUOTES,
                                                            'UTF-8'
                                                        ) ?>
                                                    </strong>
                                                </div>

                                            </div>

                                        </td>

                                        <td>
                                            <strong>
                                                <?= htmlspecialchars((string) $transfer['reference'], ENT_QUOTES, 'UTF-8') ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <strong>
                                                <?= htmlspecialchars((string) $transfer['currency'], ENT_QUOTES, 'UTF-8') ?>
                                                <?= number_format((float) $transfer['amount'], 2) ?>
                                            </strong>
                                        </td>

                                        <td>
                                            <div class="site-badge">
                                                <?= htmlspecialchars(ucfirst((string) $transfer['status']), ENT_QUOTES, 'UTF-8') ?>
                                            </div>
                                        </td>

                                        <td>
                                            <?= htmlspecialchars((string) $transfer['created_at'], ENT_QUOTES, 'UTF-8') ?>
                                        </td>

                                    </tr>

                                <?php endforeach; ?>

                            <?php else: ?>

                                <tr class="centered">
                                    <td colspan="5" class="transfer-log-empty">
                                        No transfer records found.
                                    </td>
                                </tr>

                            <?php endif; ?>

                            </tbody>

                        </table>

                    </div>

                </div>

            </div>

        </div>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>