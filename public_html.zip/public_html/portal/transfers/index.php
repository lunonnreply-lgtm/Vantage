<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

if (!isset($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$pageTitle = 'Send Money';
$activeMenu = 'transfers';
$canonicalPath = '/portal/transfers';

$success = isset($_GET['success']) && $_GET['success'] === '1';
$reference = isset($_GET['reference'])
    ? trim((string) $_GET['reference'])
    : '';

$error = isset($_GET['error'])
    ? (string) $_GET['error']
    : '';

$successTransfer = null;

if ($success && $reference !== '') {

    $successQuery = $pdo->prepare(
        "SELECT
            t.reference,
            t.amount,
            t.fee,
            t.currency,
            t.status,
            t.note,
            u.email AS recipient_email,
            u.first_name AS recipient_first_name,
            u.last_name AS recipient_last_name
         FROM transfers t
         INNER JOIN users u
             ON u.id = t.recipient_user_id
         WHERE t.sender_user_id = :user_id
           AND t.reference = :reference
         LIMIT 1"
    );

    $successQuery->execute([
        'user_id' => $userId,
        'reference' => $reference
    ]);

    $successTransfer = $successQuery->fetch();

    if (!$successTransfer) {
        $success = false;
    }
}

$extraStyles = <<<'HTML'
<style>
.deposit-success {
    display: none;
}

.deposit-success.show {
    display: block;
}

.deposit-pending-icon {
    width: 80px;
    height: 80px;
    margin: 0 auto 25px;
    border: 3px solid #28a745;
    border-radius: 50%;
    display: flex;
    align-items: center;
    justify-content: center;
    font-size: 42px;
    line-height: 1;
    color: #28a745;
}

.deposit-pending-message {
    text-align: center;
    margin-bottom: 30px;
}
</style>
HTML;

$extraScripts = <<<'HTML'
<script>
"use strict";

$(document).on('input', '.sendAmount', function () {
    var amount = $(this).val();

    $('.previewAmount').text(amount);

    var charge = 0;
    var chargeType = 'percentage';

    var finalCharge;

    if (chargeType === 'percentage') {
        finalCharge = calPercentage(amount, charge);
    } else {
        finalCharge = charge;
    }

    $('.previewCharge').text(finalCharge);
});

$(document).on('change input', '.userCheck', function () {
    var email = $(this).val();

    $('.userEmail').text(email);
});
</script>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-12 col-xl-12">

        <div class="site-card">

            <div class="site-card-header">
                <h3 class="title">Send Money</h3>

                <div class="card-header-links">
                    <a href="/portal/transfers/logs"
                       class="card-header-link">
                        SEND MONEY LOG
                    </a>
                </div>
            </div>

            <div class="site-card-body">

                <?php if (!$success): ?>

                    <div class="progress-steps">

                        <div class="single-step current">
                            <div class="number">01</div>

                            <div class="content">
                                <h4>Payment Details</h4>
                                <p>Enter your Payment details</p>
                            </div>
                        </div>

                        <div class="single-step">
                            <div class="number">02</div>

                            <div class="content">
                                <h4>Success</h4>
                                <p>Successfully Payment</p>
                            </div>
                        </div>

                    </div>

                    <?php if ($error !== ''): ?>

                        <div class="alert alert-danger" role="alert">
                            <?php
                            $errorMessages = [
                                'invalid-recipient' =>
                                    'Please enter a valid recipient email address.',

                                'recipient-not-found' =>
                                    'The recipient account could not be found.',

                                'recipient-inactive' =>
                                    'The recipient account is not active.',

                                'self-transfer' =>
                                    'You cannot send money to your own account.',

                                'sender-wallet-not-found' =>
                                    'Your main USD wallet could not be found.',

                                'recipient-wallet-not-found' =>
                                    'The recipient main USD wallet could not be found.',

                                'invalid-amount' =>
                                    'Please enter a valid transfer amount.',

                                'minimum-amount' =>
                                    'The minimum transfer amount is 10 USD.',

                                'maximum-amount' =>
                                    'The maximum transfer amount is 1,000,000 USD.',

                                'insufficient-balance' =>
                                    'You do not have enough available balance for this transfer.',

                                'balance-changed' =>
                                    'Your wallet balance changed before the transfer could be completed. Please try again.',

                                'credit-failed' =>
                                    'The recipient wallet could not be credited. No transfer was completed.',

                                'transfer-failed' =>
                                    'The transfer could not be completed. Please try again.'
                            ];

                            echo htmlspecialchars(
                                isset($errorMessages[$error])
                                    ? $errorMessages[$error]
                                    : 'Unable to process the transfer.',
                                ENT_QUOTES,
                                'UTF-8'
                            );
                            ?>
                        </div>

                    <?php endif; ?>

                    <div class="progress-steps-form">

                        <form action="/portal/transfers/now"
                              method="post">

                            <input type="hidden"
                                   name="csrf_token"
                                   value="<?php echo htmlspecialchars(
                                       $_SESSION['csrf_token'],
                                       ENT_QUOTES,
                                       'UTF-8'
                                   ); ?>">

                            <div class="row">

                                <div class="col-xl-6 col-md-12">

                                    <label for="userEmail"
                                           class="form-label">
                                        User Email
                                    </label>

                                    <div class="input-group">

                                        <input type="email"
                                               id="userEmail"
                                               name="email"
                                               required
                                               class="form-control userCheck"
                                               placeholder="User Email">

                                    </div>

                                    <div class="input-info-text notifyUser"></div>

                                </div>

                                <div class="col-xl-6 col-md-12">

                                    <label for="sendAmount"
                                           class="form-label">
                                        Enter Amount
                                    </label>

                                    <div class="input-group">

                                        <input type="text"
                                               id="sendAmount"
                                               class="form-control sendAmount"
                                               name="amount"
                                               required
                                               placeholder="Enter Amount"
                                               aria-label="Amount"
                                               oninput="this.value = validateDouble(this.value)"
                                               aria-describedby="basic-addon1">

                                        <span class="input-group-text"
                                              id="basic-addon1">
                                            USD
                                        </span>

                                    </div>

                                    <div class="input-info-text">
                                        Minimum 10 USD and Maximum 1000000 USD
                                    </div>

                                </div>

                                <div class="col-xl-12 col-md-12 mt-3">

                                    <label for="transferNote"
                                           class="form-label">
                                        Send Money Note (Optional)
                                    </label>

                                    <div class="input-group">

                                        <textarea
                                            id="transferNote"
                                            class="form-control-textarea"
                                            placeholder="Send Money Note"
                                            name="note"
                                            maxlength="500"></textarea>

                                    </div>

                                </div>

                            </div>

                            <div class="transaction-list table-responsive">

                                <div class="user-panel-title">
                                    <h3>Send Money Details</h3>
                                </div>

                                <table class="table">

                                    <tbody>

                                    <tr>
                                        <td>
                                            <strong>Payment Amount</strong>
                                        </td>

                                        <td>
                                            <span class="previewAmount"></span>
                                            USD
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Charge</strong>
                                        </td>

                                        <td>
                                            <span class="previewCharge">0</span>
                                            USD
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>User Email</strong>
                                        </td>

                                        <td class="userEmail"></td>
                                    </tr>

                                    </tbody>

                                </table>

                            </div>

                            <div class="buttons">

                                <button type="submit"
                                        class="site-btn blue-btn">
                                    Send Money
                                    <i class="anticon anticon-double-right"></i>
                                </button>

                            </div>

                        </form>

                    </div>

                <?php else: ?>

                    <div class="deposit-success show">

                        <div class="progress-steps">

                            <div class="single-step">
                                <div class="number">01</div>

                                <div class="content">
                                    <h4>Payment Details</h4>
                                    <p>Enter your Payment details</p>
                                </div>
                            </div>

                            <div class="single-step current">
                                <div class="number">02</div>

                                <div class="content">
                                    <h4>Success</h4>
                                    <p>Successfully Payment</p>
                                </div>
                            </div>

                        </div>

                        <div class="progress-steps-form">

                            <div class="deposit-pending-icon">
                                ✓
                            </div>

                            <div class="deposit-pending-message">

                                <h2>
                                    <?php
                                    echo htmlspecialchars(
                                        number_format(
                                            (float) $successTransfer['amount'],
                                            2
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    );
                                    ?>
                                    USD Payment Successful
                                </h2>

                                <p>
                                    Your payment has been successfully sent to the recipient.
                                </p>

                            </div>

                            <div class="transaction-list table-responsive">

                                <div class="user-panel-title">
                                    <h3>Transaction ID:</h3>
                                </div>

                                <table class="table">

                                    <tbody>

                                    <tr>
                                        <td>
                                            <strong>Transaction ID</strong>
                                        </td>

                                        <td>
                                            <?php
                                            echo htmlspecialchars(
                                                (string) $successTransfer['reference'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Amount</strong>
                                        </td>

                                        <td>
                                            <?php
                                            echo htmlspecialchars(
                                                number_format(
                                                    (float) $successTransfer['amount'],
                                                    2
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>
                                            USD
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Recipient</strong>
                                        </td>

                                        <td>
                                            <?php
                                            echo htmlspecialchars(
                                                (string) $successTransfer['recipient_email'],
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>
                                        </td>
                                    </tr>

                                    <tr>
                                        <td>
                                            <strong>Status</strong>
                                        </td>

                                        <td>
                                            <?php
                                            echo htmlspecialchars(
                                                ucfirst(
                                                    (string) $successTransfer['status']
                                                ),
                                                ENT_QUOTES,
                                                'UTF-8'
                                            );
                                            ?>
                                        </td>
                                    </tr>

                                    </tbody>

                                </table>

                            </div>

                            <div class="user-panel-title">

                                <h3>Success</h3>

                                <p>
                                    Your Payment Has Been Successfully Processed
                                </p>

                            </div>

                            <div class="buttons">

                                <a href="/portal/transfers"
                                   class="site-btn blue-btn">
                                    Send Money Again
                                </a>

                            </div>

                        </div>

                    </div>

                <?php endif; ?>

            </div>

        </div>

    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>