<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /portal/transfers');
    exit;
}

$sessionToken = isset($_SESSION['csrf_token'])
    ? (string) $_SESSION['csrf_token']
    : '';

$requestToken = isset($_POST['csrf_token'])
    ? (string) $_POST['csrf_token']
    : '';

if (
    $sessionToken === '' ||
    $requestToken === '' ||
    !hash_equals($sessionToken, $requestToken)
) {
    http_response_code(419);
    exit('Invalid security token. Refresh the page and try again.');
}

$email = trim((string) ($_POST['email'] ?? ''));
$rawAmount = trim((string) ($_POST['amount'] ?? ''));
$note = trim((string) ($_POST['note'] ?? ''));

if ($email === '' || !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    header('Location: /portal/transfers?error=invalid-recipient');
    exit;
}

if (
    $rawAmount === '' ||
    !preg_match(
        '/^(?:0|[1-9]\d{0,11})(?:\.\d{1,2})?$/',
        $rawAmount
    )
) {
    header('Location: /portal/transfers?error=invalid-amount');
    exit;
}

$amount = number_format(
    (float) $rawAmount,
    2,
    '.',
    ''
);

if ((float) $amount < 10) {
    header('Location: /portal/transfers?error=minimum-amount');
    exit;
}

if ((float) $amount > 1000000) {
    header('Location: /portal/transfers?error=maximum-amount');
    exit;
}

if (strlen($note) > 500) {
    $note = substr($note, 0, 500);
}

$currency = 'USD';
$fee = 0.00;

try {

    $pdo->beginTransaction();

    /*
     * Lock the sender's main USD wallet.
     */
    $senderAccountQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            wallet_type,
            available_balance,
            currency
         FROM accounts
         WHERE user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
         FOR UPDATE"
    );

    $senderAccountQuery->execute([
        'user_id' => $userId
    ]);

    $senderAccount = $senderAccountQuery->fetch();

    if (!$senderAccount) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=sender-wallet-not-found'
        );

        exit;
    }

    /*
     * Find the recipient.
     */
    $recipientQuery = $pdo->prepare(
        "SELECT
            id,
            email,
            first_name,
            last_name,
            status
         FROM users
         WHERE email = :email
         LIMIT 1"
    );

    $recipientQuery->execute([
        'email' => $email
    ]);

    $recipient = $recipientQuery->fetch();

    if (!$recipient) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=recipient-not-found'
        );

        exit;
    }

    $recipientUserId = (int) $recipient['id'];

    /*
     * Do not allow a user to send money to themselves.
     */
    if ($recipientUserId === $userId) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=self-transfer'
        );

        exit;
    }

    /*
     * Recipient must have an active account.
     */
    if ((string) $recipient['status'] !== 'active') {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=recipient-inactive'
        );

        exit;
    }

    /*
     * Lock the recipient's main USD wallet.
     */
    $recipientAccountQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            wallet_type,
            available_balance,
            currency
         FROM accounts
         WHERE user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
         FOR UPDATE"
    );

    $recipientAccountQuery->execute([
        'user_id' => $recipientUserId
    ]);

    $recipientAccount = $recipientAccountQuery->fetch();

    if (!$recipientAccount) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=recipient-wallet-not-found'
        );

        exit;
    }

    $transferAmount = (float) $amount;
    $totalDebit = round($transferAmount + $fee, 2);

    $senderBalance = (float) $senderAccount['available_balance'];

    if ($senderBalance < $totalDebit) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=insufficient-balance'
        );

        exit;
    }

    /*
     * Debit sender.
     */
    $debitQuery = $pdo->prepare(
        "UPDATE accounts
         SET available_balance =
             available_balance - :amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
           AND available_balance >= :required_balance"
    );

    $debitQuery->execute([
        'amount' => number_format(
            $totalDebit,
            2,
            '.',
            ''
        ),
        'account_id' => (int) $senderAccount['id'],
        'user_id' => $userId,
        'required_balance' => number_format(
            $totalDebit,
            2,
            '.',
            ''
        )
    ]);

    if ($debitQuery->rowCount() !== 1) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=balance-changed'
        );

        exit;
    }

    /*
     * Credit recipient.
     */
    $creditQuery = $pdo->prepare(
        "UPDATE accounts
         SET available_balance =
             available_balance + :amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'"
    );

    $creditQuery->execute([
        'amount' => number_format(
            $transferAmount,
            2,
            '.',
            ''
        ),
        'account_id' => (int) $recipientAccount['id'],
        'user_id' => $recipientUserId
    ]);

    if ($creditQuery->rowCount() !== 1) {

        $pdo->rollBack();

        header(
            'Location: /portal/transfers?error=credit-failed'
        );

        exit;
    }

    /*
     * Generate transfer reference.
     */
    $reference = 'TRF-' . strtoupper(
        bin2hex(random_bytes(8))
    );

    /*
     * Save transfer record.
     */
    $transferQuery = $pdo->prepare(
        "INSERT INTO transfers (
            sender_user_id,
            recipient_user_id,
            sender_account_id,
            recipient_account_id,
            amount,
            fee,
            currency,
            status,
            reference,
            note
        ) VALUES (
            :sender_user_id,
            :recipient_user_id,
            :sender_account_id,
            :recipient_account_id,
            :amount,
            :fee,
            'USD',
            'completed',
            :reference,
            :note
        )"
    );

    $transferQuery->execute([
        'sender_user_id' => $userId,
        'recipient_user_id' => $recipientUserId,
        'sender_account_id' => (int) $senderAccount['id'],
        'recipient_account_id' => (int) $recipientAccount['id'],
        'amount' => number_format(
            $transferAmount,
            2,
            '.',
            ''
        ),
        'fee' => number_format(
            $fee,
            2,
            '.',
            ''
        ),
        'reference' => $reference,
        'note' => $note !== '' ? $note : null
    ]);

    /*
     * Sender ledger entry.
     */
    $senderLedger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'transfer',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $senderLedger->execute([
        'user_id' => $userId,
        'account_id' => (int) $senderAccount['id'],
        'amount' => '-' . number_format(
            $totalDebit,
            2,
            '.',
            ''
        ),
        'description' =>
            'Money transfer to ' .
            (string) $recipient['email'] .
            ' ' .
            $reference
    ]);

    /*
     * Recipient ledger entry.
     */
    $recipientLedger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'transfer',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $recipientLedger->execute([
        'user_id' => $recipientUserId,
        'account_id' => (int) $recipientAccount['id'],
        'amount' => number_format(
            $transferAmount,
            2,
            '.',
            ''
        ),
        'description' =>
            'Money transfer from sender ' .
            $reference
    ]);

    /*
     * Commit everything together.
     */
    $pdo->commit();

    header(
        'Location: /portal/transfers?success=1' .
        '&reference=' .
        urlencode($reference)
    );

    exit;

} catch (Throwable $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    header(
        'Location: /portal/transfers?error=transfer-failed'
    );

    exit;
}