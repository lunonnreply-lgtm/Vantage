<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_page_auth();

$dashboardAccountQuery = $pdo->prepare('SELECT currency, available_balance FROM accounts WHERE user_id = :user_id AND wallet_type = :wallet_type ORDER BY id LIMIT 1');
$dashboardAccountQuery->execute(['user_id' => $userId, 'wallet_type' => 'main']);
$dashboardAccount = $dashboardAccountQuery->fetch() ?: ['currency' => 'USD', 'available_balance' => '0.00'];
$dashboardBalance = number_format((float) $dashboardAccount['available_balance'], 2);
$dashboardCurrency = htmlspecialchars((string) $dashboardAccount['currency'], ENT_QUOTES, 'UTF-8');

$dashboardTicketQuery = $pdo->prepare('SELECT COUNT(*) FROM support_tickets WHERE user_id = :user_id');
$dashboardTicketQuery->execute(['user_id' => $userId]);
$dashboardTicketCount = (int) $dashboardTicketQuery->fetchColumn();

$dashboardDepositQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM financial_requests WHERE user_id = :user_id AND type = 'deposit' AND status = 'approved'");
$dashboardDepositQuery->execute(['user_id' => $userId]);
$dashboardTotalDeposit = (float) $dashboardDepositQuery->fetchColumn();

$dashboardWithdrawQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM financial_requests WHERE user_id = :user_id AND type = 'withdrawal' AND status = 'approved'");
$dashboardWithdrawQuery->execute(['user_id' => $userId]);
$dashboardTotalWithdraw = (float) $dashboardWithdrawQuery->fetchColumn();

$dashboardInvestmentQuery = $pdo->prepare("SELECT COALESCE(SUM(principal), 0) FROM investments WHERE user_id = :user_id AND status IN ('active', 'released')");
$dashboardInvestmentQuery->execute(['user_id' => $userId]);
$dashboardTotalInvestment = (float) $dashboardInvestmentQuery->fetchColumn();

$dashboardTransferQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM transfers WHERE sender_user_id = :user_id AND status = 'completed'");
$dashboardTransferQuery->execute(['user_id' => $userId]);
$dashboardTotalTransfer = (float) $dashboardTransferQuery->fetchColumn();

$dashboardProfitQuery = $pdo->prepare("SELECT COALESCE(SUM(GREATEST(available_balance - restricted_balance, 0)), 0) FROM accounts WHERE user_id = :user_id AND wallet_type = 'profit'");
$dashboardProfitQuery->execute(['user_id' => $userId]);
$dashboardTotalProfit = (float) $dashboardProfitQuery->fetchColumn();

$dashboardReferralBonusQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM bonuses WHERE user_id = :user_id AND type = 'referral' AND status = 'credited'");
$dashboardReferralBonusQuery->execute(['user_id' => $userId]);
$dashboardReferralBonus = (float) $dashboardReferralBonusQuery->fetchColumn();

$dashboardDepositBonusQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM bonuses WHERE user_id = :user_id AND type = 'deposit' AND status = 'credited'");
$dashboardDepositBonusQuery->execute(['user_id' => $userId]);
$dashboardDepositBonus = (float) $dashboardDepositBonusQuery->fetchColumn();

$dashboardInvestmentBonusQuery = $pdo->prepare("SELECT COALESCE(SUM(amount), 0) FROM bonuses WHERE user_id = :user_id AND type = 'investment' AND status = 'credited'");
$dashboardInvestmentBonusQuery->execute(['user_id' => $userId]);
$dashboardInvestmentBonus = (float) $dashboardInvestmentBonusQuery->fetchColumn();

$dashboardReferralCountQuery = $pdo->prepare('SELECT COUNT(*) FROM referrals WHERE referrer_user_id = :user_id');
$dashboardReferralCountQuery->execute(['user_id' => $userId]);
$dashboardReferralCount = (int) $dashboardReferralCountQuery->fetchColumn();

$rankTiers = [
    ['name' => 'Starter', 'key' => 'starter'],
    ['name' => 'Bronze', 'key' => 'bronze'],
    ['name' => 'Silver', 'key' => 'silver'],
    ['name' => 'Gold', 'key' => 'gold'],
    ['name' => 'Platinum', 'key' => 'platinum'],
    ['name' => 'Diamond', 'key' => 'diamond'],
    ['name' => 'Elite', 'key' => 'elite'],
    ['name' => 'Master', 'key' => 'master'],
    ['name' => 'Legend', 'key' => 'legend'],
];
$rankStep = max(0, (int) floor($dashboardTotalInvestment / 10000));
$rankTierIndex = min($rankStep, count($rankTiers) - 1);
$dashboardRank = [
    'name' => $rankTiers[$rankTierIndex]['name'],
    'key' => $rankTiers[$rankTierIndex]['key'],
    'level' => $rankStep + 1,
];

if ($rankStep >= count($rankTiers)) {
    $dashboardRank['name'] .= ' ' . ($rankStep - count($rankTiers) + 2);
}

$dashboardReferralCodeQuery = $pdo->prepare('SELECT referral_code FROM users WHERE id = :user_id LIMIT 1');
$dashboardReferralCodeQuery->execute(['user_id' => $userId]);
$dashboardReferralCode = (string) ($dashboardReferralCodeQuery->fetchColumn() ?: '');
$dashboardReferralUrl = 'https://vantageinstitutional.pro/auth/register/?ref=' . urlencode($dashboardReferralCode);

$dashboardAllTransactionsQuery = $pdo->prepare(
    "SELECT
        (SELECT COUNT(*) FROM financial_requests WHERE user_id = :user_id_1)
        + (SELECT COUNT(*) FROM transfers WHERE sender_user_id = :user_id_2)
        + (SELECT COUNT(*) FROM investments WHERE user_id = :user_id_3)
        AS total"
);
$dashboardAllTransactionsQuery->execute([
    'user_id_1' => $userId,
    'user_id_2' => $userId,
    'user_id_3' => $userId,
]);
$dashboardAllTransactionsCount = (int) $dashboardAllTransactionsQuery->fetchColumn();

$dashboardRecentQuery = $pdo->prepare(
    "SELECT reference, type, amount, fee, currency, status, gateway, created_at
     FROM financial_requests
     WHERE user_id = :user_id
     ORDER BY created_at DESC
     LIMIT 10"
);
$dashboardRecentQuery->execute(['user_id' => $userId]);
$dashboardRecent = $dashboardRecentQuery->fetchAll();

$pageTitle = 'Dashboard';
$activeMenu = 'dashboard';
$canonicalPath = '/portal/dashboard';

$extraScripts = <<<'HTML'
<script>
    function copyRef() {
        /* Get the text field */
        var textToCopy = $('#refLink').val();
        // Create a temporary input element
        var tempInput = $('<input>');
        $('body').append(tempInput);
        tempInput.val(textToCopy).select();
        // Copy the text from the temporary input
        document.execCommand('copy');
        // Remove the temporary input element
        tempInput.remove();
        $('#copy').text('Copied'); var copyApi = document.getElementById("refLink");
        /* Select the text field */
        copyApi.select();
        copyApi.setSelectionRange(0, 999999999); /* For mobile devices */
        /* Copy the text inside the text field */
        document.execCommand('copy');
        $('#copy').text('Copied')

    }
</script>
HTML;

require __DIR__ . '/../_header.php';
?>

<div class="row">
    <div class="col-xl-3 col-lg-3 col-md-4 col-sm-6 col-12">
        <div class="user-ranking rank-tier-<?= htmlspecialchars($dashboardRank['key'], ENT_QUOTES, 'UTF-8') ?>">
            <h4><?= htmlspecialchars('Level ' . $dashboardRank['level'], ENT_QUOTES, 'UTF-8') ?></h4>
            <p><?= htmlspecialchars($dashboardRank['name'], ENT_QUOTES, 'UTF-8') ?></p>
            <div class="rank" role="img" aria-label="<?= htmlspecialchars($dashboardRank['name'] . ' medal', ENT_QUOTES, 'UTF-8') ?>" title="Rank advances with each USD 10,000 invested">
                <i data-lucide="medal" class="rank-medal-icon" aria-hidden="true"></i>
            </div>
        </div>

        <div class="dashboard-ranking-mobile rank-tier-<?= htmlspecialchars($dashboardRank['key'], ENT_QUOTES, 'UTF-8') ?>">
            <div class="dashboard-ranking-mobile__medal" role="img" aria-label="<?= htmlspecialchars($dashboardRank['name'] . ' medal', ENT_QUOTES, 'UTF-8') ?>">
                <i data-lucide="medal" class="rank-medal-icon" aria-hidden="true"></i>
            </div>
            <div class="dashboard-ranking-mobile__name">
                <strong><?= htmlspecialchars('Level ' . $dashboardRank['level'], ENT_QUOTES, 'UTF-8') ?></strong>
                <span><?= htmlspecialchars($dashboardRank['name'], ENT_QUOTES, 'UTF-8') ?></span>
            </div>
            <div class="dashboard-ranking-mobile__invested">
                <?= htmlspecialchars($dashboardCurrency, ENT_QUOTES, 'UTF-8') ?> <?= number_format($dashboardTotalInvestment, 2) ?> invested
            </div>
        </div>
    </div>
    <div class="col-xl-9 col-lg-9 col-md-8 col-sm-12 col-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">Referral URL</h3>
            </div>
            <div class="site-card-body">
                <div class="referral-link">
                    <div class="referral-link-form">
                        <input type="text" value="<?= htmlspecialchars($dashboardReferralUrl, ENT_QUOTES, 'UTF-8') ?>" id="refLink"readonly/>
                        <button type="submit" onclick="copyRef()">
                            <i class="anticon anticon-copy"></i>
                            <span id="copy">Copy</span>
                        </button>
                    </div>
                    <p class="referral-joined">
                        Referral activity will appear after users join with your referral link
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<div class="row user-cards ">
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-inbox"></i></div>
            <div class="content">
                <h4><span class="count"><?= $dashboardAllTransactionsCount ?></span></h4>
                <p>All Transactions</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-file-add"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardTotalDeposit, 2) ?></span></h4>
                <p>Total Deposit</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-check-square"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardTotalInvestment, 2) ?></span></h4>
                <p>Total Investment</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-credit-card"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardTotalProfit, 2) ?></span></h4>
                <p>Available Profit</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-arrow-right"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardTotalTransfer, 2) ?></span></h4>
                <p>Total Transfer </p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-money-collect"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardTotalWithdraw, 2) ?></span></h4>
                <p>Total Withdraw</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-gift"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardReferralBonus, 2) ?></span>
                </h4>
                <p>Referral Bonus</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-account-book"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardDepositBonus, 2) ?></span></h4>
                <p>Deposit Bonus</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-gold"></i></div>
            <div class="content">
                <h4><b><?= $dashboardCurrency ?></b><span class="count"><?= number_format($dashboardInvestmentBonus, 2) ?></span></h4>
                <p>Investment Bonus</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-inbox"></i></div>
            <div class="content">
                <h4 class="count"><?= $dashboardReferralCount ?></h4>
                <p>Total Referral</p>
            </div>
        </div>
    </div>

    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-radar-chart"></i></div>
            <div class="content">
                <h4 class="count"><?= $dashboardRank['level'] ?></h4>
                <p>Current Level</p>
            </div>
        </div>
    </div>
    <div class="col-xl-3 col-lg-6 col-md-6 col-sm-6 col-12">
        <div class="single">
            <div class="icon"><i class="anticon anticon-question"></i></div>
            <div class="content">
                <h4 class="count"><?= $dashboardTicketCount ?></h4>
                <p>Total Ticket</p>
            </div>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-xl-12">
        <div class="site-card">
            <div class="site-card-header">
                <h3 class="title">Recent Transactions</h3>
            </div>
            <div class="site-card-body table-responsive">
                <div class="site-datatable">
                    <table class="display data-table">
                        <thead>
                        <tr>
                            <th>Description</th>
                            <th>Transactions ID</th>
                            <th>Type</th>
                            <th>Amount</th>
                            <th>Fee</th>
                            <th>Status</th>
                            <th>Gateway</th>
                        </tr>
                        </thead>
                        <tbody>
                        <?php if ($dashboardRecent): ?>
                            <?php foreach ($dashboardRecent as $tx): ?>
                                <tr>
                                    <td>
                                        <?= $tx['type'] === 'deposit' ? 'Deposit request' : 'Withdrawal request' ?>
                                    </td>
                                    <td>
                                        <strong><?= htmlspecialchars((string) $tx['reference'], ENT_QUOTES, 'UTF-8') ?></strong>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars(ucfirst((string) $tx['type']), ENT_QUOTES, 'UTF-8') ?>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars((string) $tx['currency'], ENT_QUOTES, 'UTF-8') ?>
                                        <?= number_format((float) $tx['amount'], 2) ?>
                                    </td>
                                    <td>
                                        <?= htmlspecialchars((string) $tx['currency'], ENT_QUOTES, 'UTF-8') ?>
                                        <?= number_format((float) $tx['fee'], 2) ?>
                                    </td>
                                    <td>
                                        <div class="site-badge">
                                            <?= htmlspecialchars(ucfirst((string) $tx['status']), ENT_QUOTES, 'UTF-8') ?>
                                        </div>
                                    </td>
                                    <td>
                                        <?= $tx['gateway'] !== null
                                            ? htmlspecialchars((string) $tx['gateway'], ENT_QUOTES, 'UTF-8')
                                            : '—' ?>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr class="centered">
                                <td colspan="7">No Data Found</td>
                            </tr>
                        <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>
</div>

<?php require __DIR__ . '/../_footer.php'; ?>