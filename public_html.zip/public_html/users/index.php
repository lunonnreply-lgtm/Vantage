<?php
require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();
$userId = (int)($_SESSION['user_id'] ?? 0);
$adminQuery = $pdo->prepare('SELECT first_name,last_name,email FROM users WHERE id=:id LIMIT 1');
$adminQuery->execute(['id'=>$userId]);
$admin = $adminQuery->fetch() ?: [];
$adminName = trim((string)($admin['first_name'] ?? '').' '.(string)($admin['last_name'] ?? '')) ?: 'Administrator';

$pageTitle='Users'; $pageEyebrow='Account Management'; $adminFooterScripts=[];
require __DIR__.'/../../includes/header.php';
?>
<section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Accounts</span><h2>All Users</h2><p>Review accounts and change account status. User deletion is intentionally not exposed here.</p></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Name</th><th>Email</th><th>Role</th><th>Status</th><th>Joined</th><th>Action</th></tr></thead><tbody id="rows"><tr><td colspan="7">Loading…</td></tr></tbody></table></div></section>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function load(){const r=await fetch('/api/admin/users.php',{credentials:'same-origin'});const d=await r.json();if(!r.ok)throw Error(d.error||'Failed');document.querySelector('#rows').innerHTML=(d.items||[]).map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(x.name)}</td><td>${esc(x.email)}</td><td>${esc(x.role)}</td><td>${esc(x.status)}</td><td>${esc(x.created_at)}</td><td><select onchange="act(${x.id},this.value)"><option value="">Change status</option><option value="active">Active</option><option value="suspended">Suspended</option><option value="inactive">Inactive</option></select></td></tr>`).join('')||'<tr><td colspan="7">No users found.</td></tr>';}
async function act(id,status){if(!status||!confirm('Change account status?'))return;const r=await fetch('/api/admin/users.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify({id,status})});const d=await r.json();if(!r.ok)alert(d.error||'Update failed');else load();} async function csrf(){const r=await fetch('/api/auth/csrf',{credentials:'same-origin'});const d=await r.json();return d.token||d.csrfToken||'';} load().catch(e=>document.querySelector('#rows').innerHTML='<tr><td colspan="7">'+esc(e.message)+'</td></tr>');
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
