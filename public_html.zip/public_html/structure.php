<?php

declare(strict_types=1);

function printTree(string $directory, string $prefix = ''): void
{
    $items = scandir($directory);

    if ($items === false) {
        return;
    }

    $items = array_values(array_filter(
        $items,
        static function (string $item): bool {
            return $item !== '.' && $item !== '..';
        }
    ));

    $count = count($items);

    foreach ($items as $index => $item) {
        $path = $directory . DIRECTORY_SEPARATOR . $item;
        $isLast = $index === $count - 1;
        $branch = $isLast ? '└── ' : '├── ';

        echo htmlspecialchars($prefix . $branch . $item, ENT_QUOTES, 'UTF-8') . "\n";

        if (is_dir($path)) {
            printTree(
                $path,
                $prefix . ($isLast ? '    ' : '│   ')
            );
        }
    }
}

$root = __DIR__;

header('Content-Type: text/plain; charset=utf-8');

echo "Vantage Institutional - DIRECTORY STRUCTURE\n";
echo "================================================\n\n";
echo basename($root) . "/\n";

printTree($root);