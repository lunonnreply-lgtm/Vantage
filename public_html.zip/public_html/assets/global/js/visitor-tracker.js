(function () {
    'use strict';

    var storageKey = 'Vantage Institutional_visitor_id';
    var visitorIdPattern = /^[a-f0-9]{64}$/;

    function makeVisitorId() {
        var bytes = new Uint8Array(32);
        if (window.crypto && window.crypto.getRandomValues) {
            window.crypto.getRandomValues(bytes);
        } else {
            for (var index = 0; index < bytes.length; index++) {
                bytes[index] = Math.floor(Math.random() * 256);
            }
        }

        return Array.prototype.map.call(bytes, function (byte) {
            return byte.toString(16).padStart(2, '0');
        }).join('');
    }

    function getVisitorId() {
        try {
            var id = window.localStorage.getItem(storageKey);
            if (!visitorIdPattern.test(id || '')) {
                id = makeVisitorId();
                window.localStorage.setItem(storageKey, id);
            }
            return id;
        } catch (storageError) {
            try {
                var sessionId = window.sessionStorage.getItem(storageKey);
                if (!visitorIdPattern.test(sessionId || '')) {
                    sessionId = makeVisitorId();
                    window.sessionStorage.setItem(storageKey, sessionId);
                }
                return sessionId;
            } catch (sessionError) {
                return '';
            }
        }
    }

    var visitorId = getVisitorId();
    if (!visitorId) {
        return;
    }

    fetch('/api/visitor/track.php', {
        method: 'POST',
        credentials: 'same-origin',
        headers: {
            'Content-Type': 'application/json',
            'Accept': 'application/json'
        },
        body: JSON.stringify({
            visitor_id: visitorId,
            page: window.location.pathname,
            referrer: document.referrer || ''
        }),
        keepalive: true
    }).catch(function () {
        // Tracking should never interfere with page navigation.
    });
})();
