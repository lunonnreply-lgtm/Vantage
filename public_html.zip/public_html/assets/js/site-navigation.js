
(function () {
	"use strict";

	document.addEventListener("click", function (event) {
		const closeButton = event.target.closest("#elementor-popup-modal-611 .dialog-close-button");
		if (!closeButton) return;

		const popup = closeButton.closest("#elementor-popup-modal-611");
		if (!popup) return;

		event.preventDefault();
		event.stopImmediatePropagation();
		popup.dataset.staticClosed = "true";
		popup.setAttribute("aria-hidden", "true");
		popup.style.setProperty("display", "none", "important");
		document.body.classList.remove(
			"dialog-body",
			"dialog-lightbox-body",
			"dialog-container",
			"dialog-lightbox-container"
		);
		document.body.style.removeProperty("overflow");
		document.documentElement.style.removeProperty("overflow");
	}, true);

	document.addEventListener("click", function (event) {
		const openButton = event.target.closest('.elementor-element-3ffc983 a[href*="popup:open"]');
		if (!openButton) return;

		const popup = document.querySelector("#elementor-popup-modal-611[data-static-closed='true']");
		if (!popup) return;

		delete popup.dataset.staticClosed;
		popup.removeAttribute("aria-hidden");
		popup.style.removeProperty("display");
	}, true);
})();
