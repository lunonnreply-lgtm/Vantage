/* Mobile drawer toggle — paired with mobile-navigation.css. */
(() => {
  "use strict";

  const mobile = window.matchMedia("(max-width: 991px)");
  const toggle = document.querySelector(".panel-layout .panel-header .sidebar-toggle");
  const overlay = document.querySelector(".panel-layout .mobile-screen-show");
  const drawer = overlay && overlay.querySelector(".mobile-side-nav");

  if (!toggle || !overlay || !drawer) return;

  if (!drawer.id) drawer.id = "mobile-navigation";
  toggle.setAttribute("aria-controls", drawer.id);
  toggle.setAttribute("aria-expanded", "false");
  toggle.setAttribute("aria-label", "Open navigation menu");
  overlay.setAttribute("role", "dialog");
  overlay.setAttribute("aria-modal", "true");
  overlay.setAttribute("aria-label", "Mobile navigation");
  overlay.setAttribute("aria-hidden", "true");

  const isOpen = () => overlay.classList.contains("is-open");

  function openMenu() {
    if (!mobile.matches) return;
    overlay.classList.add("is-open");
    document.body.classList.add("mobile-nav-open");
    overlay.setAttribute("aria-hidden", "false");
    toggle.setAttribute("aria-expanded", "true");
    toggle.setAttribute("aria-label", "Close navigation menu");
    const firstLink = drawer.querySelector("a[href]");
    window.requestAnimationFrame(() => firstLink && firstLink.focus());
  }

  function closeMenu(returnFocus) {
    overlay.classList.remove("is-open");
    document.body.classList.remove("mobile-nav-open");
    overlay.setAttribute("aria-hidden", "true");
    toggle.setAttribute("aria-expanded", "false");
    toggle.setAttribute("aria-label", "Open navigation menu");
    if (returnFocus && mobile.matches) toggle.focus();
  }

  /* Capture this click so desktop sidebar handlers do not also run on phones. */
  toggle.addEventListener("click", (event) => {
    if (!mobile.matches) return;
    event.preventDefault();
    event.stopImmediatePropagation();
    if (isOpen()) closeMenu(true);
    else openMenu();
  }, true);

  overlay.addEventListener("click", (event) => {
    if (event.target === overlay) {
      closeMenu(true);
      return;
    }
    if (event.target.closest(".mobile-side-nav a[href]")) {
      window.setTimeout(() => closeMenu(false), 120);
    }
  });

  overlay.addEventListener("submit", () => closeMenu(false), true);

  document.addEventListener("keydown", (event) => {
    if (!mobile.matches || !isOpen()) return;

    if (event.key === "Escape") {
      event.preventDefault();
      closeMenu(true);
      return;
    }

    if (event.key !== "Tab") return;
    const items = Array.from(drawer.querySelectorAll(
      'a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])'
    )).filter((item) => item.getClientRects().length > 0);

    if (!items.length) {
      event.preventDefault();
      return;
    }

    const first = items[0];
    const last = items[items.length - 1];
    if (event.shiftKey && document.activeElement === first) {
      event.preventDefault();
      last.focus();
    } else if (!event.shiftKey && document.activeElement === last) {
      event.preventDefault();
      first.focus();
    }
  });

  mobile.addEventListener("change", (event) => {
    if (!event.matches) closeMenu(false);
  });
})();
