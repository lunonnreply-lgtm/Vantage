# Vantage Institutional Branding Assets

The Vantage Institutional wordmark and device icons were created as a typographic mark from the approved brand name. The primary wordmark remains 282 x 97 pixels at `assets/logo.png`; scalable source and icon variants are in `assets/branding/`.

## Replacement files required

| Existing file | Dimensions or format | Required replacement |
| --- | --- | --- |
| `assets/branding/favicon-16.png`, `favicon-32.png`, `favicon.ico`, `favicon.svg` | 16 x 16, 32 x 32, ICO, SVG | Browser favicon variants |
| `assets/branding/apple-touch-icon.png` | 180 x 180 PNG | Apple touch icon |
| `assets/branding/pwa-192.png`, `pwa-512.png`, `pwa-maskable-512.png` | 192 x 192, 512 x 512 PNG | PWA any-purpose and maskable icons |
| `assets/branding/mstile-270.png` | 270 x 270 PNG | Windows tile image |
| `wp-content/uploads/2023/09/valcrest-removebg-preview.png` | 282 x 97 PNG | Updated Vantage wordmark; legacy filename retained for URL compatibility |
| `wp-content/uploads/2023/09/cropped-valcrest_LOG_FAV-removebg-preview-32x32.png` | 32 x 32 PNG | Updated Vantage favicon; legacy filename retained for URL compatibility |
| `wp-content/uploads/2023/09/cropped-valcrest_LOG_FAV-removebg-preview-180x180.png` | 180 x 180 PNG | Updated Vantage Apple touch icon; legacy filename retained for URL compatibility |
| `wp-content/uploads/2023/09/cropped-valcrest_LOG_FAV-removebg-preview-192x192.png` | 192 x 192 PNG | Updated Vantage application icon; legacy filename retained for URL compatibility |
| `wp-content/uploads/2023/09/cropped-valcrest_LOG_FAV-removebg-preview-270x270.png` | 270 x 270 PNG | Updated Vantage Windows tile; legacy filename retained for URL compatibility |
| `wp-content/uploads/2023/11/valcrest_Card-removebg-preview.png` | 589 x 373 PNG | Card image with the old monogram replaced by the Vantage VI mark |
| `wp-content/uploads/2023/11/valcrest.pdf` | 12-page PDF | Legacy company document; replace with an approved Vantage PDF after review |

The legacy-named PNG paths now serve Vantage artwork and are no longer linked by active source; filenames remain for compatibility. The PDF remains unchanged and may still expose old branding. Check external references before removing or restricting legacy-named paths. The PDF has 12 pages and `Heritage` as its metadata title; PDF rendering and text-extraction tools were unavailable during the audit, so review its rendered content before retaining or replacing it.

## External configuration

The configured sender is `Vantage Institutional <no-reply@vantageinstitutional.pro>`. The mailbox and SMTP account must be provisioned and verified by the mail provider; confirm SPF, DKIM, and DMARC for `vantageinstitutional.pro` before production mail delivery. No credentials are included or changed by this asset handoff.