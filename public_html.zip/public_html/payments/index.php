<?php
require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();
$userId = (int)($_SESSION['user_id'] ?? 0);
$adminQuery = $pdo->prepare('SELECT first_name,last_name,email FROM users WHERE id=:id LIMIT 1');
$adminQuery->execute(['id'=>$userId]);
$admin = $adminQuery->fetch() ?: [];
$adminName = trim((string)($admin['first_name'] ?? '').' '.(string)($admin['last_name'] ?? '')) ?: 'Administrator';

$pageTitle='Payment Methods'; $pageEyebrow='Payment Configuration'; $adminFooterScripts=[];
require __DIR__.'/../../includes/header.php';
?>
<div class="management-grid"><section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Configuration</span><h2>Add / edit payment method</h2><p>Gateway details and the QR code shown when this method is selected.</p></div></div><form id="form" class="management-form"><input type="hidden" id="id"><div class="field"><label>Name</label><input id="name" required maxlength="120"></div><div class="field"><label>Gateway / provider</label><input id="gateway" maxlength="120"></div><div class="field"><label>Type</label><select id="type"><option value="bank">Bank</option><option value="crypto">Crypto</option><option value="wallet">Wallet</option><option value="gateway">Gateway</option><option value="other">Other</option></select></div><div class="field"><label>Account / address</label><input id="account" maxlength="255"></div><div class="field full"><label>Instructions</label><textarea id="instructions"></textarea></div><div class="field full"><label>QR code image URL</label><input id="qr_code_url" maxlength="500" placeholder="/assets/... or https://..."></div><div class="field"><label>Active</label><select id="active"><option value="1">Yes</option><option value="0">No</option></select></div><div class="management-actions full"><button class="admin-button" type="submit">Save method</button><button class="admin-button secondary" type="button" onclick="resetForm()">Clear</button></div></form></section>
<section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Available methods</span><h2>Payment methods</h2></div></div><div class="table-scroll"><table class="data-table"><thead><tr><th>Name</th><th>Gateway</th><th>Type</th><th>QR</th><th>Active</th><th>Action</th></tr></thead><tbody id="rows"></tbody></table></div></section></div>
<script>
const $=id=>document.getElementById(id),esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function csrf(){const r=await fetch('/api/auth/csrf',{credentials:'same-origin'});const d=await r.json();return d.token||d.csrfToken||''}
async function load(){const r=await fetch('/api/admin/payment-methods.php',{credentials:'same-origin'});const d=await r.json();if(!r.ok)throw Error(d.error||'Failed');$('rows').innerHTML=(d.items||[]).map(x=>`<tr><td>${esc(x.name)}</td><td>${esc(x.gateway)}</td><td>${esc(x.type)}</td><td>${x.qr_code_url?'Yes':'No'}</td><td>${x.active?'Yes':'No'}</td><td><button class="admin-button secondary" onclick='edit(${JSON.stringify(x)})'>Edit</button> <button class="admin-button danger-button" onclick="del(${x.id})">Delete</button></td></tr>`).join('')||'<tr><td colspan="6">No payment methods.</td></tr>'}
function edit(x){['id','name','gateway','type','account','instructions','qr_code_url','active'].forEach(k=>$(k).value=x[k]??'');scrollTo(0,0)}
function resetForm(){ $('form').reset();$('id').value='';$('active').value='1'}
$('form').onsubmit=async e=>{e.preventDefault();const body={id:$('id').value||null,name:$('name').value,gateway:$('gateway').value,type:$('type').value,account:$('account').value,instructions:$('instructions').value,qr_code_url:$('qr_code_url').value,active:$('active').value};const r=await fetch('/api/admin/payment-methods.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify(body)});const d=await r.json();if(!r.ok)return alert(d.error||'Save failed');resetForm();load()}
async function del(id){if(!confirm('Delete this payment method?'))return;const r=await fetch('/api/admin/payment-methods.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify({delete:id})});const d=await r.json();if(!r.ok)alert(d.error||'Delete failed');load()} load();
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
