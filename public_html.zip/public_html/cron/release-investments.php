<?php

declare(strict_types=1);

require __DIR__ . '/../backend/src/bootstrap.php';

if (PHP_SAPI !== 'cli') {
    http_response_code(403);
    exit("CLI execution required.\n");
}

$pdo->beginTransaction();

try {
    /*
     * Pay due daily periods. The first period is due 24 hours after
     * starts_at; missed periods are caught up on the next cron run.
     */
    $query = $pdo->query(
        "SELECT
            i.id,
            i.user_id,
            i.profit_account_id,
            i.principal,
            i.expected_return,
            i.currency,
            i.reference,
            p.capital_back,
            TIMESTAMPDIFF(DAY, i.starts_at, i.matures_at) AS term_days,
            LEAST(
                TIMESTAMPDIFF(DAY, i.starts_at, CURRENT_TIMESTAMP),
                TIMESTAMPDIFF(DAY, i.starts_at, i.matures_at)
            ) AS due_periods
         FROM investments i
         INNER JOIN investment_plans p
             ON p.id = i.plan_id
         WHERE i.status = 'active'
           AND TIMESTAMPDIFF(DAY, i.starts_at, CURRENT_TIMESTAMP) >= 1
           AND (
               SELECT COALESCE(MAX(d.period_number), 0)
               FROM investment_daily_payouts d
               WHERE d.investment_id = i.id
           ) < LEAST(
               TIMESTAMPDIFF(DAY, i.starts_at, CURRENT_TIMESTAMP),
               TIMESTAMPDIFF(DAY, i.starts_at, i.matures_at)
           )
         ORDER BY i.id
         FOR UPDATE"
    );

    $investments = $query->fetchAll();

    $progressQuery = $pdo->prepare(
        "SELECT
            COALESCE(MAX(period_number), 0) AS periods_paid,
            COALESCE(SUM(profit_amount), 0) AS profit_paid
         FROM investment_daily_payouts
         WHERE investment_id = :investment_id"
    );

    $release = $pdo->prepare(
        "UPDATE accounts
                 SET available_balance = available_balance + :amount,
                         restricted_balance = restricted_balance + :restricted_delta
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = :currency
                     AND wallet_type = 'profit'
                     AND restricted_balance >= :unlock_amount"
    );

    $ledger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'investment_release',
            :amount,
            :currency,
            'completed',
            :description
        )"
    );

    $recordPayout = $pdo->prepare(
        "INSERT INTO investment_daily_payouts (
            investment_id,
            period_number,
            profit_amount,
            principal_amount
        ) VALUES (
            :investment_id,
            :period_number,
            :profit_amount,
            :principal_amount
        )"
    );

    $markReleased = $pdo->prepare(
        "UPDATE investments
         SET
            status = 'released',
            released_at = CURRENT_TIMESTAMP
         WHERE id = :id
           AND status = 'active'"
    );

    $periodsPaidCount = 0;
    $investmentsReleasedCount = 0;

    foreach ($investments as $investment) {
        $termDays = (int) $investment['term_days'];
        $duePeriods = min($termDays, max(0, (int) $investment['due_periods']));

        if ($termDays < 1) {
            throw new RuntimeException(
                'Investment ' . $investment['reference'] . ' has an invalid term.'
            );
        }

        $progressQuery->execute([
            'investment_id' => $investment['id'],
        ]);
        $progress = $progressQuery->fetch();
        $periodsPaid = (int) $progress['periods_paid'];
        $profitPaid = (float) $progress['profit_paid'];
        $expectedReturn = round((float) $investment['expected_return'], 2);

        while ($periodsPaid < $duePeriods) {
            $periodNumber = $periodsPaid + 1;
            $isFinalPeriod = $periodNumber === $termDays;

            /* Keep the sum of daily profit credits exactly equal to expected_return. */
            $dailyProfit = $isFinalPeriod
                ? round($expectedReturn - $profitPaid, 2)
                : round($expectedReturn / $termDays, 2);

            if ($dailyProfit < 0) {
                throw new RuntimeException(
                    'Daily payouts exceed the expected return for investment '
                    . $investment['reference'] . '.'
                );
            }

            $principalAmount = $isFinalPeriod
                && (int) $investment['capital_back'] === 1
                    ? round((float) $investment['principal'], 2)
                    : 0.0;

            $creditAmount = round($dailyProfit + $principalAmount, 2);
            $restrictedDelta = $isFinalPeriod ? -$profitPaid : $dailyProfit;
            $unlockAmount = $isFinalPeriod ? $profitPaid : 0.0;

            if ($creditAmount > 0 || $restrictedDelta != 0.0) {
                $amountSql = number_format($creditAmount, 2, '.', '');

                $release->execute([
                    'amount' => $amountSql,
                    'restricted_delta' => number_format($restrictedDelta, 2, '.', ''),
                    'account_id' => $investment['profit_account_id'],
                    'user_id' => $investment['user_id'],
                    'currency' => $investment['currency'],
                    'unlock_amount' => number_format($unlockAmount, 2, '.', ''),
                ]);

                if ($release->rowCount() !== 1) {
                    throw new RuntimeException(
                        'The profit wallet is unavailable for investment '
                        . $investment['reference'] . '.'
                    );
                }

                $description = $isFinalPeriod
                    ? 'Investment maturity payout ' . $investment['reference']
                    : 'Daily investment profit '
                        . $periodNumber . '/' . $termDays . ' '
                        . $investment['reference'];

                if ($creditAmount > 0) {
                    $ledger->execute([
                        'user_id' => $investment['user_id'],
                        'account_id' => $investment['profit_account_id'],
                        'amount' => $amountSql,
                        'currency' => $investment['currency'],
                        'description' => $description,
                    ]);
                }
            }

            $recordPayout->execute([
                'investment_id' => $investment['id'],
                'period_number' => $periodNumber,
                'profit_amount' => number_format($dailyProfit, 2, '.', ''),
                'principal_amount' => number_format($principalAmount, 2, '.', ''),
            ]);

            $profitPaid = round($profitPaid + $dailyProfit, 2);
            $periodsPaid++;
            $periodsPaidCount++;

            if ($isFinalPeriod) {
                $markReleased->execute([
                    'id' => $investment['id'],
                ]);

                if ($markReleased->rowCount() !== 1) {
                    throw new RuntimeException(
                        'Failed to release investment '
                        . $investment['reference'] . '.'
                    );
                }

                $investmentsReleasedCount++;
            }
        }
    }

    $pdo->commit();

    echo json_encode([
        'success' => true,
        'periods_paid' => $periodsPaidCount,
        'investments_released' => $investmentsReleasedCount,
    ]) . PHP_EOL;

    exit(0);
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    fwrite(
        STDERR,
        '[investment-cron] ' . $exception->getMessage() . PHP_EOL
    );

    exit(1);
}