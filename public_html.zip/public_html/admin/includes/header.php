<?php
declare(strict_types=1);
require_once __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();

if (empty($_SESSION['csrf_token'])) {
    $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}
$adminUserId=(int)($_SESSION['user_id']??0);
$q=$pdo->prepare('SELECT first_name,last_name,email FROM users WHERE id=:id LIMIT 1');$q->execute(['id'=>$adminUserId]);$u=$q->fetch()?:[];
$adminName=trim(($u['first_name']??'').' '.($u['last_name']??''))?:'Administrator';
?><!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><meta name="csrf-token" content="<?= htmlspecialchars((string)($_SESSION['csrf_token'] ?? ""),ENT_QUOTES,'UTF-8') ?>"><title><?=htmlspecialchars($pageTitle??'Admin | Vantage Institutional',ENT_QUOTES,'UTF-8')?>

</title>

<link rel="icon" type="image/svg+xml" href="/assets/branding/favicon.svg"><link rel="icon" type="image/png" sizes="48x48" href="/assets/branding/favicon-48.png"><link rel="icon" type="image/png" sizes="32x32" href="/assets/branding/favicon-32.png"><link rel="icon" type="image/png" sizes="16x16" href="/assets/branding/favicon-16.png"><link rel="shortcut icon" href="/assets/branding/favicon.ico"><link rel="apple-touch-icon" sizes="180x180" href="/assets/branding/apple-touch-icon.png"><link rel="manifest" href="/assets/branding/site.webmanifest"><meta name="msapplication-TileImage" content="/assets/branding/mstile-270.png"><meta name="msapplication-config" content="/browserconfig.xml"><meta name="msapplication-TileColor" content="#0B1F3A"><meta name="theme-color" content="#0B1F3A">
<link rel="stylesheet" href="/admin/admin.css?v=<?= filemtime(__DIR__ . '/../admin.css') ?>">

<link rel="stylesheet" href="/admin/admin-management.css?v=<?= filemtime(__DIR__ . '/../admin-management.css') ?>">



</head>

<body><main class="admin-shell"><header class="admin-header"><div><div class="admin-brand">Vantage Institutional</div><div class="admin-subtitle">Administration / Operations console</div></div><div class="admin-header-actions"><span class="admin-user"><?=htmlspecialchars($adminName,ENT_QUOTES,'UTF-8')?></span><a class="vc-btn vc-btn-light" href="/admin/">Dashboard</a><button class="vc-btn vc-btn-orange" type="button" data-admin-logout>Logout</button></div></header><button class="admin-nav-toggle" type="button" aria-expanded="false" aria-controls="admin-nav" data-admin-nav-toggle><span></span><span></span><span></span><b>Menu</b></button><nav class="admin-nav" id="admin-nav"><a href="/admin/deposits/">Deposits</a><a href="/admin/withdrawals/">Withdrawals</a><a href="/admin/withdrawal-settings/">Withdrawal Settings</a><a href="/admin/users/">Users</a><a href="/admin/payment-methods/">Payment Methods</a><a href="/admin/investment-plans/">Investment Plans</a><a href="/admin/support/">Support</a></nav><script src="/admin/admin-management.js?v=<?= filemtime(__DIR__ . '/../admin-management.js') ?>"></script><section class="admin-content">
