<?php
declare(strict_types=1);

function admin_query_params(array $overrides = []): string
{
    $params = $_GET;
    foreach ($overrides as $key => $value) {
        if ($value === null || $value === '') unset($params[$key]);
        else $params[$key] = $value;
    }
    return http_build_query($params);
}

function admin_sort_link(string $column, string $label, string $currentSort, string $currentDir): string
{
    $nextDir = ($currentSort === $column && $currentDir === 'asc') ? 'desc' : 'asc';
    $qs = admin_query_params(['sort' => $column, 'dir' => $nextDir, 'page' => 1]);
    $arrow = $currentSort === $column ? ($currentDir === 'asc' ? ' ↑' : ' ↓') : '';
    return '<a class="table-sort" href="?' . htmlspecialchars($qs, ENT_QUOTES, 'UTF-8') . '">' . htmlspecialchars($label, ENT_QUOTES, 'UTF-8') . $arrow . '</a>';
}

function admin_pagination(int $page, int $perPage, int $total): string
{
    if ($total <= 0) return '';
    $pages = max(1, (int)ceil($total / $perPage));
    if ($pages <= 1) return '<div class="pagination-meta">Showing ' . $total . ' record' . ($total === 1 ? '' : 's') . '</div>';
    $start = (($page - 1) * $perPage) + 1;
    $end = min($total, $page * $perPage);
    $html = '<div class="admin-pagination"><div class="pagination-meta">Showing ' . $start . '–' . $end . ' of ' . $total . '</div><div class="pagination-links">';
    if ($page > 1) {
        $html .= '<a class="vc-btn vc-btn-light" href="?' . htmlspecialchars(admin_query_params(['page' => $page - 1]), ENT_QUOTES, 'UTF-8') . '">Previous</a>';
    }
    $windowStart = max(1, $page - 2);
    $windowEnd = min($pages, $page + 2);
    if ($windowStart > 1) $html .= '<a class="page-number" href="?' . htmlspecialchars(admin_query_params(['page' => 1]), ENT_QUOTES, 'UTF-8') . '">1</a>';
    if ($windowStart > 2) $html .= '<span class="page-gap">…</span>';
    for ($i = $windowStart; $i <= $windowEnd; $i++) {
        $class = $i === $page ? 'page-number current' : 'page-number';
        $html .= '<a class="' . $class . '" href="?' . htmlspecialchars(admin_query_params(['page' => $i]), ENT_QUOTES, 'UTF-8') . '">' . $i . '</a>';
    }
    if ($windowEnd < $pages - 1) $html .= '<span class="page-gap">…</span>';
    if ($windowEnd < $pages) $html .= '<a class="page-number" href="?' . htmlspecialchars(admin_query_params(['page' => $pages]), ENT_QUOTES, 'UTF-8') . '">' . $pages . '</a>';
    if ($page < $pages) $html .= '<a class="vc-btn vc-btn-light" href="?' . htmlspecialchars(admin_query_params(['page' => $page + 1]), ENT_QUOTES, 'UTF-8') . '">Next</a>';
    $html .= '</div></div>';
    return $html;
}
