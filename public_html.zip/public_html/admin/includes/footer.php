</section>
</main>

<script>window.__ADMIN_USER_ID=<?= (int)$adminUserId ?>;</script>
<script src="/admin/column-chooser.js?v=<?= filemtime(__DIR__ . '/../column-chooser.js') ?>"></script>
<script src="/assets/global/js/visitor-tracker.js" defer></script>
</body>
</html>
