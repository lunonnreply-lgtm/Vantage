<?php

declare(strict_types=1);

/**
 * Tokenise ordinary admin search text.
 */
function admin_search_tokens(string $value): array
{
    $value = trim($value);
    if ($value === '') {
        return [];
    }

    preg_match_all('/[[:alnum:]_]+/u', $value, $matches);
    return array_values(array_unique($matches[0] ?? []));
}

/**
 * Converts ordinary admin search text into a safe MySQL BOOLEAN FULLTEXT
 * prefix query. Each token is required and supports prefix matching.
 */
function admin_fulltext_query(string $value): string
{
    $tokens = admin_search_tokens($value);
    if (!$tokens) {
        return '';
    }

    return implode(' ', array_map(
        static fn(string $token): string => '+' . $token . '*',
        $tokens
    ));
}

/**
 * FULLTEXT cannot reliably search very short tokens. We use LIKE directly
 * when any search token is shorter than MySQL's common minimum.
 */
function admin_search_prefers_like(string $value): bool
{
    foreach (admin_search_tokens($value) as $token) {
        if (mb_strlen($token, 'UTF-8') < 3) {
            return true;
        }
    }

    return false;
}

/**
 * Builds a case-insensitive fallback LIKE condition for short terms and
 * FULLTEXT stopwords. Each field receives its own bound parameter.
 */
function admin_like_search_clause(array $fields, string $value, array &$params, string $prefix): string
{
    $parts = [];
    $needle = '%' . $value . '%';

    foreach (array_values($fields) as $index => $field) {
        $name = $prefix . '_like_' . $index;
        $parts[] = $field . ' LIKE :' . $name;
        $params[$name] = $needle;
    }

    return $parts ? '(' . implode(' OR ', $parts) . ')' : '1=0';
}
