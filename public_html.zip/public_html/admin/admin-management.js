(() => {
    const csrf = () =>
        document.querySelector('meta[name="csrf-token"]')?.content ||
        window.__CSRF_TOKEN ||
        '';

    async function api(url, opt = {}) {
        const o = {
            credentials: 'same-origin',
            ...opt,
            headers: {
                ...(opt.headers || {})
            }
        };

        if (o.method && o.method !== 'GET') {
    o.headers['X-CSRF-Token'] = csrf();

    if (!(o.body instanceof FormData)) {
        o.headers['Content-Type'] =
            o.headers['Content-Type'] || 'application/json';
    }
}

        const r = await fetch(url, o);
        const d = await r.json().catch(() => ({}));

        if (!r.ok) {
            throw Error(
                d.error ||
                d.message ||
                `Request failed (${r.status})`
            );
        }

        return d;
    }

    window.adminApi = api;

    window.escapeHtml = s =>
        String(s ?? '').replace(
            /[&<>"']/g,
            c => ({
                '&': '&amp;',
                '<': '&lt;',
                '>': '&gt;',
                '"': '&quot;',
                "'": '&#039;'
            }[c])
        );

    window.flash = (m, ok = true) => {
        const e = document.querySelector('#admin-flash');
        if (!e) return;
        e.textContent = m;
        e.className = 'flash show ' + (ok ? 'ok' : 'error');
    };

    document.addEventListener('submit', async e => {
        if (e.defaultPrevented) return;

        const form = e.target.closest('form');
        if (!form) return;

        const method =
            (form.getAttribute('method') || 'GET').toUpperCase();

        if (method !== 'POST') return;

        const action =
            form.getAttribute('action') || window.location.href;

        let url;

        try {
            url = new URL(action, window.location.href);
        } catch (_) {
            return;
        }

        if (!url.pathname.startsWith('/api/admin/')) return;

        e.preventDefault();

        const token =
            form.querySelector('input[name="csrf_token"]')?.value ||
            csrf();

        if (!token) {
            window.flash?.(
                'Security token is missing. Refresh the page and try again.',
                false
            );
            return;
        }

        const formData = new FormData(form);
        const submitter = e.submitter;

        if (
            submitter &&
            submitter.name &&
            !formData.has(submitter.name)
        ) {
            formData.append(
                submitter.name,
                submitter.value || ''
            );
        }

        const buttons = form.querySelectorAll('button');

        buttons.forEach(button => {
            button.disabled = true;
        });

        try {
            const response = await fetch(url.href, {
                method: 'POST',
                credentials: 'same-origin',
                headers: {
                    'X-CSRF-Token': token,
                    'Accept': 'application/json'
                },
                body: formData
            });

            const data = await response
                .json()
                .catch(() => ({}));

            if (!response.ok) {
                throw new Error(
                    data.error ||
                    data.message ||
                    `Request failed (${response.status})`
                );
            }

            const redirect =
                form.querySelector(
                    'input[name="_admin_redirect"]'
                )?.value;

            if (redirect) {
                window.location.href = redirect;
                return;
            }

            window.location.reload();

        } catch (error) {
            buttons.forEach(button => {
                button.disabled = false;
            });

            window.flash?.(
                error.message ||
                'The request could not be completed.',
                false
            );
        }
    });

    document.addEventListener('click', e => {
        const b = e.target.closest('[data-admin-nav-toggle]');
        if (!b) return;

        const n = document.getElementById('admin-nav');
        if (!n) return;

        const open = n.classList.toggle('is-open');

        b.setAttribute(
            'aria-expanded',
            open ? 'true' : 'false'
        );
    });

    document.addEventListener('click', e => {
        const m = document.getElementById('admin-nav');

        if (!m || !m.classList.contains('is-open')) return;

        if (
            e.target.closest('#admin-nav') ||
            e.target.closest('[data-admin-nav-toggle]')
        ) {
            return;
        }

        m.classList.remove('is-open');

        document
            .querySelector('[data-admin-nav-toggle]')
            ?.setAttribute('aria-expanded', 'false');
    });

    document.addEventListener('click', async e => {
        if (!e.target.closest('[data-admin-logout]')) return;

        try {
            await api('/api/auth/logout.php', {
                method: 'POST',
                body: '{}'
            });
        } catch (_) {}

        location.href = '/auth/login/';
    });
})();
