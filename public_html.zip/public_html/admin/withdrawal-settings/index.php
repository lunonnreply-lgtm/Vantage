<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();

if (empty($_SESSION['csrf_token'])) {
	$_SESSION['csrf_token'] = bin2hex(random_bytes(32));
}

$message = '';
$messageType = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
	$submittedToken = (string)($_POST['csrf_token'] ?? '');

	if (!hash_equals((string)$_SESSION['csrf_token'], $submittedToken)) {
		$message = 'Security token expired. Refresh and try again.';
		$messageType = 'error';
	} else {
		$currency = strtoupper(trim((string)($_POST['currency'] ?? '')));
		$minimum = trim((string)($_POST['minimum_amount'] ?? ''));
		$maximum = trim((string)($_POST['maximum_amount'] ?? ''));
		$feeType = (string)($_POST['fee_type'] ?? 'fixed');
		$fee = trim((string)($_POST['fee'] ?? '0'));
		$processingTime = trim((string)($_POST['processing_time'] ?? ''));
		$status = (string)($_POST['status'] ?? 'active');

		if (!preg_match('/^[A-Z]{3}$/', $currency)) {
			$message = 'Enter a valid three-letter currency code.';
			$messageType = 'error';
		} elseif (!is_numeric($minimum) || !is_numeric($maximum) || (float)$minimum < 0 || (float)$maximum < (float)$minimum) {
			$message = 'Enter valid withdrawal limits; maximum must be at least the minimum.';
			$messageType = 'error';
		} elseif (!in_array($feeType, ['fixed', 'percentage'], true) || !is_numeric($fee) || (float)$fee < 0) {
			$message = 'Enter a valid non-negative fee and fee type.';
			$messageType = 'error';
		} elseif ($processingTime === '' || mb_strlen($processingTime) > 120) {
			$message = 'Enter a processing time (up to 120 characters).';
			$messageType = 'error';
		} elseif (!in_array($status, ['active', 'inactive'], true)) {
			$message = 'Select a valid status.';
			$messageType = 'error';
		} else {
			$save = $pdo->prepare(
				"INSERT INTO withdrawal_settings (
					method, currency, minimum_amount, maximum_amount,
					fee_type, fee, processing_time, status
				) VALUES (
					'Crypto', :currency, :minimum_amount, :maximum_amount,
					:fee_type, :fee, :processing_time, :status
				)
				ON DUPLICATE KEY UPDATE
					minimum_amount = VALUES(minimum_amount),
					maximum_amount = VALUES(maximum_amount),
					fee_type = VALUES(fee_type),
					fee = VALUES(fee),
					processing_time = VALUES(processing_time),
					status = VALUES(status),
					updated_at = CURRENT_TIMESTAMP"
			);
			$save->execute([
				'currency' => $currency,
				'minimum_amount' => number_format((float)$minimum, 2, '.', ''),
				'maximum_amount' => number_format((float)$maximum, 2, '.', ''),
				'fee_type' => $feeType,
				'fee' => number_format((float)$fee, 4, '.', ''),
				'processing_time' => $processingTime,
				'status' => $status,
			]);

			header('Location: /admin/withdrawal-settings/?currency=' . urlencode($currency) . '&saved=1');
			exit;
		}
	}
}

$selectedCurrency = strtoupper(trim((string)($_GET['currency'] ?? 'USD')));
if (!preg_match('/^[A-Z]{3}$/', $selectedCurrency)) {
	$selectedCurrency = 'USD';
}

$settingQuery = $pdo->prepare(
	"SELECT currency, minimum_amount, maximum_amount, fee_type, fee, processing_time, status
	 FROM withdrawal_settings
	 WHERE method = 'Crypto' AND currency = :currency
	 LIMIT 1"
);
$settingQuery->execute(['currency' => $selectedCurrency]);
$setting = $settingQuery->fetch() ?: [
	'currency' => $selectedCurrency,
	'minimum_amount' => '10.00',
	'maximum_amount' => '999999.99',
	'fee_type' => 'fixed',
	'fee' => '0.0000',
	'processing_time' => 'Within 24 hours',
	'status' => 'inactive',
];

$settings = $pdo->query(
	"SELECT currency, minimum_amount, maximum_amount, fee_type, fee, processing_time, status
	 FROM withdrawal_settings
	 WHERE method = 'Crypto'
	 ORDER BY currency"
)->fetchAll();

$pageTitle = 'Crypto Withdrawal Settings | Vantage Institutional';
require __DIR__ . '/../includes/header.php';
?>

<div class="admin-page-head">
	<div>
		<h1>Crypto Withdrawal Settings</h1>
		<p>Configure limits, fees and processing time for the Crypto withdrawal method.</p>
	</div>
</div>

<?php if (isset($_GET['saved'])): ?>
	<div class="flash ok">Crypto withdrawal settings saved.</div>
<?php elseif ($message !== ''): ?>
	<div class="flash <?= htmlspecialchars($messageType, ENT_QUOTES, 'UTF-8') ?>">
		<?= htmlspecialchars($message, ENT_QUOTES, 'UTF-8') ?>
	</div>
<?php endif; ?>

<section class="admin-card">
	<h2><?= isset($_GET['currency']) ? 'Edit' : 'Add' ?> Crypto currency rule</h2>
	<form class="vc-form" method="post">
		<input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)$_SESSION['csrf_token'], ENT_QUOTES, 'UTF-8') ?>">
		<div>
			<label for="withdrawal-method">Withdrawal method</label>
			<input id="withdrawal-method" value="Crypto" readonly>
		</div>
		<div>
			<label for="withdrawal-currency">Currency</label>
			<input id="withdrawal-currency" name="currency" value="<?= htmlspecialchars((string)$setting['currency'], ENT_QUOTES, 'UTF-8') ?>" maxlength="3" pattern="[A-Za-z]{3}" required>
		</div>
		<div>
			<label for="withdrawal-minimum">Minimum amount</label>
			<input id="withdrawal-minimum" name="minimum_amount" type="number" min="0" step="0.01" value="<?= htmlspecialchars((string)$setting['minimum_amount'], ENT_QUOTES, 'UTF-8') ?>" required>
		</div>
		<div>
			<label for="withdrawal-maximum">Maximum amount</label>
			<input id="withdrawal-maximum" name="maximum_amount" type="number" min="0" step="0.01" value="<?= htmlspecialchars((string)$setting['maximum_amount'], ENT_QUOTES, 'UTF-8') ?>" required>
		</div>
		<div>
			<label for="withdrawal-fee-type">Fee type</label>
			<select id="withdrawal-fee-type" name="fee_type">
				<option value="fixed" <?= $setting['fee_type'] === 'fixed' ? 'selected' : '' ?>>Fixed amount</option>
				<option value="percentage" <?= $setting['fee_type'] === 'percentage' ? 'selected' : '' ?>>Percentage</option>
			</select>
		</div>
		<div>
			<label for="withdrawal-fee">Fee</label>
			<input id="withdrawal-fee" name="fee" type="number" min="0" step="0.0001" value="<?= htmlspecialchars((string)$setting['fee'], ENT_QUOTES, 'UTF-8') ?>" required>
		</div>
		<div>
			<label for="withdrawal-processing">Processing time</label>
			<input id="withdrawal-processing" name="processing_time" maxlength="120" value="<?= htmlspecialchars((string)$setting['processing_time'], ENT_QUOTES, 'UTF-8') ?>" required>
		</div>
		<div>
			<label for="withdrawal-status">Status</label>
			<select id="withdrawal-status" name="status">
				<option value="active" <?= $setting['status'] === 'active' ? 'selected' : '' ?>>Active</option>
				<option value="inactive" <?= $setting['status'] === 'inactive' ? 'selected' : '' ?>>Inactive</option>
			</select>
		</div>
		<div class="full form-actions">
			<button class="vc-btn vc-btn-orange" type="submit">Save Crypto settings</button>
		</div>
	</form>
</section>

<section class="admin-card">
	<h2>Configured Crypto currencies</h2>
	<div class="table-wrap">
		<table class="admin-table">
			<thead><tr><th>Method</th><th>Currency</th><th>Limits</th><th>Fee</th><th>Processing</th><th>Status</th><th>Action</th></tr></thead>
			<tbody>
			<?php if (!$settings): ?>
				<tr><td colspan="7">No Crypto withdrawal currencies configured yet.</td></tr>
			<?php endif; ?>
			<?php foreach ($settings as $row): ?>
				<tr>
					<td>Crypto</td>
					<td><?= htmlspecialchars((string)$row['currency'], ENT_QUOTES, 'UTF-8') ?></td>
					<td><?= htmlspecialchars((string)$row['minimum_amount'], ENT_QUOTES, 'UTF-8') ?> – <?= htmlspecialchars((string)$row['maximum_amount'], ENT_QUOTES, 'UTF-8') ?></td>
					<td><?= htmlspecialchars((string)$row['fee'], ENT_QUOTES, 'UTF-8') ?> <?= $row['fee_type'] === 'percentage' ? '%' : htmlspecialchars((string)$row['currency'], ENT_QUOTES, 'UTF-8') ?></td>
					<td><?= htmlspecialchars((string)$row['processing_time'], ENT_QUOTES, 'UTF-8') ?></td>
					<td><span class="status-badge status-<?= htmlspecialchars((string)$row['status'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars((string)$row['status'], ENT_QUOTES, 'UTF-8') ?></span></td>
					<td><a class="vc-btn vc-btn-light" href="?currency=<?= urlencode((string)$row['currency']) ?>">Edit</a></td>
				</tr>
			<?php endforeach; ?>
			</tbody>
		</table>
	</div>
</section>

<?php require __DIR__ . '/../includes/footer.php'; ?>
