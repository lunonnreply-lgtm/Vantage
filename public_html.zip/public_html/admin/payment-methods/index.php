<?php
declare(strict_types=1);

$pageTitle = 'Payment Methods | Vantage Institutional';

require __DIR__ . '/../includes/header.php';
require __DIR__ . '/../includes/pagination.php';

$perPage = min(100, max(10, (int)($_GET['per_page'] ?? 25)));
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;

$allowedSort = [
    'name'     => 'name',
    'code'     => 'code',
    'charge'   => 'charge',
    'currency' => 'currency',
    'status'   => 'status',
    'created'  => 'created_at',
];

$sortKey = (string)($_GET['sort'] ?? 'name');
$sort = $allowedSort[$sortKey] ?? $allowedSort['name'];

$dir = strtolower((string)($_GET['dir'] ?? 'asc'));
$dir = $dir === 'desc' ? 'desc' : 'asc';

$count = (int)$pdo->query(
    'SELECT COUNT(*) FROM payment_methods'
)->fetchColumn();

$pages = max(1, (int)ceil($count / $perPage));

if ($page > $pages) {
    $page = $pages;
}

$offset = ($page - 1) * $perPage;

$q = $pdo->prepare(
    'SELECT
        id,
        code,
        name,
        wallet_address,
        qr_code,
        charge,
        charge_type,
        minimum_deposit,
        maximum_deposit,
        currency,
        status,
        created_at,
        updated_at
     FROM payment_methods
     ORDER BY ' . $sort . ' ' . $dir . ', id ASC
     LIMIT :limit OFFSET :offset'
);

$q->bindValue(':limit', $perPage, PDO::PARAM_INT);
$q->bindValue(':offset', $offset, PDO::PARAM_INT);
$q->execute();

$rows = $q->fetchAll();
?>

<div class="admin-page-head">
    <div>
        <h1>Payment Methods</h1>
        <p>
            Manage deposit methods, wallet details and QR code images.
        </p>
    </div>

    <button
        class="vc-btn vc-btn-orange"
        id="new-payment"
        type="button"
    >
        Add Payment Method
    </button>
</div>

<div id="admin-flash" class="flash"></div>

<div class="admin-card" id="payment-form-card" hidden>

    <form
        class="vc-form"
        id="payment-form"
        enctype="multipart/form-data"
    >

        <input type="hidden" name="id">

        <div>
            <label>Code</label>
            <input
                name="code"
                maxlength="60"
                required
            >
        </div>

        <div>
            <label>Name</label>
            <input
                name="name"
                maxlength="120"
                required
            >
        </div>

        <div class="full">
            <label>Wallet Address</label>
            <input
                name="wallet_address"
                maxlength="500"
            >
        </div>

        <div class="full">
            <label>QR Code Image</label>

            <input
                type="file"
                name="qr_code"
                id="qr-code"
                accept="image/jpeg,image/png,image/webp"
            >

            <small class="muted">
                Upload a JPG, PNG or WEBP image. Maximum size: 5 MB.
                Leave empty when editing to keep the existing QR code.
            </small>

            <div
                id="qr-preview-container"
                style="display:none;margin-top:12px;"
            >
                <img
                    id="qr-preview"
                    src=""
                    alt="QR Code Preview"
                    style="
                        max-width:220px;
                        max-height:220px;
                        width:auto;
                        height:auto;
                        border-radius:8px;
                        border:1px solid rgba(255,255,255,.12);
                    "
                >
            </div>
        </div>

        <div>
            <label>Charge</label>
            <input
                name="charge"
                type="number"
                step="0.0001"
                min="0"
                value="0"
            >
        </div>

        <div>
            <label>Charge Type</label>

            <select name="charge_type">
                <option value="fixed">Fixed</option>
                <option value="percentage">Percentage</option>
            </select>
        </div>

        <div>
            <label>Minimum Deposit</label>

            <input
                name="minimum_deposit"
                type="number"
                step="0.01"
                min="0"
                value="0"
            >
        </div>

        <div>
            <label>Maximum Deposit</label>

            <input
                name="maximum_deposit"
                type="number"
                step="0.01"
                min="0"
                value="999999.99"
            >
        </div>

        <div>
            <label>Currency</label>

            <input
                name="currency"
                maxlength="3"
                value="USD"
                required
            >
        </div>

        <div>
            <label>Status</label>

            <select name="status">
                <option value="active">Active</option>
                <option value="inactive">Inactive</option>
            </select>
        </div>

        <div class="full form-actions">

            <button
                class="vc-btn vc-btn-orange"
                type="submit"
            >
                Save
            </button>

            <button
                type="button"
                class="vc-btn vc-btn-light"
                id="cancel-payment"
            >
                Cancel
            </button>

        </div>

    </form>

</div>

<div class="admin-card">

    <div class="admin-toolbar">

        <strong>
            <?= $count ?>
            payment method<?= $count === 1 ? '' : 's' ?>
        </strong>

        <div class="admin-page-size">

            <label>Per page</label>

            <form method="get">

                <input
                    type="hidden"
                    name="sort"
                    value="<?= htmlspecialchars(
                        $sortKey,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                >

                <input
                    type="hidden"
                    name="dir"
                    value="<?= htmlspecialchars(
                        $dir,
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>"
                >

                <select
                    name="per_page"
                    onchange="this.form.submit()"
                >
                    <?php foreach ([10, 25, 50, 100] as $n): ?>

                        <option
                            value="<?= $n ?>"
                            <?= $perPage === $n ? 'selected' : '' ?>
                        >
                            <?= $n ?>
                        </option>

                    <?php endforeach; ?>
                </select>

            </form>

        </div>

    </div>

    <div class="table-wrap">

        <table class="admin-table">

            <thead>

                <tr>

                    <th>
                        <?= admin_sort_link(
                            'name',
                            'Method',
                            $sortKey,
                            $dir
                        ) ?>
                    </th>

                    <th>Wallet</th>

                    <th>QR</th>

                    <th>
                        <?= admin_sort_link(
                            'charge',
                            'Charge',
                            $sortKey,
                            $dir
                        ) ?>
                    </th>

                    <th>Limits</th>

                    <th>
                        <?= admin_sort_link(
                            'status',
                            'Status',
                            $sortKey,
                            $dir
                        ) ?>
                    </th>

                    <th>Actions</th>

                </tr>

            </thead>

            <tbody>

                <?php if (!$rows): ?>

                    <tr>
                        <td colspan="7">
                            No payment methods found.
                        </td>
                    </tr>

                <?php endif; ?>

                <?php foreach ($rows as $r): ?>

                    <tr>

                        <td>

                            <strong>
                                <?= htmlspecialchars(
                                    (string)$r['name'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </strong>

                            <br>

                            <span class="muted">
                                <?= htmlspecialchars(
                                    (string)$r['code'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>
                            </span>

                        </td>

                        <td>
                            <?= htmlspecialchars(
                                (string)($r['wallet_address'] ?: '—'),
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>
                        </td>

                        <td>

                            <?php if (!empty($r['qr_code'])): ?>

                                <img
                                    src="<?= htmlspecialchars(
                                        (string)$r['qr_code'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>"
                                    alt="QR Code"
                                    style="
                                        width:70px;
                                        height:70px;
                                        object-fit:contain;
                                        border-radius:6px;
                                        border:1px solid rgba(255,255,255,.12);
                                    "
                                >

                            <?php else: ?>

                                <span class="muted">No QR</span>

                            <?php endif; ?>

                        </td>

                        <td>

                            <?= htmlspecialchars(
                                (string)$r['charge'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                            <?= $r['charge_type'] === 'percentage'
                                ? '%'
                                : htmlspecialchars(
                                    (string)$r['currency'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                )
                            ?>

                        </td>

                        <td>

                            <?= htmlspecialchars(
                                (string)$r['minimum_deposit'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                            –

                            <?= htmlspecialchars(
                                (string)$r['maximum_deposit'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                            <?= htmlspecialchars(
                                (string)$r['currency'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>

                        </td>

                        <td>

                            <span class="status-badge status-<?= htmlspecialchars(
                                (string)$r['status'],
                                ENT_QUOTES,
                                'UTF-8'
                            ) ?>">

                                <?= htmlspecialchars(
                                    (string)$r['status'],
                                    ENT_QUOTES,
                                    'UTF-8'
                                ) ?>

                            </span>

                        </td>

                        <td>

                            <div class="admin-actions">

                                <button
                                    type="button"
                                    class="vc-btn vc-btn-light edit-payment"
                                    data-payment='<?= htmlspecialchars(
                                        json_encode(
                                            $r,
                                            JSON_HEX_TAG |
                                            JSON_HEX_APOS |
                                            JSON_HEX_AMP |
                                            JSON_HEX_QUOT
                                        ),
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>'
                                >
                                    Edit
                                </button>

                                <button
                                    type="button"
                                    class="vc-btn vc-btn-light toggle-payment"
                                    data-id="<?= (int)$r['id'] ?>"
                                >
                                    <?= $r['status'] === 'active'
                                        ? 'Deactivate'
                                        : 'Activate'
                                    ?>
                                </button>

                                <button
                                    type="button"
                                    class="vc-btn vc-btn-danger delete-payment"
                                    data-id="<?= (int)$r['id'] ?>"
                                >
                                    Delete
                                </button>

                            </div>

                        </td>

                    </tr>

                <?php endforeach; ?>

            </tbody>

        </table>

    </div>

    <?= admin_pagination(
        $page,
        $perPage,
        $count
    ) ?>

</div>

<script>
(() => {

    const card = document.querySelector('#payment-form-card');
    const form = document.querySelector('#payment-form');
    const qrInput = document.querySelector('#qr-code');
    const qrPreview = document.querySelector('#qr-preview');
    const qrPreviewContainer = document.querySelector('#qr-preview-container');

    let existingQrCode = '';

    const clearPreview = () => {
        qrPreview.src = '';
        qrPreviewContainer.style.display = 'none';
    };

    const showPreview = (src) => {

        if (!src) {
            clearPreview();
            return;
        }

        qrPreview.src = src;
        qrPreviewContainer.style.display = 'block';
    };

    const show = (x) => {

        form.reset();

        form.id.value = x?.id || '';

        existingQrCode = x?.qr_code || '';

        if (x) {

            Object.keys(x).forEach(k => {

                if (
                    k !== 'qr_code' &&
                    form.elements[k]
                ) {
                    form.elements[k].value = x[k] ?? '';
                }

            });

            if (existingQrCode) {
                showPreview(existingQrCode);
            } else {
                clearPreview();
            }

        } else {

            existingQrCode = '';
            clearPreview();

        }

        card.hidden = false;

        window.scrollTo({
            top: 0,
            behavior: 'smooth'
        });
    };

    document.querySelector('#new-payment').onclick = () => show();

    document.querySelector('#cancel-payment').onclick = () => {
        card.hidden = true;
        form.reset();
        existingQrCode = '';
        clearPreview();
    };

    document.querySelectorAll('.edit-payment').forEach(button => {

        button.onclick = () => {

            show(
                JSON.parse(button.dataset.payment)
            );

        };

    });

    qrInput.addEventListener('change', () => {

        const file = qrInput.files[0];

        if (!file) {
            return;
        }

        const allowed = [
            'image/jpeg',
            'image/png',
            'image/webp'
        ];

        if (!allowed.includes(file.type)) {

            qrInput.value = '';

            window.flash(
                'QR code must be a JPG, PNG or WEBP image.',
                false
            );

            return;
        }

        if (file.size > 5 * 1024 * 1024) {

            qrInput.value = '';

            window.flash(
                'QR code image must not exceed 5 MB.',
                false
            );

            return;
        }

        const reader = new FileReader();

        reader.onload = () => {
            showPreview(reader.result);
        };

        reader.readAsDataURL(file);

    });

    document.querySelectorAll(
        '.toggle-payment,.delete-payment'
    ).forEach(button => {

        button.onclick = async () => {

            const action =
                button.classList.contains('delete-payment')
                    ? 'delete'
                    : 'toggle';

            const confirmed = confirm(
                action === 'delete'
                    ? 'Delete this payment method?'
                    : 'Change this payment method status?'
            );

            if (!confirmed) {
                return;
            }

            try {

                await window.adminApi(
                    '/api/admin/payment-methods.php',
                    {
                        method: 'POST',
                        body: JSON.stringify({
                            id: Number(button.dataset.id),
                            action
                        })
                    }
                );

                location.reload();

            } catch (e) {

                window.flash(
                    e.message,
                    false
                );

            }

        };

    });

    form.onsubmit = async (e) => {

        e.preventDefault();

        const file = qrInput.files[0];

        if (file) {

            const allowed = [
                'image/jpeg',
                'image/png',
                'image/webp'
            ];

            if (!allowed.includes(file.type)) {

                window.flash(
                    'QR code must be a JPG, PNG or WEBP image.',
                    false
                );

                return;
            }

            if (file.size > 5 * 1024 * 1024) {

                window.flash(
                    'QR code image must not exceed 5 MB.',
                    false
                );

                return;
            }

        }

        try {

            const formData = new FormData(form);

            await window.adminApi(
                '/api/admin/payment-methods.php',
                {
                    method: 'POST',
                    body: formData
                }
            );

            location.reload();

        } catch (e) {

            window.flash(
                e.message,
                false
            );

        }

    };

})();
</script>

<?php require __DIR__ . '/../includes/footer.php'; ?>