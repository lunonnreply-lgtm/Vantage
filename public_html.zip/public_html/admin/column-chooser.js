(function(){
  'use strict';
  const path=window.location.pathname.toLowerCase();
  const pageKey=path.includes('/deposits/')?'deposits':path.includes('/withdrawals/')?'withdrawals':path.includes('/users/')?'users':path.includes('/payment-methods/')?'payment-methods':path.includes('/investment-plans/')?'investment-plans':path.includes('/support/')?'support':'admin';
  const defaults={
    deposits:['reference','user','amount','status','action'],
    withdrawals:['reference','user','amount','status','action'],
    users:['user','email','status','action'],
    'payment-methods':['method','status','actions'],
    'investment-plans':['plan','return','status','actions'],
    support:['ticket','subject','status','action']
  };
  const normalize=s=>s.toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
  function keyFor(label){
    const k=normalize(label);
    const aliases={created:'created',updated:'updated',reference:'reference',user:'user',username:'username',email:'email',country:'country',role:'role',status:'status',action:'action',actions:'actions',amount:'amount',gateway:'gateway',method:'method',qr:'qr',charge:'charge',limits:'limits',wallet:'wallet',ticket:'ticket',subject:'subject',category:'category',plan:'plan',range:'range',return:'return',term:'term',capital:'capital'};
    return aliases[k]||k;
  }
  function storageKey(){return 'Vantage Institutional-admin-columns:'+pageKey;}
  function build(table){
    if(table.dataset.columnChooserReady==='1') return;
    const heads=[...table.querySelectorAll('thead th')]; if(!heads.length) return;
    const cols=heads.map((th,i)=>({i,key:keyFor(th.textContent.trim())||('col-'+i),label:th.textContent.trim()||('Column '+(i+1))}));
    const essential=new Set(defaults[pageKey]||cols.slice(0,2).map(c=>c.key));
    let saved={}; try{saved=JSON.parse(localStorage.getItem(storageKey())||'{}')||{}}catch(e){}
    const visible={}; cols.forEach(c=>visible[c.key]=saved[c.key]===undefined?true:!!saved[c.key]); essential.forEach(k=>visible[k]=true);
    const wrap=document.createElement('div'); wrap.className='column-chooser';
    wrap.innerHTML='<button type="button" class="column-chooser-toggle" aria-expanded="false">Columns <span aria-hidden="true">▾</span></button><div class="column-chooser-menu" hidden><strong>Show columns</strong><div class="column-chooser-options"></div><button type="button" class="column-chooser-reset">Reset</button></div>';
    const options=wrap.querySelector('.column-chooser-options');
    cols.forEach(c=>{if(essential.has(c.key)) return; const label=document.createElement('label'); label.className='column-option'; label.innerHTML='<input type="checkbox"> <span></span>'; label.querySelector('span').textContent=c.label; const input=label.querySelector('input'); input.checked=visible[c.key]; input.dataset.key=c.key; input.addEventListener('change',()=>{visible[c.key]=input.checked; save(); apply();}); options.appendChild(label);});
    const toggle=wrap.querySelector('.column-chooser-toggle'), menu=wrap.querySelector('.column-chooser-menu');
    toggle.addEventListener('click',e=>{e.stopPropagation(); const open=menu.hidden; menu.hidden=!open; toggle.setAttribute('aria-expanded',String(open));});
    document.addEventListener('click',e=>{if(!wrap.contains(e.target)){menu.hidden=true;toggle.setAttribute('aria-expanded','false');}});
    wrap.querySelector('.column-chooser-reset').addEventListener('click',()=>{cols.forEach(c=>visible[c.key]=true); try{localStorage.removeItem(storageKey())}catch(e){} options.querySelectorAll('input').forEach(i=>i.checked=true); apply();});
    table.parentElement.parentElement.insertBefore(wrap,table.parentElement);
    function save(){try{localStorage.setItem(storageKey(),JSON.stringify(visible))}catch(e){}}
    function apply(){
      cols.forEach(c=>{
        const show=visible[c.key]!==false;
        heads[c.i].classList.toggle('column-hidden-mobile',!show&&!essential.has(c.key));
        table.querySelectorAll('tbody tr').forEach(tr=>{if(tr.children[c.i]) tr.children[c.i].classList.toggle('column-hidden-mobile',!show&&!essential.has(c.key));});
      });
    }
    apply(); table.dataset.columnChooserReady='1';
  }
  function init(){document.querySelectorAll('.admin-table').forEach(build);}
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',init); else init();
})();
