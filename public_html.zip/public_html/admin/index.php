<?php
declare(strict_types=1);

$pageTitle = 'Admin Dashboard | Vantage Institutional';

require __DIR__ . '/includes/header.php';

/*
 * Dashboard statistics
 */
$stats = [
    'users' => 0,
    'active_users' => 0,
    'suspended_users' => 0,
    'deposits' => 0,
    'pending_withdrawals' => 0,
    'investments' => 0,
    'open_tickets' => 0,
    'visitors' => 0,
];

try {
    $q = $pdo->query('SELECT COUNT(*) FROM users');
    $stats['users'] = (int) $q->fetchColumn();

    $q = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'active'");
    $stats['active_users'] = (int) $q->fetchColumn();

    $q = $pdo->query("SELECT COUNT(*) FROM users WHERE status = 'suspended'");
    $stats['suspended_users'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
    // Keep dashboard usable if an optional table/column is unavailable.
}

/*
 * Count operational records from their current source tables.
 */
try {
    $q = $pdo->query("SELECT COUNT(*) FROM financial_requests WHERE type = 'deposit'");
    $stats['deposits'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
}

try {
    $q = $pdo->query("SELECT COUNT(*) FROM financial_requests WHERE type = 'withdrawal' AND status = 'pending'");
    $stats['pending_withdrawals'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
}

try {
    $q = $pdo->query('SELECT COUNT(*) FROM investments');
    $stats['investments'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
}

try {
    $q = $pdo->query("SELECT COUNT(*) FROM support_tickets WHERE status = 'open'");
    $stats['open_tickets'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
}

try {
    $q = $pdo->query('SELECT COUNT(*) FROM site_visitors');
    $stats['visitors'] = (int) $q->fetchColumn();
} catch (Throwable $e) {
}
?>

<div class="admin-page-head">
    <div>
        <h1>Admin Dashboard</h1>
        <p>Overview of Vantage Institutional operations.</p>
    </div>
</div>

<div class="admin-grid">

    <div class="admin-card">
        <h3>Total Users</h3>
        <div class="admin-stat">
            <?= number_format($stats['users']) ?>
        </div>
        <p>
            <a href="/admin/users/">Manage users →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Active Users</h3>
        <div class="admin-stat">
            <?= number_format($stats['active_users']) ?>
        </div>
        <p>Currently active accounts.</p>
    </div>

    <div class="admin-card">
        <h3>Suspended Users</h3>
        <div class="admin-stat">
            <?= number_format($stats['suspended_users']) ?>
        </div>
        <p>
            <a href="/admin/users/?status=suspended">View suspended →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Deposits</h3>
        <div class="admin-stat">
            <?= number_format($stats['deposits']) ?>
        </div>
        <p>
            <a href="/admin/deposits/">Manage deposits →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Pending Withdrawals</h3>
        <div class="admin-stat">
            <?= number_format($stats['pending_withdrawals']) ?>
        </div>
        <p>
            <a href="/admin/withdrawals/?status=pending">Review withdrawals →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Investments</h3>
        <div class="admin-stat">
            <?= number_format($stats['investments']) ?>
        </div>
        <p>
            <a href="/admin/investment-plans/">Investment plans →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Open Support Tickets</h3>
        <div class="admin-stat">
            <?= number_format($stats['open_tickets']) ?>
        </div>
        <p>
            <a href="/admin/support/?status=open">Review tickets →</a>
        </p>
    </div>

    <div class="admin-card">
        <h3>Unique Visitors</h3>
        <div class="admin-stat">
            <?= number_format($stats['visitors']) ?>
        </div>
        <p>
            <a href="/admin/visitors/">View visitor activity →</a>
        </p>
    </div>

</div>



<?php require __DIR__ . '/includes/footer.php'; ?>