<?php
declare(strict_types=1);
$pageTitle='Deposits | Vantage Institutional';
require __DIR__.'/../includes/header.php';
require __DIR__.'/../includes/pagination.php';
$perPage = min(100, max(10, (int)($_GET['per_page'] ?? 25)));
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;
$status=trim((string)($_GET['status']??''));
$search=trim((string)($_GET['search']??''));
$allowedSort=['reference'=>'fr.reference','amount'=>'fr.amount','gateway'=>'fr.gateway','status'=>'fr.status','created'=>'fr.created_at'];
$sortKey=(string)($_GET['sort']??'created'); $sort=$allowedSort[$sortKey]??$allowedSort['created'];
$dir=strtolower((string)($_GET['dir']??'desc')); $dir=$dir==='asc'?'asc':'desc';
$where=["fr.type='deposit'"]; $params=[];
if(in_array($status,['pending','approved','rejected','cancelled'],true)){$where[]='fr.status=:status';$params['status']=$status;}
$baseWhere=$where;$baseParams=$params;$useFulltext=false;
if($search!==''){
    $useFulltext=!admin_search_prefers_like($search) && admin_fulltext_query($search)!=='';
    if($useFulltext){$where[]='(MATCH(fr.reference,fr.gateway,fr.notes) AGAINST (:search_request_fulltext IN BOOLEAN MODE) OR MATCH(u.first_name,u.last_name,u.username,u.email,u.country) AGAINST (:search_user_fulltext IN BOOLEAN MODE))';$params['search_request_fulltext']=admin_fulltext_query($search);$params['search_user_fulltext']=admin_fulltext_query($search);}
    else{$where[]=admin_like_search_clause(['fr.reference','fr.gateway','fr.notes','u.first_name','u.last_name','u.username','u.email','u.country'],$search,$params,'deposit_search');}
}
$whereSql=implode(' AND ',$where);
$count=$pdo->prepare('SELECT COUNT(*) FROM financial_requests fr JOIN users u ON u.id=fr.user_id WHERE '.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();
if($search!=='' && $useFulltext && $total===0){$where=$baseWhere;$params=$baseParams;$where[]=admin_like_search_clause(['fr.reference','fr.gateway','fr.notes','u.first_name','u.last_name','u.username','u.email','u.country'],$search,$params,'deposit_fallback');$whereSql=implode(' AND ',$where);$count=$pdo->prepare('SELECT COUNT(*) FROM financial_requests fr JOIN users u ON u.id=fr.user_id WHERE '.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();}
$pages=max(1,(int)ceil($total/$perPage));if($page>$pages)$page=$pages;$offset=($page-1)*$perPage;
$q=$pdo->prepare('SELECT fr.id,fr.reference,fr.amount,fr.fee,fr.currency,fr.gateway,fr.status,fr.created_at,u.first_name,u.last_name,u.email,pm.name AS payment_name FROM financial_requests fr JOIN users u ON u.id=fr.user_id LEFT JOIN payment_methods pm ON pm.id=fr.payment_method_id WHERE '.$whereSql.' ORDER BY '.$sort.' '.$dir.', fr.id DESC LIMIT :limit OFFSET :offset');foreach($params as $k=>$v)$q->bindValue(':'.$k,$v);$q->bindValue(':limit',$perPage,PDO::PARAM_INT);$q->bindValue(':offset',$offset,PDO::PARAM_INT);$q->execute();$rows=$q->fetchAll();
$stats=$pdo->query("SELECT COUNT(*) total,SUM(status='pending') pending,SUM(status='approved') approved,SUM(status='rejected') rejected FROM financial_requests WHERE type='deposit'")->fetch()?:[];
?>
<div class="admin-page-head"><div><h1>Deposits</h1><p>Server-rendered records from <code>financial_requests</code> where <code>type='deposit'</code>.</p></div></div>
<div class="admin-stat-grid"><div class="admin-stat"><small>Total</small><strong><?= (int)($stats['total']??0) ?></strong></div><div class="admin-stat"><small>Pending</small><strong><?= (int)($stats['pending']??0) ?></strong></div><div class="admin-stat"><small>Approved</small><strong><?= (int)($stats['approved']??0) ?></strong></div><div class="admin-stat"><small>Rejected</small><strong><?= (int)($stats['rejected']??0) ?></strong></div></div>
<div class="admin-card"><form class="admin-toolbar" method="get"><div class="field"><input name="search" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" placeholder="Search reference, user or email"></div><div class="field"><select name="status"><option value="">All statuses</option><?php foreach(['pending','approved','rejected','cancelled'] as $s): ?><option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= ucfirst($s) ?></option><?php endforeach; ?></select></div><div class="admin-page-size"><label>Per page</label><select name="per_page" onchange="this.form.submit()"><?php foreach([10,25,50,100] as $n): ?><option value="<?= $n ?>" <?= $perPage===$n?'selected':'' ?>><?= $n ?></option><?php endforeach; ?></select></div><button class="vc-btn vc-btn-orange">Filter</button><a class="vc-btn vc-btn-light" href="/admin/deposits/">Reset</a></form>
<div class="table-wrap"><table class="admin-table"><thead><tr><th><?=admin_sort_link('reference','Reference',$sortKey,$dir)?></th><th>User</th><th><?=admin_sort_link('amount','Amount',$sortKey,$dir)?></th><th><?=admin_sort_link('gateway','Gateway',$sortKey,$dir)?></th><th>Method</th><th><?=admin_sort_link('status','Status',$sortKey,$dir)?></th><th><?=admin_sort_link('created','Created',$sortKey,$dir)?></th><th>Action</th></tr></thead><tbody>
<?php if(!$rows): ?><tr><td colspan="8">No deposits found.</td></tr><?php endif; ?>
<?php foreach($rows as $r): ?><tr><td><strong><?= htmlspecialchars((string)$r['reference']) ?></strong></td><td><?= htmlspecialchars(trim((string)$r['first_name'].' '.(string)$r['last_name'])) ?><br><span class="muted"><?= htmlspecialchars((string)$r['email']) ?></span></td><td><?= htmlspecialchars((string)$r['amount']) ?> <?= htmlspecialchars((string)$r['currency']) ?></td><td><?= htmlspecialchars((string)($r['gateway']??'—')) ?></td><td><?= htmlspecialchars((string)($r['payment_name']??'—')) ?></td><td><span class="status-badge status-<?= htmlspecialchars((string)$r['status']) ?>"><?= htmlspecialchars((string)$r['status']) ?></span></td><td><?= htmlspecialchars((string)$r['created_at']) ?></td><td><?php if($r['status']==='pending'): ?><form method="post" action="/api/admin/deposits.php" class="inline-api-form"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($_SESSION['csrf_token'] ?? ""),ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="requestId" value="<?= (int)$r['id'] ?>"><button name="action" value="approved" class="vc-btn vc-btn-green">Approve</button><button name="action" value="rejected" class="vc-btn vc-btn-danger">Reject</button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?=admin_pagination($page,$perPage,$total)?></div>
<?php require __DIR__.'/../includes/footer.php'; ?>
