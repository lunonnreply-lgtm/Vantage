<?php
declare(strict_types=1);
$pageTitle='Users | Vantage Institutional';
require __DIR__.'/../includes/header.php';
require __DIR__.'/../includes/pagination.php';
require __DIR__.'/../includes/fulltext-search.php';
$perPage = min(100, max(10, (int)($_GET['per_page'] ?? 25)));
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;
$status=trim((string)($_GET['status']??''));$search=trim((string)($_GET['search']??''));
$allowedSort=['name'=>'first_name','username'=>'username','email'=>'email','country'=>'country','role'=>'role','status'=>'status','created'=>'created_at'];$sortKey=(string)($_GET['sort']??'created');$sort=$allowedSort[$sortKey]??$allowedSort['created'];$dir=strtolower((string)($_GET['dir']??'desc'));$dir=$dir==='asc'?'asc':'desc';
$where=[];$params=[];
if(in_array($status,['active','suspended'],true)){$where[]='status=:status';$params['status']=$status;}
$baseWhere=$where;$baseParams=$params;$useFulltext=false;
if($search!==''){
    $useFulltext=!admin_search_prefers_like($search) && admin_fulltext_query($search)!=='';
    if($useFulltext){$where[]='MATCH(first_name,last_name,username,email,country) AGAINST (:search_fulltext IN BOOLEAN MODE)';$params['search_fulltext']=admin_fulltext_query($search);}
    else{$where[]=admin_like_search_clause(['first_name','last_name','username','email','country'],$search,$params,'user_search');}
}
$whereSql=$where?' WHERE '.implode(' AND ',$where):'';
$count=$pdo->prepare('SELECT COUNT(*) FROM users'.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();
if($search!=='' && $useFulltext && $total===0){$where=$baseWhere;$params=$baseParams;$where[]=admin_like_search_clause(['first_name','last_name','username','email','country'],$search,$params,'user_fallback');$whereSql=' WHERE '.implode(' AND ',$where);$count=$pdo->prepare('SELECT COUNT(*) FROM users'.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();}
$pages=max(1,(int)ceil($total/$perPage));if($page>$pages)$page=$pages;$offset=($page-1)*$perPage;$q=$pdo->prepare('SELECT id,first_name,last_name,email,username,country,phone,city,role,rank_id,status,created_at,updated_at FROM users'.$whereSql.' ORDER BY '.$sort.' '.$dir.', id DESC LIMIT :limit OFFSET :offset');foreach($params as $k=>$v)$q->bindValue(':'.$k,$v);$q->bindValue(':limit',$perPage,PDO::PARAM_INT);$q->bindValue(':offset',$offset,PDO::PARAM_INT);$q->execute();$rows=$q->fetchAll();
?>
<div class="admin-page-head"><div><h1>Users</h1><p>Server-rendered records from the real <code>users</code> table.</p></div></div>
<div class="admin-card"><form class="admin-toolbar" method="get"><div class="field"><input name="search" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" placeholder="Search name, username or email"></div><div class="field"><select name="status"><option value="">All statuses</option><option value="active" <?= $status==='active'?'selected':'' ?>>Active</option><option value="suspended" <?= $status==='suspended'?'selected':'' ?>>Suspended</option></select></div><div class="admin-page-size"><label>Per page</label><select name="per_page" onchange="this.form.submit()"><?php foreach([10,25,50,100] as $n): ?><option value="<?= $n ?>" <?= $perPage===$n?'selected':'' ?>><?= $n ?></option><?php endforeach; ?></select></div><button class="vc-btn vc-btn-orange">Filter</button><a class="vc-btn vc-btn-light" href="/admin/users/">Reset</a></form>
<div class="table-wrap"><table class="admin-table"><thead><tr><th><?=admin_sort_link('name','User',$sortKey,$dir)?></th><th><?=admin_sort_link('username','Username',$sortKey,$dir)?></th><th><?=admin_sort_link('email','Email',$sortKey,$dir)?></th><th><?=admin_sort_link('country','Country',$sortKey,$dir)?></th><th><?=admin_sort_link('role','Role',$sortKey,$dir)?></th><th><?=admin_sort_link('status','Status',$sortKey,$dir)?></th><th><?=admin_sort_link('created','Created',$sortKey,$dir)?></th><th>Action</th></tr></thead><tbody>
<?php if(!$rows): ?><tr><td colspan="8">No users found.</td></tr><?php endif; ?><?php foreach($rows as $r): ?><tr><td><strong><?= htmlspecialchars(trim((string)$r['first_name'].' '.(string)$r['last_name'])) ?></strong></td><td><?= htmlspecialchars((string)$r['username']) ?></td><td><?= htmlspecialchars((string)$r['email']) ?></td><td><?= htmlspecialchars((string)$r['country']) ?></td><td><?= htmlspecialchars((string)$r['role']) ?></td><td><span class="status-badge status-<?= htmlspecialchars((string)$r['status']) ?>"><?= htmlspecialchars((string)$r['status']) ?></span></td><td><?= htmlspecialchars((string)$r['created_at']) ?></td><td><?php if($r['role']!=='admin'): ?><form method="post" action="/api/admin/users.php" class="inline-api-form"><input type="hidden" name="csrf_token" value="<?= htmlspecialchars((string)($_SESSION['csrf_token'] ?? ""),ENT_QUOTES,'UTF-8') ?>"><input type="hidden" name="_admin_redirect" value="/admin/users/"><input type="hidden" name="userId" value="<?= (int)$r['id'] ?>"><input type="hidden" name="status" value="<?= $r['status']==='active'?'suspended':'active' ?>"><button class="vc-btn <?= $r['status']==='active'?'vc-btn-danger':'vc-btn-green' ?>"><?= $r['status']==='active'?'Suspend':'Activate' ?></button></form><?php else: ?>—<?php endif; ?></td></tr><?php endforeach; ?>
</tbody></table></div><?=admin_pagination($page,$perPage,$total)?></div>
<?php require __DIR__.'/../includes/footer.php'; ?>

