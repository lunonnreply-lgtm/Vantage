<?php

declare(strict_types=1);

$pageTitle = 'Visitor Activity | Vantage Institutional';
require __DIR__ . '/../includes/header.php';

$statsQuery = $pdo->query(
    'SELECT
        (SELECT COUNT(*) FROM site_visitors) AS unique_visitors,
        (SELECT COUNT(*) FROM site_visitor_visits) AS total_visits,
        (SELECT COUNT(*) FROM site_visitor_notifications WHERE status = "sent") AS notifications_sent'
);
$stats = $statsQuery->fetch() ?: [
    'unique_visitors' => 0,
    'total_visits' => 0,
    'notifications_sent' => 0,
];

$recentVisitsQuery = $pdo->query(
    'SELECT visited_at, ip_address, device, browser, operating_system,
            page_path, referrer, visitor_status
     FROM site_visitor_visits
     ORDER BY id DESC
     LIMIT 200'
);
$recentVisits = $recentVisitsQuery->fetchAll();

$notificationsQuery = $pdo->query(
    'SELECT n.created_at, n.completed_at, n.recipient_email, n.status,
            n.error_message, v.visited_at, v.ip_address, v.page_path,
            v.visitor_status
     FROM site_visitor_notifications n
     INNER JOIN site_visitor_visits v ON v.id = n.visit_id
     ORDER BY n.id DESC
     LIMIT 100'
);
$notificationHistory = $notificationsQuery->fetchAll();
?>

<div class="admin-page-head">
    <div>
        <h1>Visitor Activity</h1>
        <p>Recent site visits and visitor notification delivery history.</p>
    </div>
</div>

<div class="admin-stat-grid">
    <div class="admin-stat"><small>Unique Visitors</small><strong><?= number_format((int) $stats['unique_visitors']) ?></strong></div>
    <div class="admin-stat"><small>Recorded Visits</small><strong><?= number_format((int) $stats['total_visits']) ?></strong></div>
    <div class="admin-stat"><small>Emails Sent</small><strong><?= number_format((int) $stats['notifications_sent']) ?></strong></div>
</div>

<section class="admin-card">
    <h2>Recent Visits</h2>
    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr><th>Date/time</th><th>Visitor</th><th>IP address</th><th>Device</th><th>Browser / OS</th><th>Page</th><th>Referrer</th></tr>
            </thead>
            <tbody>
                <?php if (!$recentVisits): ?>
                    <tr><td colspan="7">No visits recorded yet.</td></tr>
                <?php endif; ?>
                <?php foreach ($recentVisits as $visit): ?>
                    <tr>
                        <td><?= htmlspecialchars((string) $visit['visited_at'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars(ucfirst((string) $visit['visitor_status']), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) ($visit['ip_address'] ?? 'Unavailable'), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) $visit['device'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) $visit['browser'] . ' / ' . (string) $visit['operating_system'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td class="visitor-path"><?= htmlspecialchars((string) $visit['page_path'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td class="visitor-path"><?= htmlspecialchars((string) ($visit['referrer'] ?? 'Direct visit'), ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<section class="admin-card">
    <h2>Notification History</h2>
    <div class="table-wrap">
        <table class="admin-table">
            <thead>
                <tr><th>Attempted</th><th>Recipient</th><th>Visitor</th><th>IP address</th><th>Page</th><th>Status</th><th>Details</th></tr>
            </thead>
            <tbody>
                <?php if (!$notificationHistory): ?>
                    <tr><td colspan="7">No notification attempts recorded yet.</td></tr>
                <?php endif; ?>
                <?php foreach ($notificationHistory as $notification): ?>
                    <tr>
                        <td><?= htmlspecialchars((string) $notification['created_at'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) ($notification['recipient_email'] ?? 'No active recipient'), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars(ucfirst((string) $notification['visitor_status']), ENT_QUOTES, 'UTF-8') ?></td>
                        <td><?= htmlspecialchars((string) ($notification['ip_address'] ?? 'Unavailable'), ENT_QUOTES, 'UTF-8') ?></td>
                        <td class="visitor-path"><?= htmlspecialchars((string) $notification['page_path'], ENT_QUOTES, 'UTF-8') ?></td>
                        <td><span class="status-badge status-<?= htmlspecialchars((string) $notification['status'], ENT_QUOTES, 'UTF-8') ?>"><?= htmlspecialchars(ucwords(str_replace('_', ' ', (string) $notification['status'])), ENT_QUOTES, 'UTF-8') ?></span></td>
                        <td><?= htmlspecialchars((string) ($notification['error_message'] ?? ''), ENT_QUOTES, 'UTF-8') ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</section>

<style>
.visitor-path {
    max-width: 260px;
    overflow-wrap: anywhere;
}
</style>

<?php require __DIR__ . '/../includes/footer.php'; ?>
