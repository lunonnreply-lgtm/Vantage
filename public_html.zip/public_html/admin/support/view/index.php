<?php

declare(strict_types=1);

$pageTitle = 'Support Ticket | Vantage Institutional';

require __DIR__ . '/../../includes/header.php';

$id = filter_var(
    $_GET['id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$id || $id <= 0) {
    http_response_code(404);

    echo '<div class="admin-card">';
    echo '<h1>Ticket not found</h1>';
    echo '</div>';

    require __DIR__ . '/../../includes/footer.php';
    exit;
}

/*
 * Load ticket.
 */
$ticketQuery = $pdo->prepare("
    SELECT
        t.id,
        t.user_id,
        t.subject,
        t.category,
        t.status,
        t.created_at,
        t.updated_at,
        u.first_name,
        u.last_name,
        u.email,
        u.username
    FROM support_tickets t
    JOIN users u
        ON u.id = t.user_id
    WHERE t.id = :id
    LIMIT 1
");

$ticketQuery->execute([
    'id' => $id,
]);

$ticket = $ticketQuery->fetch();

if (!$ticket) {
    http_response_code(404);

    echo '<div class="admin-card">';
    echo '<h1>Ticket not found</h1>';
    echo '</div>';

    require __DIR__ . '/../../includes/footer.php';
    exit;
}

/*
 * Load messages.
 */
$messageQuery = $pdo->prepare("
    SELECT
        m.id,
        m.ticket_id,
        m.author_user_id,
        m.message,
        m.created_at,
        u.first_name,
        u.last_name,
        u.email
    FROM support_ticket_messages m
    LEFT JOIN users u
        ON u.id = m.author_user_id
    WHERE m.ticket_id = :id
    ORDER BY m.created_at ASC, m.id ASC
");

$messageQuery->execute([
    'id' => $id,
]);

$messages = $messageQuery->fetchAll();

/*
 * Load attachments.
 */
$attachmentQuery = $pdo->prepare("
    SELECT
        id,
        ticket_id,
        message_id,
        uploaded_by_user_id,
        original_name,
        mime_type,
        file_size,
        created_at
    FROM support_ticket_attachments
    WHERE ticket_id = :id
    ORDER BY id ASC
");

$attachmentQuery->execute([
    'id' => $id,
]);

$attachments = $attachmentQuery->fetchAll();

/*
 * Group attachments by message.
 */
$attachmentsByMessage = [];

foreach ($attachments as $attachment) {

    $messageId = (int) $attachment['message_id'];

    if (!isset($attachmentsByMessage[$messageId])) {
        $attachmentsByMessage[$messageId] = [];
    }

    $attachmentsByMessage[$messageId][] = $attachment;
}

$adminUserId = (int) ($_SESSION['user_id'] ?? 0);

$csrfToken = (string) ($_SESSION['csrf_token'] ?? '');

?>

<style>
.support-ticket-attachment-list {
    margin-top: 12px;
    padding-top: 10px;
    border-top: 1px solid rgba(255, 255, 255, 0.08);
}

.support-ticket-attachment-title {
    margin-bottom: 7px;
    color: rgba(255, 255, 255, 0.5);
    font-size: 12px;
    font-weight: 500;
}

.support-ticket-attachment {
    display: flex;
    align-items: center;
    gap: 8px;
    margin-top: 6px;
    font-size: 13px;
}

.support-ticket-attachment a {
    color: #60a5fa;
    text-decoration: none;
    word-break: break-word;
}

.support-ticket-attachment a:hover {
    text-decoration: underline;
}

.support-ticket-attachment-icon {
    flex: 0 0 auto;
}

.support-ticket-upload {
    margin-top: 5px;
}

.support-ticket-upload input[type="file"] {
    width: 100%;
}

.support-ticket-upload-help {
    margin-top: 6px;
    color: rgba(255, 255, 255, 0.45);
    font-size: 12px;
}

.ticket-message.admin {
    border-left: 3px solid rgba(96, 165, 250, 0.45);
}
</style>

<div class="admin-page-head">

    <div>
        <h1>
            Support Ticket #<?= (int) $ticket['id'] ?>
        </h1>

        <p>
            Server-rendered conversation from
            <code>support_ticket_messages</code>.
        </p>
    </div>

    <a
        class="vc-btn vc-btn-light"
        href="/admin/support/"
    >
        Back
    </a>

</div>

<div class="admin-card">

    <div class="detail-grid">

        <div class="detail-item">
            <small>Subject</small>

            <strong>
                <?= htmlspecialchars(
                    (string) $ticket['subject'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </strong>
        </div>

        <div class="detail-item">

            <small>Client</small>

            <strong>
                <?= htmlspecialchars(
                    trim(
                        (string) $ticket['first_name'] .
                        ' ' .
                        (string) $ticket['last_name']
                    ),
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </strong>

            <span class="muted">
                <?= htmlspecialchars(
                    (string) $ticket['email'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </span>

        </div>

        <div class="detail-item">

            <small>Category</small>

            <strong>
                <?= htmlspecialchars(
                    (string) $ticket['category'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </strong>

        </div>

        <div class="detail-item">

            <small>Created</small>

            <strong>
                <?= htmlspecialchars(
                    (string) $ticket['created_at'],
                    ENT_QUOTES,
                    'UTF-8'
                ) ?>
            </strong>

        </div>

    </div>

</div>

<div class="admin-card">

    <div class="admin-toolbar">

        <strong>
            Conversation
        </strong>

        <span
            class="status-badge status-<?= htmlspecialchars(
                (string) $ticket['status'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >
            <?= htmlspecialchars(
                (string) $ticket['status'],
                ENT_QUOTES,
                'UTF-8'
            ) ?>
        </span>

    </div>

    <div class="message-list">

        <?php if (!$messages): ?>

            <p class="muted">
                No messages.
            </p>

        <?php endif; ?>

        <?php foreach ($messages as $message): ?>

            <?php

            $messageId = (int) $message['id'];

            $isAdmin =
                (int) $message['author_user_id'] ===
                $adminUserId;

            $messageAttachments =
                $attachmentsByMessage[$messageId] ?? [];

            ?>

            <article
                class="ticket-message <?= $isAdmin ? 'admin' : '' ?>"
            >

                <div class="meta">

                    <?= $isAdmin
                        ? 'Administrator'
                        : htmlspecialchars(
                            trim(
                                (string) (
                                    $message['first_name'] ?? ''
                                ) .
                                ' ' .
                                (string) (
                                    $message['last_name'] ?? ''
                                )
                            ),
                            ENT_QUOTES,
                            'UTF-8'
                        ) ?>

                    ·

                    <?= htmlspecialchars(
                        (string) $message['created_at'],
                        ENT_QUOTES,
                        'UTF-8'
                    ) ?>

                </div>

                <div>
                    <?= nl2br(
                        htmlspecialchars(
                            (string) $message['message'],
                            ENT_QUOTES,
                            'UTF-8'
                        )
                    ) ?>
                </div>

                <?php if ($messageAttachments): ?>

                    <div class="support-ticket-attachment-list">

                        <div class="support-ticket-attachment-title">

                            Attachment<?=
                                count($messageAttachments) > 1
                                    ? 's'
                                    : ''
                            ?>

                        </div>

                        <?php foreach ($messageAttachments as $attachment): ?>

                            <div class="support-ticket-attachment">

                                <span
                                    class="support-ticket-attachment-icon"
                                    aria-hidden="true"
                                >📎</span>

                                <a
                                    href="/api/admin/support-attachment.php?id=<?= (int) $attachment['id'] ?>"
                                    target="_blank"
                                    rel="noopener noreferrer"
                                >
                                    <?= htmlspecialchars(
                                        (string) $attachment['original_name'],
                                        ENT_QUOTES,
                                        'UTF-8'
                                    ) ?>
                                </a>

                            </div>

                        <?php endforeach; ?>

                    </div>

                <?php endif; ?>

            </article>

        <?php endforeach; ?>

    </div>

</div>

<div class="admin-card">

    <form
        class="vc-form"
        method="post"
        action="/api/admin/support-tickets.php"
        enctype="multipart/form-data"
    >

        <input
            type="hidden"
            name="csrf_token"
            value="<?= htmlspecialchars(
                $csrfToken,
                ENT_QUOTES,
                'UTF-8'
            ) ?>"
        >

        <input
            type="hidden"
            name="_admin_redirect"
            value="/admin/support/view/?id=<?= (int) $id ?>"
        >

        <input
            type="hidden"
            name="ticketId"
            value="<?= (int) $id ?>"
        >

        <div>

            <label>
                Status
            </label>

            <select name="status">

                <option
                    value="open"
                    <?= $ticket['status'] === 'open'
                        ? 'selected'
                        : '' ?>
                >
                    Open
                </option>

                <option
                    value="in_progress"
                    <?= $ticket['status'] === 'in_progress'
                        ? 'selected'
                        : '' ?>
                >
                    In progress
                </option>

                <option
                    value="resolved"
                    <?= $ticket['status'] === 'resolved'
                        ? 'selected'
                        : '' ?>
                >
                    Resolved
                </option>

                <option
                    value="closed"
                    <?= $ticket['status'] === 'closed'
                        ? 'selected'
                        : '' ?>
                >
                    Closed
                </option>

            </select>

        </div>

        <div class="full">

            <label>
                Reply
            </label>

            <textarea
                name="message"
                maxlength="5000"
                placeholder="Optional reply to the client"
            ></textarea>

        </div>

        <div class="full support-ticket-upload">

            <label for="ticket-attachment">
                Attachment
            </label>

            <input
                type="file"
                id="ticket-attachment"
                name="attachment"
                accept="image/jpeg,image/png,image/gif,image/webp"
            >

            <div class="support-ticket-upload-help">
                Optional. JPEG, PNG, GIF or WEBP. Maximum 5 MB.
            </div>

        </div>

        <div class="full form-actions">

            <button
                type="submit"
                class="vc-btn vc-btn-orange"
            >
                Save / Send Reply
            </button>

        </div>

    </form>

</div>

<script>
(function () {
    'use strict';

    var form = document.querySelector(
        'form[action="/api/admin/support-tickets.php"]'
    );

    var fileInput = document.getElementById(
        'ticket-attachment'
    );

    if (!form || !fileInput) {
        return;
    }

    form.addEventListener('submit', function (event) {

        if (
            !fileInput.files ||
            fileInput.files.length === 0
        ) {
            return;
        }

        var file = fileInput.files[0];

        if (file.size > 5 * 1024 * 1024) {

            event.preventDefault();

            window.alert(
                'Attachment must be smaller than 5 MB.'
            );

            fileInput.value = '';

            return;
        }

        /*
         * Client-side checks are only for convenience.
         * The PHP API performs the real security validation.
         */
        var allowedTypes = [
            'image/jpeg',
            'image/png',
            'image/gif',
            'image/webp'
        ];

        if (
            allowedTypes.indexOf(file.type) === -1
        ) {

            event.preventDefault();

            window.alert(
                'Only JPEG, PNG, GIF, and WEBP images are allowed.'
            );

            fileInput.value = '';
        }

    });

})();
</script>

<?php require __DIR__ . '/../../includes/footer.php'; ?>