<?php
declare(strict_types=1);
$pageTitle='Support | Vantage Institutional';
require __DIR__.'/../includes/header.php';
require __DIR__.'/../includes/pagination.php';
$perPage = min(100, max(10, (int)($_GET['per_page'] ?? 25)));
$page = max(1, (int)($_GET['page'] ?? 1));
$offset = ($page - 1) * $perPage;
$status=trim((string)($_GET['status']??''));$search=trim((string)($_GET['search']??''));$allowedSort=['ticket'=>'t.id','subject'=>'t.subject','category'=>'t.category','status'=>'t.status','updated'=>'t.updated_at'];$sortKey=(string)($_GET['sort']??'updated');$sort=$allowedSort[$sortKey]??$allowedSort['updated'];$dir=strtolower((string)($_GET['dir']??'desc'));$dir=$dir==='asc'?'asc':'desc';$where=[];$params=[];
if(in_array($status,['open','in_progress','resolved','closed'],true)){$where[]='t.status=:status';$params['status']=$status;}
$baseWhere=$where;$baseParams=$params;$useFulltext=false;
if($search!==''){
    $useFulltext=!admin_search_prefers_like($search) && admin_fulltext_query($search)!=='';
    if($useFulltext){$where[]='(MATCH(t.reference,t.subject,t.category) AGAINST (:search_ticket_fulltext IN BOOLEAN MODE) OR MATCH(u.first_name,u.last_name,u.username,u.email,u.country) AGAINST (:search_user_fulltext IN BOOLEAN MODE))';$params['search_ticket_fulltext']=admin_fulltext_query($search);$params['search_user_fulltext']=admin_fulltext_query($search);}
    else{$where[]=admin_like_search_clause(['t.reference','t.subject','t.category','u.first_name','u.last_name','u.username','u.email','u.country'],$search,$params,'support_search');}
}
$whereSql=$where?' WHERE '.implode(' AND ',$where):'';
$count=$pdo->prepare('SELECT COUNT(*) FROM support_tickets t JOIN users u ON u.id=t.user_id'.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();
if($search!=='' && $useFulltext && $total===0){$where=$baseWhere;$params=$baseParams;$where[]=admin_like_search_clause(['t.reference','t.subject','t.category','u.first_name','u.last_name','u.username','u.email','u.country'],$search,$params,'support_fallback');$whereSql=' WHERE '.implode(' AND ',$where);$count=$pdo->prepare('SELECT COUNT(*) FROM support_tickets t JOIN users u ON u.id=t.user_id'.$whereSql);$count->execute($params);$total=(int)$count->fetchColumn();}
$pages=max(1,(int)ceil($total/$perPage));if($page>$pages)$page=$pages;$offset=($page-1)*$perPage;$q=$pdo->prepare('SELECT t.id,t.user_id,t.subject,t.category,t.status,t.created_at,t.updated_at,u.first_name,u.last_name,u.email FROM support_tickets t JOIN users u ON u.id=t.user_id'.$whereSql.' ORDER BY '.$sort.' '.$dir.',t.id DESC LIMIT :limit OFFSET :offset');foreach($params as $k=>$v)$q->bindValue(':'.$k,$v);$q->bindValue(':limit',$perPage,PDO::PARAM_INT);$q->bindValue(':offset',$offset,PDO::PARAM_INT);$q->execute();$rows=$q->fetchAll();
?>
<div class="admin-page-head"><div><h1>Support Inbox</h1><p>Server-rendered <code>support_tickets</code> joined to <code>users</code>.</p></div></div>
<div class="admin-card"><form class="admin-toolbar" method="get"><div class="field"><input name="search" value="<?= htmlspecialchars($search,ENT_QUOTES,'UTF-8') ?>" placeholder="Search subject, name or email"></div><div class="field"><select name="status"><option value="">All statuses</option><?php foreach(['open','in_progress','resolved','closed'] as $s): ?><option value="<?= $s ?>" <?= $status===$s?'selected':'' ?>><?= ucwords(str_replace('_',' ',$s)) ?></option><?php endforeach; ?></select></div><div class="admin-page-size"><label>Per page</label><select name="per_page" onchange="this.form.submit()"><?php foreach([10,25,50,100] as $n): ?><option value="<?= $n ?>" <?= $perPage===$n?'selected':'' ?>><?= $n ?></option><?php endforeach; ?></select></div><button class="vc-btn vc-btn-orange">Filter</button><a class="vc-btn vc-btn-light" href="/admin/support/">Reset</a></form>
<div class="table-wrap"><table class="admin-table"><thead><tr><th><?=admin_sort_link('ticket','Ticket',$sortKey,$dir)?></th><th><?=admin_sort_link('subject','Subject',$sortKey,$dir)?></th><th>Client</th><th><?=admin_sort_link('category','Category',$sortKey,$dir)?></th><th><?=admin_sort_link('status','Status',$sortKey,$dir)?></th><th><?=admin_sort_link('updated','Updated',$sortKey,$dir)?></th><th>Action</th></tr></thead><tbody><?php if(!$rows): ?><tr><td colspan="7">No tickets found.</td></tr><?php endif; ?><?php foreach($rows as $r): ?><tr><td>#<?= (int)$r['id'] ?></td><td><strong><?= htmlspecialchars((string)$r['subject']) ?></strong></td><td><?= htmlspecialchars(trim((string)$r['first_name'].' '.(string)$r['last_name'])) ?><br><span class="muted"><?= htmlspecialchars((string)$r['email']) ?></span></td><td><?= htmlspecialchars((string)$r['category']) ?></td><td><span class="status-badge status-<?= htmlspecialchars((string)$r['status']) ?>"><?= htmlspecialchars((string)$r['status']) ?></span></td><td><?= htmlspecialchars((string)$r['updated_at']) ?></td><td><a class="vc-btn vc-btn-light" href="/admin/support/view/?id=<?= (int)$r['id'] ?>">Open</a></td></tr><?php endforeach; ?></tbody></table></div><?=admin_pagination($page,$perPage,$total)?></div>
<?php require __DIR__.'/../includes/footer.php'; ?>


