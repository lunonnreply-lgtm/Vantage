<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $query = $pdo->prepare('
        SELECT
            id,
            reference,
            subject,
            category,
            status,
            created_at,
            updated_at
        FROM support_tickets
        WHERE user_id = :user_id
        ORDER BY updated_at DESC
    ');

    $query->execute([
        'user_id' => $userId,
    ]);

    respond([
        'tickets' => $query->fetchAll(),
    ]);
}

require_post();
require_csrf();

$input = json_input();

$subject = trim((string) ($input['subject'] ?? ''));
$category = trim((string) ($input['category'] ?? 'general'));
$message = trim((string) ($input['message'] ?? ''));

if (
    $subject === '' ||
    strlen($subject) > 180 ||
    strlen($category) > 60 ||
    $message === '' ||
    strlen($message) > 5000
) {
    respond([
        'error' => 'Enter a valid subject, category, and message.',
    ], 422);
}

$pdo->beginTransaction();

try {
    /*
     * Generate a unique ticket reference.
     * Example: SUPT347541
     */
    do {
        $reference = 'SUPT' . str_pad(
            (string) random_int(0, 999999),
            6,
            '0',
            STR_PAD_LEFT
        );

        $referenceCheck = $pdo->prepare('
            SELECT id
            FROM support_tickets
            WHERE reference = :reference
            LIMIT 1
        ');

        $referenceCheck->execute([
            'reference' => $reference,
        ]);

        $referenceExists = $referenceCheck->fetchColumn() !== false;

    } while ($referenceExists);

    /*
     * Create the ticket.
     */
    $ticket = $pdo->prepare('
        INSERT INTO support_tickets (
            user_id,
            reference,
            subject,
            category
        ) VALUES (
            :user_id,
            :reference,
            :subject,
            :category
        )
    ');

    $ticket->execute([
        'user_id' => $userId,
        'reference' => $reference,
        'subject' => $subject,
        'category' => $category,
    ]);

    /*
     * Save the ticket ID before inserting the message.
     */
    $ticketId = (int) $pdo->lastInsertId();

    /*
     * Create the first ticket message.
     */
    $messageQuery = $pdo->prepare('
        INSERT INTO support_ticket_messages (
            ticket_id,
            author_user_id,
            message
        ) VALUES (
            :ticket_id,
            :author_user_id,
            :message
        )
    ');

    $messageQuery->execute([
        'ticket_id' => $ticketId,
        'author_user_id' => $userId,
        'message' => $message,
    ]);

    $pdo->commit();

    respond([
        'message' => 'Support ticket submitted.',
        'ticketId' => $ticketId,
        'reference' => $reference,
        'status' => 'open',
    ], 201);

} catch (Throwable $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    respond([
        'error' => 'Support ticket could not be submitted.',
    ], 500);
}