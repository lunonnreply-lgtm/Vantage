<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();

$attachmentId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$attachmentId || $attachmentId <= 0) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Only allow attachments belonging to a ticket
 * owned by the currently authenticated user.
 */
$query = $pdo->prepare('
    SELECT
        sta.id,
        sta.ticket_id,
        sta.original_name,
        sta.stored_name,
        sta.file_path,
        sta.mime_type,
        sta.file_size
    FROM support_ticket_attachments sta
    INNER JOIN support_tickets st
        ON st.id = sta.ticket_id
    WHERE sta.id = :attachment_id
      AND st.user_id = :user_id
    LIMIT 1
');

$query->execute([
    'attachment_id' => $attachmentId,
    'user_id' => $userId,
]);

$attachment = $query->fetch();

if (!$attachment) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Build the storage path from the trusted stored filename.
 *
 * Do not trust file_path from the URL or user input.
 */
$storageDirectory = realpath(
    __DIR__ . '/../../storage/uploads/support'
);

if ($storageDirectory === false) {
    http_response_code(404);
    exit('Attachment not found.');
}

$storedName = basename(
    (string) $attachment['stored_name']
);

$filePath = $storageDirectory . DIRECTORY_SEPARATOR . $storedName;

$realFilePath = realpath($filePath);

/*
 * Make sure the resolved file is actually inside
 * the support attachment storage directory.
 */
if (
    $realFilePath === false ||
    !is_file($realFilePath) ||
    !is_readable($realFilePath) ||
    !str_starts_with(
        $realFilePath,
        $storageDirectory . DIRECTORY_SEPARATOR
    )
) {
    http_response_code(404);
    exit('Attachment not found.');
}

$mimeType = (string) $attachment['mime_type'];

$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
];

if (!in_array($mimeType, $allowedMimeTypes, true)) {
    http_response_code(403);
    exit('Attachment type not allowed.');
}

$fileSize = filesize($realFilePath);

if ($fileSize === false) {
    http_response_code(404);
    exit('Attachment not found.');
}

$originalName = basename(
    (string) $attachment['original_name']
);

$downloadName = str_replace(
    ["\r", "\n", '"'],
    '',
    $originalName
);

if ($downloadName === '') {
    $downloadName = 'attachment';
}

/*
 * Serve the image inline so the user can view it
 * directly in the browser.
 */
header('Content-Type: ' . $mimeType);
header('Content-Length: ' . (string) $fileSize);
header(
    'Content-Disposition: inline; filename="' .
    $downloadName .
    '"'
);
header('X-Content-Type-Options: nosniff');
header('Cache-Control: private, no-store, max-age=0');
header('Pragma: no-cache');

readfile($realFilePath);
exit;