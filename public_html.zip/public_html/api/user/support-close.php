<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();

require_post();
require_csrf();

$input = json_input();

$ticketId = (int) ($input['ticketId'] ?? 0);

if ($ticketId <= 0) {
    respond([
        'error' => 'Invalid ticket.',
    ], 422);
}

$ticketQuery = $pdo->prepare('
    SELECT
        id,
        status
    FROM support_tickets
    WHERE id = :ticket_id
      AND user_id = :user_id
    LIMIT 1
');

$ticketQuery->execute([
    'ticket_id' => $ticketId,
    'user_id' => $userId,
]);

$ticket = $ticketQuery->fetch();

if (!$ticket) {
    respond([
        'error' => 'Support ticket not found.',
    ], 404);
}

if (strtolower((string) $ticket['status']) === 'closed') {
    respond([
        'message' => 'Support ticket is already closed.',
        'ticketId' => $ticketId,
        'status' => 'closed',
    ]);
}

$update = $pdo->prepare('
    UPDATE support_tickets
    SET
        status = :status,
        updated_at = CURRENT_TIMESTAMP
    WHERE id = :ticket_id
      AND user_id = :user_id
');

$update->execute([
    'status' => 'closed',
    'ticket_id' => $ticketId,
    'user_id' => $userId,
]);

respond([
    'message' => 'Support ticket closed successfully.',
    'ticketId' => $ticketId,
    'status' => 'closed',
]);