<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    header('Location: /portal/settings');
    exit;
}

require_csrf();

try {
    $pdo->beginTransaction();

    $stmt = $pdo->prepare("
        SELECT
            id,
            gender,
            date_of_birth,
            phone,
            city,
            zip_code,
            address,
            photo
        FROM users
        WHERE id = :id
        LIMIT 1
        FOR UPDATE
    ");

    $stmt->execute([
        ':id' => $userId,
    ]);

    $user = $stmt->fetch();

    if (!$user) {
        throw new RuntimeException('User account was not found.');
    }

    $gender = isset($_POST['gender']) ? trim((string) $_POST['gender']) : '';
    $dateOfBirth = isset($_POST['date_of_birth']) ? trim((string) $_POST['date_of_birth']) : '';
    $phone = isset($_POST['phone']) ? trim((string) $_POST['phone']) : '';
    $city = isset($_POST['city']) ? trim((string) $_POST['city']) : '';
    $zipCode = isset($_POST['zip_code']) ? trim((string) $_POST['zip_code']) : '';
    $address = isset($_POST['address']) ? trim((string) $_POST['address']) : '';

    if ($gender !== '' && !in_array($gender, ['male', 'female', 'other'], true)) {
        throw new RuntimeException('Invalid gender selected.');
    }

    if ($dateOfBirth !== '') {
        $date = DateTime::createFromFormat('Y-m-d', $dateOfBirth);

        if (!$date || $date->format('Y-m-d') !== $dateOfBirth) {
            throw new RuntimeException('Please enter a valid date of birth.');
        }

        if ($date > new DateTime('today')) {
            throw new RuntimeException('Date of birth cannot be in the future.');
        }
    }

    if (strlen($phone) > 30) {
        throw new RuntimeException('Phone number is too long.');
    }

    if (strlen($city) > 100) {
        throw new RuntimeException('City name is too long.');
    }

    if (strlen($zipCode) > 30) {
        throw new RuntimeException('ZIP/postal code is too long.');
    }

    if (strlen($address) > 255) {
        throw new RuntimeException('Address is too long.');
    }

    $newPhoto = null;
    $oldPhoto = isset($user['photo']) ? trim((string) $user['photo']) : '';

    if (
        isset($_FILES['avatar']) &&
        isset($_FILES['avatar']['error']) &&
        $_FILES['avatar']['error'] !== UPLOAD_ERR_NO_FILE
    ) {
        if ($_FILES['avatar']['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException('The avatar upload failed.');
        }

        if ($_FILES['avatar']['size'] > 2 * 1024 * 1024) {
            throw new RuntimeException('Avatar must not be larger than 2MB.');
        }

        $tmpFile = $_FILES['avatar']['tmp_name'];

        if (!is_uploaded_file($tmpFile)) {
            throw new RuntimeException('Invalid avatar upload.');
        }

        $imageInfo = @getimagesize($tmpFile);

        if ($imageInfo === false) {
            throw new RuntimeException('The uploaded avatar is not a valid image.');
        }

        $mime = isset($imageInfo['mime']) ? $imageInfo['mime'] : '';

        $allowedMimeTypes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
        ];

        if (!isset($allowedMimeTypes[$mime])) {
            throw new RuntimeException('Avatar must be a JPG, PNG, or GIF image.');
        }

        $uploadDirectory = __DIR__ . '/../../uploads/avatars';

        if (!is_dir($uploadDirectory)) {
            if (!mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
                throw new RuntimeException('Unable to create avatar upload directory.');
            }
        }

        $fileName = 'avatar_' . $userId . '_' . bin2hex(random_bytes(8)) . '.' . $allowedMimeTypes[$mime];

        $destination = $uploadDirectory . '/' . $fileName;

        if (!move_uploaded_file($tmpFile, $destination)) {
            throw new RuntimeException('Unable to save the uploaded avatar.');
        }

        $newPhoto = '/uploads/avatars/' . $fileName;
    }

    if ($newPhoto !== null) {
        $update = $pdo->prepare("
            UPDATE users
            SET
                gender = :gender,
                date_of_birth = :date_of_birth,
                phone = :phone,
                city = :city,
                zip_code = :zip_code,
                address = :address,
                photo = :photo
            WHERE id = :id
        ");

        $update->execute([
            ':gender' => $gender !== '' ? $gender : null,
            ':date_of_birth' => $dateOfBirth !== '' ? $dateOfBirth : null,
            ':phone' => $phone !== '' ? $phone : null,
            ':city' => $city !== '' ? $city : null,
            ':zip_code' => $zipCode !== '' ? $zipCode : null,
            ':address' => $address !== '' ? $address : null,
            ':photo' => $newPhoto,
            ':id' => $userId,
        ]);
    } else {
        $update = $pdo->prepare("
            UPDATE users
            SET
                gender = :gender,
                date_of_birth = :date_of_birth,
                phone = :phone,
                city = :city,
                zip_code = :zip_code,
                address = :address
            WHERE id = :id
        ");

        $update->execute([
            ':gender' => $gender !== '' ? $gender : null,
            ':date_of_birth' => $dateOfBirth !== '' ? $dateOfBirth : null,
            ':phone' => $phone !== '' ? $phone : null,
            ':city' => $city !== '' ? $city : null,
            ':zip_code' => $zipCode !== '' ? $zipCode : null,
            ':address' => $address !== '' ? $address : null,
            ':id' => $userId,
        ]);
    }

    $pdo->commit();

    if ($newPhoto !== null && $oldPhoto !== '') {
        $oldFile = __DIR__ . '/../../' . ltrim($oldPhoto, '/');

        if (is_file($oldFile) && strpos(realpath($oldFile), realpath(__DIR__ . '/../../uploads/avatars')) === 0) {
            @unlink($oldFile);
        }
    }

    $_SESSION['settings_success'] = 'Your profile settings have been updated successfully.';

    header('Location: /portal/settings');
    exit;
} catch (Throwable $e) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    $_SESSION['settings_error'] = $e->getMessage();

    header('Location: /portal/settings');
    exit;
}