<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();
require_post();
require_csrf();

$input = json_input();

$investmentId = filter_var(
    $input['investmentId'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$investmentId) {
    respond([
        'error' => 'Select a valid investment.'
    ], 422);
}

try {
    $pdo->beginTransaction();

    /*
     * Lock the investment and make sure it belongs
     * to the currently authenticated user.
     */
    $investmentQuery = $pdo->prepare(
        "SELECT
            i.id,
            i.user_id,
            i.plan_id,
            i.source_account_id,
            i.profit_account_id,
            i.principal,
            i.currency,
            i.starts_at,
            i.status,
            i.reference,
            p.cancel_minutes,
            p.name AS plan_name
         FROM investments i
         INNER JOIN investment_plans p
             ON p.id = i.plan_id
         WHERE i.id = :investment_id
           AND i.user_id = :user_id
           AND i.currency = 'USD'
           AND i.status = 'active'
         FOR UPDATE"
    );

    $investmentQuery->execute([
        'investment_id' => $investmentId,
        'user_id' => $userId
    ]);

    $investment = $investmentQuery->fetch();

    if (!$investment) {
        $pdo->rollBack();

        respond([
            'error' => 'The investment could not be found or is no longer active.'
        ], 404);
    }

    /*
     * Check whether the cancellation period has expired.
     */
    $startsAt = new DateTimeImmutable(
        $investment['starts_at']
    );

    $now = new DateTimeImmutable('now');

    $cancelMinutes = (int) $investment['cancel_minutes'];

    $cancelDeadline = $startsAt->modify(
        '+' . $cancelMinutes . ' minutes'
    );

    if ($now > $cancelDeadline) {
        $pdo->rollBack();

        respond([
            'error' => 'The cancellation period for this investment has expired.'
        ], 422);
    }

    $payoutCheck = $pdo->prepare(
        'SELECT 1 FROM investment_daily_payouts WHERE investment_id = :investment_id LIMIT 1'
    );
    $payoutCheck->execute([
        'investment_id' => $investmentId,
    ]);

    if ($payoutCheck->fetchColumn()) {
        $pdo->rollBack();

        respond([
            'error' => 'This investment cannot be cancelled after daily payouts have started.'
        ], 422);
    }

    /*
     * Lock the user's USD main wallet.
     */
    $walletQuery = $pdo->prepare(
        "SELECT
            id,
            available_balance
         FROM accounts
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
         FOR UPDATE"
    );

    $walletQuery->execute([
        'account_id' => $investment['source_account_id'],
        'user_id' => $userId
    ]);

    $wallet = $walletQuery->fetch();

    if (!$wallet) {
        $pdo->rollBack();

        respond([
            'error' => 'Your USD main wallet could not be found.'
        ], 409);
    }

    $principal = number_format(
        (float) $investment['principal'],
        2,
        '.',
        ''
    );

    /*
     * Refund the investment principal.
     */
    $refund = $pdo->prepare(
        "UPDATE accounts
         SET available_balance = available_balance + :refund_amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'"
    );

    $refund->execute([
        'refund_amount' => $principal,
        'account_id' => $wallet['id'],
        'user_id' => $userId
    ]);

    if ($refund->rowCount() !== 1) {
        $pdo->rollBack();

        respond([
            'error' => 'The wallet could not be refunded. Please try again.'
        ], 409);
    }

    /*
     * Mark the investment as cancelled.
     */
    $cancel = $pdo->prepare(
        "UPDATE investments
         SET status = 'cancelled'
         WHERE id = :investment_id
           AND user_id = :user_id
           AND status = 'active'"
    );

    $cancel->execute([
        'investment_id' => $investmentId,
        'user_id' => $userId
    ]);

    if ($cancel->rowCount() !== 1) {
        $pdo->rollBack();

        respond([
            'error' => 'The investment status could not be updated. Please try again.'
        ], 409);
    }

    /*
     * Record the refund in the ledger.
     */
    $ledgerInsert = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'investment_cancelled',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $ledgerInsert->execute([
        'user_id' => $userId,
        'account_id' => $wallet['id'],
        'amount' => $principal,
        'description' => 'Investment cancelled ' . $investment['reference']
    ]);

    $pdo->commit();

    respond([
        'message' => 'Investment cancelled successfully.',
        'reference' => $investment['reference'],
        'currency' => 'USD',
        'refundedAmount' => $principal
    ], 200);

} catch (Throwable $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    respond([
        'error' => 'The investment could not be cancelled. Please try again.'
    ], 500);
}