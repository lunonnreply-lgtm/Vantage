<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();

require_post();
require_csrf();

$ticketId = filter_input(
    INPUT_POST,
    'ticketId',
    FILTER_VALIDATE_INT
);

$message = trim(
    (string) ($_POST['message'] ?? '')
);

if (!$ticketId || $ticketId <= 0) {
    respond([
        'error' => 'Invalid ticket.',
    ], 422);
}

if ($message === '' || strlen($message) > 5000) {
    respond([
        'error' => 'Enter a valid reply.',
    ], 422);
}

/*
 * ---------------------------------------------------------
 * Validate uploaded attachment
 * ---------------------------------------------------------
 */

$attachment = null;

if (
    isset($_FILES['attachment']) &&
    is_array($_FILES['attachment'])
) {
    $uploadError = (int) (
        $_FILES['attachment']['error'] ??
        UPLOAD_ERR_NO_FILE
    );

    if ($uploadError !== UPLOAD_ERR_NO_FILE) {

        if ($uploadError !== UPLOAD_ERR_OK) {
            respond([
                'error' => 'The attachment could not be uploaded.',
            ], 422);
        }

        /*
         * Only accept one file.
         */
        if (
            is_array($_FILES['attachment']['name']) ||
            is_array($_FILES['attachment']['tmp_name']) ||
            is_array($_FILES['attachment']['size'])
        ) {
            respond([
                'error' => 'Only one attachment is allowed.',
            ], 422);
        }

        $tmpName = (string) (
            $_FILES['attachment']['tmp_name'] ?? ''
        );

        $originalName = (string) (
            $_FILES['attachment']['name'] ?? ''
        );

        $fileSize = (int) (
            $_FILES['attachment']['size'] ?? 0
        );

        /*
         * Verify this is an actual HTTP uploaded file.
         */
        if (
            $tmpName === '' ||
            !is_uploaded_file($tmpName)
        ) {
            respond([
                'error' => 'Invalid attachment upload.',
            ], 422);
        }

        /*
         * Maximum 5 MB.
         */
        $maxFileSize = 5 * 1024 * 1024;

        if (
            $fileSize <= 0 ||
            $fileSize > $maxFileSize
        ) {
            respond([
                'error' => 'Attachment must be smaller than 5 MB.',
            ], 422);
        }

        /*
         * Verify the temporary file exists and is readable.
         */
        if (
            !is_file($tmpName) ||
            !is_readable($tmpName)
        ) {
            respond([
                'error' => 'The uploaded attachment could not be read.',
            ], 422);
        }

        /*
         * -------------------------------------------------
         * MIME validation
         * -------------------------------------------------
         *
         * Never trust $_FILES['type'].
         * Detect the MIME type from the actual file.
         */
        $finfo = new finfo(FILEINFO_MIME_TYPE);

        $mimeType = (string) $finfo->file($tmpName);

        /*
         * Only these image formats are accepted.
         *
         * The extension is determined by the server,
         * not by the user's filename.
         */
        $allowedTypes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp',
        ];

        if (!isset($allowedTypes[$mimeType])) {
            respond([
                'error' => 'Only JPG, PNG, GIF, and WEBP images are allowed.',
            ], 422);
        }

        /*
         * -------------------------------------------------
         * File-content validation
         * -------------------------------------------------
         *
         * MIME detection alone is not enough.
         * Confirm that PHP can actually recognize the
         * uploaded file as an image.
         */
        $imageInfo = @getimagesize($tmpName);

        if ($imageInfo === false) {
            respond([
                'error' => 'The attachment is not a valid image.',
            ], 422);
        }

        /*
         * Make sure the detected image MIME agrees with
         * the MIME detected by finfo.
         */
        $imageMime = '';

        if (
            isset($imageInfo['mime']) &&
            is_string($imageInfo['mime'])
        ) {
            $imageMime = $imageInfo['mime'];
        }

        if (
            $imageMime === '' ||
            $imageMime !== $mimeType
        ) {
            respond([
                'error' => 'The attachment contents are invalid.',
            ], 422);
        }

        /*
         * Require sensible image dimensions.
         *
         * This prevents malformed images with unreasonable
         * dimensions from being accepted.
         */
        $imageWidth = (int) (
            $imageInfo[0] ?? 0
        );

        $imageHeight = (int) (
            $imageInfo[1] ?? 0
        );

        if (
            $imageWidth <= 0 ||
            $imageHeight <= 0 ||
            $imageWidth > 10000 ||
            $imageHeight > 10000
        ) {
            respond([
                'error' => 'The image dimensions are not allowed.',
            ], 422);
        }

        /*
         * -------------------------------------------------
         * Filename validation
         * -------------------------------------------------
         *
         * The original filename is NEVER used as the
         * physical storage filename.
         *
         * It is kept only as display metadata.
         */
        $originalName = basename($originalName);

        /*
         * Remove control characters.
         */
        $originalName = preg_replace(
            '/[\x00-\x1F\x7F]/u',
            '',
            $originalName
        );

        if (!is_string($originalName)) {
            $originalName = '';
        }

        $originalName = trim($originalName);

        /*
         * Prevent excessively long filenames.
         */
        if (strlen($originalName) > 255) {
            $originalName = substr(
                $originalName,
                0,
                255
            );
        }

        if ($originalName === '') {
            $originalName =
                'attachment.' .
                $allowedTypes[$mimeType];
        }

        /*
         * Never trust the user's extension.
         *
         * We only use the extension determined from
         * the server-side MIME validation.
         */
        $extension = $allowedTypes[$mimeType];

        $attachment = [
            'tmp_name' => $tmpName,
            'original_name' => $originalName,
            'file_size' => $fileSize,
            'mime_type' => $mimeType,
            'extension' => $extension,
        ];
    }
}

/*
 * ---------------------------------------------------------
 * Verify ticket ownership
 * ---------------------------------------------------------
 */

$ticketQuery = $pdo->prepare('
    SELECT
        id,
        status
    FROM support_tickets
    WHERE id = :ticket_id
      AND user_id = :user_id
    LIMIT 1
');

$ticketQuery->execute([
    'ticket_id' => $ticketId,
    'user_id' => $userId,
]);

$ticket = $ticketQuery->fetch();

if (!$ticket) {
    respond([
        'error' => 'Ticket not found.',
    ], 404);
}

if (
    strtolower(
        (string) $ticket['status']
    ) === 'closed'
) {
    respond([
        'error' => 'This ticket is closed.',
    ], 409);
}

/*
 * ---------------------------------------------------------
 * Create message + attachment atomically
 * ---------------------------------------------------------
 */

$pdo->beginTransaction();

$storedPath = null;

try {

    /*
     * Create the support message first.
     */
    $messageQuery = $pdo->prepare('
        INSERT INTO support_ticket_messages (
            ticket_id,
            author_user_id,
            message
        ) VALUES (
            :ticket_id,
            :author_user_id,
            :message
        )
    ');

    $messageQuery->execute([
        'ticket_id' => $ticketId,
        'author_user_id' => $userId,
        'message' => $message,
    ]);

    $messageId = (int) $pdo->lastInsertId();

    /*
     * -----------------------------------------------------
     * Store attachment
     * -----------------------------------------------------
     */

    if ($attachment !== null) {

        $storageDirectory = __DIR__ .
            '/../../storage/uploads/support';

        /*
         * Create directory if necessary.
         */
        if (!is_dir($storageDirectory)) {

            if (
                !mkdir(
                    $storageDirectory,
                    0755,
                    true
                ) &&
                !is_dir($storageDirectory)
            ) {
                throw new RuntimeException(
                    'Could not create attachment directory.'
                );
            }
        }

        /*
         * Confirm the storage directory is actually
         * a directory and writable.
         */
        if (
            !is_dir($storageDirectory) ||
            !is_writable($storageDirectory)
        ) {
            throw new RuntimeException(
                'Attachment directory is not writable.'
            );
        }

        /*
         * Resolve the directory so that we can ensure
         * the final file cannot escape it.
         */
        $realStorageDirectory = realpath(
            $storageDirectory
        );

        if ($realStorageDirectory === false) {
            throw new RuntimeException(
                'Attachment directory could not be resolved.'
            );
        }

        /*
         * Cryptographically random storage filename.
         *
         * The user's original filename is NEVER used here.
         */
        $storedName =
            bin2hex(
                random_bytes(32)
            ) .
            '.' .
            $attachment['extension'];

        $storedPath =
            $realStorageDirectory .
            DIRECTORY_SEPARATOR .
            $storedName;

        /*
         * Confirm the generated path stays inside
         * the attachment directory.
         */
        $parentDirectory = dirname(
            $storedPath
        );

        if (
            $parentDirectory !==
            $realStorageDirectory
        ) {
            throw new RuntimeException(
                'Invalid attachment storage path.'
            );
        }

        /*
         * Prevent accidental overwrite.
         */
        if (file_exists($storedPath)) {
            throw new RuntimeException(
                'Attachment storage collision.'
            );
        }

        /*
         * Move the validated upload.
         */
        if (!move_uploaded_file(
            $attachment['tmp_name'],
            $storedPath
        )) {
            throw new RuntimeException(
                'Could not save attachment.'
            );
        }

        /*
         * Restrict permissions on the stored file.
         *
         * The PHP process can still read it through the
         * secure attachment endpoint.
         */
        @chmod(
            $storedPath,
            0640
        );

        /*
         * Verify the moved file is still the expected
         * physical file.
         */
        if (
            !is_file($storedPath) ||
            !is_readable($storedPath)
        ) {
            throw new RuntimeException(
                'Stored attachment could not be verified.'
            );
        }

        /*
         * Store a relative application path in the DB.
         */
        $databasePath =
            'storage/uploads/support/' .
            $storedName;

        $attachmentQuery = $pdo->prepare('
            INSERT INTO support_ticket_attachments (
                ticket_id,
                message_id,
                uploaded_by_user_id,
                original_name,
                stored_name,
                file_path,
                mime_type,
                file_size
            ) VALUES (
                :ticket_id,
                :message_id,
                :uploaded_by_user_id,
                :original_name,
                :stored_name,
                :file_path,
                :mime_type,
                :file_size
            )
        ');

        $attachmentQuery->execute([
            'ticket_id' => $ticketId,
            'message_id' => $messageId,
            'uploaded_by_user_id' => $userId,
            'original_name' => $attachment['original_name'],
            'stored_name' => $storedName,
            'file_path' => $databasePath,
            'mime_type' => $attachment['mime_type'],
            'file_size' => $attachment['file_size'],
        ]);
    }

    /*
     * Update ticket activity timestamp.
     */
    $updateTicket = $pdo->prepare('
        UPDATE support_tickets
        SET updated_at = CURRENT_TIMESTAMP
        WHERE id = :ticket_id
    ');

    $updateTicket->execute([
        'ticket_id' => $ticketId,
    ]);

    /*
     * Commit message + attachment metadata together.
     */
    $pdo->commit();

    respond([
        'message' => 'Reply submitted successfully.',
        'ticketId' => $ticketId,
        'messageId' => $messageId,
        'attachment' => $attachment !== null,
    ], 201);

} catch (Throwable $exception) {

    /*
     * Roll back the database changes.
     */
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
     * If the physical file was already moved but the
     * database transaction failed, remove the orphan.
     */
    if (
        $storedPath !== null &&
        is_file($storedPath)
    ) {
        @unlink($storedPath);
    }

    respond([
        'error' => 'Reply could not be submitted.',
    ], 500);
}