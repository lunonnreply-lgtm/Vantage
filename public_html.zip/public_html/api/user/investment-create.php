<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$userId = require_auth();
require_post();
require_csrf();

$input = json_input();

$planId = filter_var(
    $input['planId'] ?? null,
    FILTER_VALIDATE_INT
);

$accountId = filter_var(
    $input['accountId'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$planId || !$accountId) {
    respond([
        'error' => 'Select a valid investment plan and wallet.'
    ], 422);
}

$amount = amount_from_input($input['amount'] ?? null);

try {
    $pdo->beginTransaction();

    /*
     * Get the selected USD investment plan.
     */
    $planQuery = $pdo->prepare(
        "SELECT
            id,
            name,
            currency,
            minimum_amount,
            maximum_amount,
            return_rate,
            term_days,
            capital_back
         FROM investment_plans
         WHERE id = :id
           AND currency = 'USD'
           AND status = 'active'
         FOR UPDATE"
    );

    $planQuery->execute([
        'id' => $planId
    ]);

    $plan = $planQuery->fetch();

    if (!$plan) {
        $pdo->rollBack();

        respond([
            'error' => 'The selected investment plan is not available.'
        ], 422);
    }

    $amountFloat = (float) $amount;
    $minimum = (float) $plan['minimum_amount'];

    $maximum = $plan['maximum_amount'] === null
        ? null
        : (float) $plan['maximum_amount'];

    if ($amountFloat < $minimum) {
        $pdo->rollBack();

        respond([
            'error' => 'The investment amount is below the minimum for this plan.'
        ], 422);
    }

    if ($maximum !== null && $amountFloat > $maximum) {
        $pdo->rollBack();

        respond([
            'error' => 'The investment amount is above the maximum for this plan.'
        ], 422);
    }

    /*
     * Get the user's actual USD main wallet.
     */
    $walletQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            currency,
            wallet_type,
            available_balance
         FROM accounts
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
         FOR UPDATE"
    );

    $walletQuery->execute([
        'account_id' => $accountId,
        'user_id' => $userId
    ]);

    $sourceAccount = $walletQuery->fetch();

    if (!$sourceAccount) {
        $pdo->rollBack();

        respond([
            'error' => 'The selected USD wallet does not exist.'
        ], 422);
    }

    $availableBalance = (float) $sourceAccount['available_balance'];

    if ($availableBalance < $amountFloat) {
        $pdo->rollBack();

        respond([
            'error' => 'Insufficient funds in your USD wallet.'
        ], 422);
    }

    /*
     * Get the user's actual USD profit wallet.
     */
    $profitQuery = $pdo->prepare(
        "SELECT
            id
         FROM accounts
         WHERE user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'profit'
         FOR UPDATE"
    );

    $profitQuery->execute([
        'user_id' => $userId
    ]);

    $profitAccountId = $profitQuery->fetchColumn();

    if (!$profitAccountId) {
        $pdo->rollBack();

        respond([
            'error' => 'Your USD profit wallet is not configured.'
        ], 409);
    }

    /*
     * Calculate expected return.
     * return_rate is the daily percentage.
     */
    $returnRate = (float) $plan['return_rate'];
    $termDays = (int) $plan['term_days'];

    $expectedReturn = round(
        $amountFloat * ($returnRate / 100) * $termDays,
        2
    );

    $now = new DateTimeImmutable('now');

    $maturesAt = $now->modify(
        '+' . $termDays . ' days'
    );

    $reference = 'INV-' . strtoupper(
        bin2hex(random_bytes(8))
    );

    /*
     * Debit the USD main wallet.
     *
     * IMPORTANT:
     * Use different parameter names for the two
     * occurrences of the amount.
     */
    $debit = $pdo->prepare(
        "UPDATE accounts
         SET available_balance = available_balance - :debit_amount
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = 'USD'
           AND wallet_type = 'main'
           AND available_balance >= :required_amount"
    );

    $debit->execute([
        'debit_amount' => $amount,
        'account_id' => $accountId,
        'user_id' => $userId,
        'required_amount' => $amount
    ]);

    if ($debit->rowCount() !== 1) {
        $pdo->rollBack();

        respond([
            'error' => 'The wallet balance changed. Please try again.'
        ], 409);
    }

    /*
     * Create the investment.
     */
    $investmentInsert = $pdo->prepare(
        "INSERT INTO investments (
            user_id,
            plan_id,
            source_account_id,
            profit_account_id,
            principal,
            expected_return,
            currency,
            starts_at,
            matures_at,
            status,
            reference
        ) VALUES (
            :user_id,
            :plan_id,
            :source_account_id,
            :profit_account_id,
            :principal,
            :expected_return,
            'USD',
            :starts_at,
            :matures_at,
            'active',
            :reference
        )"
    );

    $investmentInsert->execute([
        'user_id' => $userId,
        'plan_id' => $planId,
        'source_account_id' => $accountId,
        'profit_account_id' => $profitAccountId,
        'principal' => $amount,
        'expected_return' => number_format(
            $expectedReturn,
            2,
            '.',
            ''
        ),
        'starts_at' => $now->format('Y-m-d H:i:s'),
        'matures_at' => $maturesAt->format('Y-m-d H:i:s'),
        'reference' => $reference
    ]);

    /*
     * Record the wallet debit in the ledger.
     */
    $ledgerInsert = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
        ) VALUES (
            :user_id,
            :account_id,
            'investment',
            :amount,
            'USD',
            'completed',
            :description
        )"
    );

    $ledgerInsert->execute([
        'user_id' => $userId,
        'account_id' => $accountId,
        'amount' => '-' . $amount,
        'description' => 'Investment created ' . $reference
    ]);

    $pdo->commit();

    respond([
        'message' => 'Investment created successfully.',
        'reference' => $reference,
        'currency' => 'USD',
        'principal' => number_format(
            $amountFloat,
            2,
            '.',
            ''
        ),
        'expectedReturn' => number_format(
            $expectedReturn,
            2,
            '.',
            ''
        ),
        'maturesAt' => $maturesAt->format(DATE_ATOM)
    ], 201);

} catch (Throwable $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    respond([
        'error' => 'The investment could not be created. Please try again.'
    ], 500);
}