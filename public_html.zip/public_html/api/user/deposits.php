<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require __DIR__ . '/../../backend/src/helpers.php';
require_once __DIR__ . '/../../backend/src/notifications.php';

$userId = require_auth();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $action = isset($_GET['action']) && is_string($_GET['action'])
        ? trim($_GET['action'])
        : '';

    if ($action === 'methods') {
        $query = $pdo->prepare(
            'SELECT
                id,
                code,
                name,
                wallet_address,
                qr_code,
                charge,
                charge_type,
                minimum_deposit,
                maximum_deposit,
                currency
             FROM payment_methods
             WHERE status = "active"
             ORDER BY id ASC'
        );

        $query->execute();

        respond([
            'payment_methods' => $query->fetchAll(),
        ]);
    }

    $query = $pdo->prepare(
        'SELECT
            fr.reference,
            fr.amount,
            fr.fee,
            fr.currency,
            fr.gateway,
            fr.status,
            fr.notes,
            fr.screenshot_path,
            fr.created_at,
            pm.name AS payment_method
         FROM financial_requests fr
         LEFT JOIN payment_methods pm
            ON pm.id = fr.payment_method_id
         WHERE fr.user_id = :user_id
           AND fr.type = "deposit"
         ORDER BY fr.created_at DESC'
    );

    $query->execute([
        'user_id' => $userId,
    ]);

    respond([
        'deposits' => $query->fetchAll(),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'error' => 'Method not allowed.',
    ], 405);
}

require_csrf();

$paymentMethodCode = request_string('payment_method', 60);

if ($paymentMethodCode === '') {
    respond([
        'error' => 'Please select a payment method.',
    ], 422);
}

$amount = amount_from_input($_POST['amount'] ?? null);

if ($amount <= 0) {
    respond([
        'error' => 'Please enter a valid deposit amount.',
    ], 422);
}

$methodQuery = $pdo->prepare(
    'SELECT
        id,
        code,
        name,
        wallet_address,
        qr_code,
        charge,
        charge_type,
        minimum_deposit,
        maximum_deposit,
        currency
     FROM payment_methods
     WHERE code = :code
       AND status = "active"
     LIMIT 1'
);

$methodQuery->execute([
    'code' => $paymentMethodCode,
]);

$paymentMethod = $methodQuery->fetch();

if (!$paymentMethod) {
    respond([
        'error' => 'The selected payment method is not available.',
    ], 422);
}

$minimumDeposit = (float) $paymentMethod['minimum_deposit'];
$maximumDeposit = (float) $paymentMethod['maximum_deposit'];

if ($amount < $minimumDeposit) {
    respond([
        'error' => 'Minimum deposit is ' .
            number_format($minimumDeposit, 2) . ' ' .
            $paymentMethod['currency'] . '.',
    ], 422);
}

if ($amount > $maximumDeposit) {
    respond([
        'error' => 'Maximum deposit is ' .
            number_format($maximumDeposit, 2) . ' ' .
            $paymentMethod['currency'] . '.',
    ], 422);
}

$fee = (float) $paymentMethod['charge'];

if ($paymentMethod['charge_type'] === 'percentage') {
    $fee = ($amount * $fee) / 100;
}

$fee = round($fee, 2);

$accountQuery = $pdo->prepare(
    'SELECT id
     FROM accounts
     WHERE user_id = :user_id
       AND currency = :currency
       AND wallet_type = "main"
     LIMIT 1'
);

$accountQuery->execute([
    'user_id' => $userId,
    'currency' => $paymentMethod['currency'],
]);

$account = $accountQuery->fetch();

if (!$account) {
    respond([
        'error' => 'Your ' . $paymentMethod['currency'] . ' wallet is not configured.',
    ], 404);
}

if (
    !isset($_FILES['screenshot']) ||
    !is_array($_FILES['screenshot']) ||
    !isset($_FILES['screenshot']['error'])
) {
    respond([
        'error' => 'Payment screenshot is required.',
    ], 422);
}

if ((int) $_FILES['screenshot']['error'] !== UPLOAD_ERR_OK) {
    respond([
        'error' => 'Unable to upload the payment screenshot.',
    ], 422);
}

$fileSize = isset($_FILES['screenshot']['size'])
    ? (int) $_FILES['screenshot']['size']
    : 0;

if ($fileSize <= 0) {
    respond([
        'error' => 'The uploaded screenshot is empty.',
    ], 422);
}

if ($fileSize > 5 * 1024 * 1024) {
    respond([
        'error' => 'Payment screenshot must not exceed 5MB.',
    ], 422);
}

$tmpName = isset($_FILES['screenshot']['tmp_name'])
    ? (string) $_FILES['screenshot']['tmp_name']
    : '';

if ($tmpName === '' || !is_uploaded_file($tmpName)) {
    respond([
        'error' => 'Invalid payment screenshot upload.',
    ], 422);
}

$finfo = new finfo(FILEINFO_MIME_TYPE);
$mimeType = $finfo->file($tmpName);

$allowedMimeTypes = [
    'image/jpeg' => 'jpg',
    'image/png' => 'png',
    'image/webp' => 'webp',
];

if (!isset($allowedMimeTypes[$mimeType])) {
    respond([
        'error' => 'Screenshot must be a JPG, PNG, or WEBP image.',
    ], 422);
}

$uploadDirectory = __DIR__ . '/../../uploads/deposits';

if (!is_dir($uploadDirectory)) {
    if (!mkdir($uploadDirectory, 0755, true) && !is_dir($uploadDirectory)) {
        respond([
            'error' => 'Unable to prepare screenshot storage.',
        ], 500);
    }
}

$reference = strtoupper(bin2hex(random_bytes(8)));

$fileName = $reference . '-' .
    bin2hex(random_bytes(8)) . '.' .
    $allowedMimeTypes[$mimeType];

$targetPath = $uploadDirectory . '/' . $fileName;

if (!move_uploaded_file($tmpName, $targetPath)) {
    respond([
        'error' => 'Unable to save the payment screenshot.',
    ], 500);
}

$screenshotPath = '/uploads/deposits/' . $fileName;

$notes = request_string('notes', 500);

$insert = $pdo->prepare(
    'INSERT INTO financial_requests (
        user_id,
        account_id,
        type,
        amount,
        fee,
        currency,
        gateway,
        payment_method_id,
        status,
        reference,
        notes,
        screenshot_path
     )
     VALUES (
        :user_id,
        :account_id,
        "deposit",
        :amount,
        :fee,
        :currency,
        :gateway,
        :payment_method_id,
        "pending",
        :reference,
        :notes,
        :screenshot_path
     )'
);

try {
    $insert->execute([
        'user_id' => $userId,
        'account_id' => $account['id'],
        'amount' => number_format((float) $amount, 2, '.', ''),
        'fee' => number_format((float) $fee, 2, '.', ''),
        
        
        'currency' => $paymentMethod['currency'],
        'gateway' => $paymentMethod['name'],
        'payment_method_id' => $paymentMethod['id'],
        'reference' => $reference,
        'notes' => $notes !== '' ? $notes : null,
        'screenshot_path' => $screenshotPath,
    ]);
    
    
    
    
    
    
    } catch (Throwable $e) {
    if (is_file($targetPath)) {
        unlink($targetPath);
    }

    respond([
        'error' => 'Database error: ' . $e->getMessage(),
    ], 500);
}

notify_admins_of_event(
    $pdo,
    $config,
    $userId,
    'New deposit request placed',
    'A user has submitted a deposit request for review.',
    [
        'Reference' => $reference,
        'Amount' => number_format((float)$amount, 2, '.', '') . ' ' . (string)$paymentMethod['currency'],
        'Payment method' => (string)$paymentMethod['name'],
    ]
);
    
    
    
    
 

$total = round($amount + $fee, 2);

respond([
    'message' => 'Your deposit request was submitted for review.',
    'reference' => $reference,
    'status' => 'pending',
    number_format((float) $amount, 2, '.', ''),
    'fee' => number_format($fee, 2, '.', ''),
    'total' => number_format($total, 2, '.', ''),
    'currency' => $paymentMethod['currency'],
    'payment_method' => $paymentMethod['name'],
], 201);
