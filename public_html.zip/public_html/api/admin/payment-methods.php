<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

require_admin();

/*
 * GET
 */
if ($_SERVER['REQUEST_METHOD'] === 'GET') {

    $q = $pdo->query(
        "SELECT
            id,
            code,
            name,
            wallet_address,
            qr_code,
            charge,
            charge_type,
            minimum_deposit,
            maximum_deposit,
            currency,
            status,
            created_at,
            updated_at
         FROM payment_methods
         ORDER BY name ASC, id ASC"
    );

    respond([
        'paymentMethods' => $q->fetchAll()
    ]);
}


/*
 * Only POST is allowed below.
 */
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'error' => 'Method not allowed.'
    ], 405);
}

require_csrf();


/*
 * Determine whether this is an action request
 * such as toggle/delete.
 *
 * The normal create/edit request uses
 * multipart/form-data because it can contain
 * an uploaded QR image.
 */
$contentType = strtolower(
    (string)($_SERVER['CONTENT_TYPE'] ?? '')
);

$isMultipart = str_contains(
    $contentType,
    'multipart/form-data'
);


/*
 * Read request data.
 */
if ($isMultipart) {

    $b = $_POST;

} else {

    $b = json_decode(
        (string)file_get_contents('php://input'),
        true
    ) ?: [];

}


$action = (string)($b['action'] ?? '');

$id = filter_var(
    $b['id'] ?? null,
    FILTER_VALIDATE_INT
);


/*
 * TOGGLE STATUS
 */
if ($action === 'toggle') {

    if (!$id) {
        respond([
            'error' => 'Invalid payment method.'
        ], 422);
    }

    $s = $pdo->prepare(
        "UPDATE payment_methods
         SET status = CASE
             WHEN status = 'active'
             THEN 'inactive'
             ELSE 'active'
         END
         WHERE id = :id"
    );

    $s->execute([
        'id' => $id
    ]);

    if ($s->rowCount() !== 1) {
        respond([
            'error' => 'Payment method not found.'
        ], 404);
    }

    respond([
        'message' => 'Payment method status updated.'
    ]);
}


/*
 * DELETE
 */
if ($action === 'delete') {

    if (!$id) {
        respond([
            'error' => 'Invalid payment method.'
        ], 422);
    }

    /*
     * Get the existing QR path first so that
     * the physical file can be removed after
     * successful database deletion.
     */
    $existingQuery = $pdo->prepare(
        "SELECT qr_code
         FROM payment_methods
         WHERE id = :id
         LIMIT 1"
    );

    $existingQuery->execute([
        'id' => $id
    ]);

    $existingQr = $existingQuery->fetchColumn();

    try {

        $s = $pdo->prepare(
            'DELETE FROM payment_methods
             WHERE id = :id'
        );

        $s->execute([
            'id' => $id
        ]);

    } catch (Throwable $e) {

        respond([
            'error' =>
                'This payment method is referenced by existing financial requests. Deactivate it instead.'
        ], 409);
    }

    if ($s->rowCount() !== 1) {
        respond([
            'error' => 'Payment method not found.'
        ], 404);
    }

    /*
     * Remove the old QR image after the database
     * record has been successfully deleted.
     */
    if (
        is_string($existingQr) &&
        $existingQr !== ''
    ) {

        $storageDir = realpath(
            __DIR__ . '/../../storage/uploads/payment-methods/qr'
        );

        if ($storageDir !== false) {

            $relativeQr = ltrim(
                $existingQr,
                '/'
            );

            if (
                str_starts_with(
                    $relativeQr,
                    'storage/uploads/payment-methods/qr/'
                )
            ) {

                $fileName = basename($relativeQr);

                $filePath = $storageDir .
                    DIRECTORY_SEPARATOR .
                    $fileName;

                if (
                    is_file($filePath) &&
                    is_writable($filePath)
                ) {
                    @unlink($filePath);
                }
            }
        }
    }

    respond([
        'message' => 'Payment method deleted.'
    ]);
}


/*
 * CREATE / UPDATE
 */

$code = trim(
    (string)($b['code'] ?? '')
);

$name = trim(
    (string)($b['name'] ?? '')
);

$currency = strtoupper(
    trim((string)($b['currency'] ?? ''))
);

if (
    $code === '' ||
    $name === '' ||
    !preg_match(
        '/^[A-Z0-9_-]{1,60}$/',
        $code
    ) ||
    !preg_match(
        '/^[A-Z]{3}$/',
        $currency
    )
) {

    respond([
        'error' => 'Invalid code, name, or currency.'
    ], 422);
}


$ct = (string)(
    $b['charge_type'] ?? 'fixed'
);

$status = (string)(
    $b['status'] ?? 'active'
);

if (
    !in_array(
        $ct,
        ['fixed', 'percentage'],
        true
    ) ||
    !in_array(
        $status,
        ['active', 'inactive'],
        true
    )
) {

    respond([
        'error' => 'Invalid payment method option.'
    ], 422);
}


/*
 * Get the existing QR image when editing.
 *
 * This allows us to keep the old QR image if
 * the administrator edits the payment method
 * without selecting a replacement image.
 */
$existingQr = null;

if ($id) {

    $existingQuery = $pdo->prepare(
        "SELECT qr_code
         FROM payment_methods
         WHERE id = :id
         LIMIT 1"
    );

    $existingQuery->execute([
        'id' => $id
    ]);

    $existingQr = $existingQuery->fetchColumn();

    if ($existingQr === false) {
        respond([
            'error' => 'Payment method not found.'
        ], 404);
    }

    $existingQr = $existingQr !== null
        ? (string)$existingQr
        : null;
}


/*
 * QR IMAGE UPLOAD
 */

$qrPath = $existingQr;


/*
 * Only process an upload when a new file
 * was actually selected.
 */
$hasQrUpload = isset(
    $_FILES['qr_code']
) && (
    (int)($_FILES['qr_code']['error'] ?? UPLOAD_ERR_NO_FILE)
    !== UPLOAD_ERR_NO_FILE
);


if ($hasQrUpload) {

    $upload = $_FILES['qr_code'];

    $uploadError = (int)(
        $upload['error'] ?? UPLOAD_ERR_NO_FILE
    );

    if ($uploadError !== UPLOAD_ERR_OK) {

        respond([
            'error' => 'The QR code image could not be uploaded.'
        ], 422);
    }


    /*
     * Maximum 5 MB.
     */
    $maxFileSize = 5 * 1024 * 1024;

    $fileSize = (int)(
        $upload['size'] ?? 0
    );

    if (
        $fileSize <= 0 ||
        $fileSize > $maxFileSize
    ) {

        respond([
            'error' =>
                'The QR code image must be between 1 byte and 5 MB.'
        ], 422);
    }


    /*
     * Make sure PHP reports an actual uploaded file.
     */
    $tmpName = (string)(
        $upload['tmp_name'] ?? ''
    );

    if (
        $tmpName === '' ||
        !is_uploaded_file($tmpName)
    ) {

        respond([
            'error' => 'Invalid QR code upload.'
        ], 422);
    }


    /*
     * Detect the actual MIME type.
     *
     * Do NOT trust the browser-provided MIME type.
     */
    $finfo = new finfo(
        FILEINFO_MIME_TYPE
    );

    $mime = $finfo->file(
        $tmpName
    );


    $allowedMimeTypes = [
        'image/jpeg' => 'jpg',
        'image/png'  => 'png',
        'image/webp' => 'webp',
    ];


    if (
        !is_string($mime) ||
        !isset($allowedMimeTypes[$mime])
    ) {

        respond([
            'error' =>
                'QR code must be a JPG, PNG, or WEBP image.'
        ], 422);
    }


    /*
     * Confirm that PHP can actually decode the image.
     */
    $imageInfo = @getimagesize(
        $tmpName
    );

    if (
        $imageInfo === false
    ) {

        respond([
            'error' => 'The uploaded QR code is not a valid image.'
        ], 422);
    }


    $width = (int)(
        $imageInfo[0] ?? 0
    );

    $height = (int)(
        $imageInfo[1] ?? 0
    );


    /*
     * Prevent extremely large images.
     */
    if (
        $width <= 0 ||
        $height <= 0 ||
        $width > 10000 ||
        $height > 10000
    ) {

        respond([
            'error' =>
                'The QR code image dimensions are not allowed.'
        ], 422);
    }


    /*
     * Storage directory.
     */
    $storageDir = __DIR__ .
        '/../../storage/uploads/payment-methods/qr';


    if (!is_dir($storageDir)) {

        if (!mkdir(
            $storageDir,
            0755,
            true
        )) {

            respond([
                'error' =>
                    'The QR code storage directory could not be created.'
            ], 500);
        }
    }


    if (!is_writable($storageDir)) {

        respond([
            'error' =>
                'The QR code storage directory is not writable.'
        ], 500);
    }


    /*
     * Generate a completely random server-side
     * filename.
     *
     * Never use the original filename.
     */
    try {

        $randomName = bin2hex(
            random_bytes(32)
        );

    } catch (Throwable $e) {

        respond([
            'error' =>
                'Could not generate a secure QR code filename.'
        ], 500);
    }


    $extension =
        $allowedMimeTypes[$mime];

    $storedName =
        $randomName . '.' . $extension;

    $destination =
        $storageDir .
        DIRECTORY_SEPARATOR .
        $storedName;


    /*
     * Move uploaded image.
     */
    if (!move_uploaded_file(
        $tmpName,
        $destination
    )) {

        respond([
            'error' =>
                'The QR code image could not be saved.'
        ], 500);
    }


    /*
     * Restrict permissions.
     */
    @chmod(
        $destination,
        0644
    );


    /*
     * Path stored in database.
     *
     * This is the web path used by the deposit
     * page's <img src="">.
     */
    $qrPath =
        '/storage/uploads/payment-methods/qr/' .
        $storedName;
}


/*
 * Prepare payment method data.
 */
$d = [
    'code' => $code,

    'name' => $name,

    'wallet_address' =>
        trim(
            (string)($b['wallet_address'] ?? '')
        ) ?: null,

    'qr_code' => $qrPath,

    'charge' =>
        (float)($b['charge'] ?? 0),

    'charge_type' => $ct,

    'minimum_deposit' =>
        (float)($b['minimum_deposit'] ?? 0),

    'maximum_deposit' =>
        (float)($b['maximum_deposit'] ?? 999999.99),

    'currency' => $currency,

    'status' => $status,
];


$newQrPath = null;


/*
 * If a new image was uploaded, remember its path
 * so we can clean it up if the database operation
 * fails.
 */
if ($hasQrUpload) {
    $newQrPath = $qrPath;
}


try {

    if ($id) {

        $d['id'] = $id;

        $s = $pdo->prepare(
            "UPDATE payment_methods
             SET
                code = :code,
                name = :name,
                wallet_address = :wallet_address,
                qr_code = :qr_code,
                charge = :charge,
                charge_type = :charge_type,
                minimum_deposit = :minimum_deposit,
                maximum_deposit = :maximum_deposit,
                currency = :currency,
                status = :status
             WHERE id = :id"
        );

        $s->execute($d);

    } else {

        $s = $pdo->prepare(
            "INSERT INTO payment_methods (
                code,
                name,
                wallet_address,
                qr_code,
                charge,
                charge_type,
                minimum_deposit,
                maximum_deposit,
                currency,
                status
             ) VALUES (
                :code,
                :name,
                :wallet_address,
                :qr_code,
                :charge,
                :charge_type,
                :minimum_deposit,
                :maximum_deposit,
                :currency,
                :status
             )"
        );

        $s->execute($d);

        $id = (int)$pdo->lastInsertId();
    }

} catch (Throwable $e) {

    /*
     * Remove newly uploaded image if the database
     * save failed.
     */
    if (
        $newQrPath !== null &&
        $newQrPath !== ''
    ) {

        $storageDir = realpath(
            __DIR__ . '/../../storage/uploads/payment-methods/qr'
        );

        if ($storageDir !== false) {

            $fileName = basename(
                $newQrPath
            );

            $filePath =
                $storageDir .
                DIRECTORY_SEPARATOR .
                $fileName;

            if (is_file($filePath)) {
                @unlink($filePath);
            }
        }
    }

    respond([
        'error' =>
            'Could not save payment method. The code may already exist or the values may be invalid.'
    ], 409);
}


/*
 * If this was an edit with a new QR image,
 * delete the previous image after the database
 * update succeeded.
 */
if (
    $id &&
    $hasQrUpload &&
    $existingQr !== null &&
    $existingQr !== '' &&
    $existingQr !== $qrPath
) {

    $storageDir = realpath(
        __DIR__ . '/../../storage/uploads/payment-methods/qr'
    );

    if ($storageDir !== false) {

        $relativeOldQr = ltrim(
            $existingQr,
            '/'
        );

        if (
            str_starts_with(
                $relativeOldQr,
                'storage/uploads/payment-methods/qr/'
            )
        ) {

            $oldFileName = basename(
                $relativeOldQr
            );

            $oldFilePath =
                $storageDir .
                DIRECTORY_SEPARATOR .
                $oldFileName;

            if (
                is_file($oldFilePath) &&
                is_writable($oldFilePath)
            ) {
                @unlink($oldFilePath);
            }
        }
    }
}


respond([
    'message' => 'Payment method saved.',
    'id' => $id
]);