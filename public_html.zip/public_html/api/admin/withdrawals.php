<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_once __DIR__ . '/../../backend/src/notifications.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = $pdo->query(
        "SELECT
            fr.id,
            fr.user_id,
            fr.account_id,
            fr.amount,
            fr.fee,
            fr.currency,
            fr.gateway,
            fr.payment_method_id,
            fr.withdrawal_account_id,
            fr.status,
            fr.reference,
            fr.notes,
            fr.screenshot_path,
            fr.created_at,
            fr.updated_at,
            u.first_name,
            u.last_name,
            u.email,
            wa.method AS payment_name,
            wa.account_name,
            wa.account_number,
            wa.bank_name,
            wa.bank_code,
            wa.wallet_address,
            wa.network
         FROM financial_requests fr
         JOIN users u ON u.id = fr.user_id
         LEFT JOIN withdrawal_accounts wa
                ON wa.id = fr.withdrawal_account_id
         WHERE fr.type = 'withdrawal'
         ORDER BY fr.created_at DESC, fr.id DESC"
    );

    respond([
        'requests' => $q->fetchAll()
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'error' => 'Method not allowed.'
    ], 405);
}

require_csrf();

$isJson = str_contains(
    strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? '')),
    'application/json'
);

$body = $isJson
    ? (json_decode((string) file_get_contents('php://input'), true) ?: [])
    : $_POST;

$id = filter_var(
    $body['requestId'] ?? null,
    FILTER_VALIDATE_INT
);

$action = (string) ($body['action'] ?? '');

if (
    !$id ||
    !in_array($action, ['approved', 'rejected'], true)
) {
    respond([
        'error' => 'Invalid request.'
    ], 422);
}

try {
    $pdo->beginTransaction();

    /*
     * Lock the withdrawal row.
     *
     * This prevents two admins from approving/rejecting
     * the same pending withdrawal simultaneously.
     */
    $requestQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            account_id,
            amount,
            fee,
            currency,
            reference,
            status
         FROM financial_requests
         WHERE id = :id
           AND type = 'withdrawal'
         LIMIT 1
         FOR UPDATE"
    );

    $requestQuery->execute([
        ':id' => $id
    ]);

    $request = $requestQuery->fetch();

    if (!$request) {
        throw new RuntimeException(
            'Withdrawal not found.'
        );
    }

    /*
     * Only pending withdrawals can be processed.
     */
    if ((string) $request['status'] !== 'pending') {
        throw new RuntimeException(
            'Withdrawal not found or no longer pending.'
        );
    }

    $userId = (int) $request['user_id'];
    $accountId = (int) $request['account_id'];
    $amount = round((float) $request['amount'], 2);
    $fee = round((float) $request['fee'], 2);
    $totalRefund = round($amount + $fee, 2);
    $currency = strtoupper((string) $request['currency']);
    $reference = (string) $request['reference'];

    /*
     * APPROVE
     *
     * The withdrawal amount and fee were already deducted
     * when the withdrawal was created.
     *
     * Therefore approval does not change the balance here.
     */
    if ($action === 'approved') {

        $update = $pdo->prepare(
            "UPDATE financial_requests
             SET status = 'approved',
                 updated_at = CURRENT_TIMESTAMP
             WHERE id = :id
               AND status = 'pending'"
        );

        $update->execute([
            ':id' => $id
        ]);

        if ($update->rowCount() !== 1) {
            throw new RuntimeException(
                'Withdrawal could not be approved.'
            );
        }

        $pdo->commit();

        notify_user_of_event(
            $pdo,
            $config,
            $userId,
            'Withdrawal request approved',
            'Your withdrawal request was approved.',
            [
                'Reference' => $reference,
                'Amount' => number_format(
                    $amount,
                    2,
                    '.',
                    ''
                ) . ' ' . $currency,
                'Status' => 'Approved'
            ]
        );

        if (!$isJson) {
            header(
                'Location: ' .
                ((string) (
                    $body['_admin_redirect']
                    ?? '/admin/withdrawals/'
                ))
            );
            exit;
        }

        respond([
            'message' => 'Withdrawal approved.',
            'requestId' => $id,
            'status' => 'approved'
        ]);
    }

    /*
     * REJECT
     *
     * The original withdrawal already deducted:
     *
     * amount + fee
     *
     * from accounts.available_balance.
     *
     * Restore the exact same total here.
     */

    /*
     * Lock the user's account before refunding it.
     */
    $accountQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            currency,
            wallet_type,
            available_balance
         FROM accounts
         WHERE id = :account_id
           AND user_id = :user_id
           AND currency = :currency
           AND wallet_type = 'main'
         LIMIT 1
         FOR UPDATE"
    );

    $accountQuery->execute([
        ':account_id' => $accountId,
        ':user_id' => $userId,
        ':currency' => $currency
    ]);

    $account = $accountQuery->fetch();

    if (!$account) {
        throw new RuntimeException(
            'The user main account could not be found.'
        );
    }

    $currentBalance = round(
        (float) $account['available_balance'],
        2
    );

    $refundedBalance = round(
        $currentBalance + $totalRefund,
        2
    );

    /*
     * Restore amount + fee.
     */
    $balanceUpdate = $pdo->prepare(
        "UPDATE accounts
         SET available_balance = :available_balance,
             updated_at = CURRENT_TIMESTAMP
         WHERE id = :account_id
           AND user_id = :user_id"
    );

    $balanceUpdate->execute([
        ':available_balance' => number_format(
            $refundedBalance,
            2,
            '.',
            ''
        ),
        ':account_id' => $accountId,
        ':user_id' => $userId
    ]);

    if ($balanceUpdate->rowCount() !== 1) {
        throw new RuntimeException(
            'Unable to restore the user balance.'
        );
    }

    /*
     * Change the withdrawal to rejected.
     */
    $statusUpdate = $pdo->prepare(
        "UPDATE financial_requests
         SET status = 'rejected',
             updated_at = CURRENT_TIMESTAMP
         WHERE id = :id
           AND status = 'pending'"
    );

    $statusUpdate->execute([
        ':id' => $id
    ]);

    if ($statusUpdate->rowCount() !== 1) {
        throw new RuntimeException(
            'Withdrawal could not be rejected.'
        );
    }

    /*
     * Record a separate reversal/refund ledger transaction.
     *
     * Positive amount = money returned to the user's account.
     */
    $ledgerQuery = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
         ) VALUES (
            :user_id,
            :account_id,
            'withdrawal_refund',
            :amount,
            :currency,
            'completed',
            :description
         )"
    );

    $ledgerQuery->execute([
        ':user_id' => $userId,
        ':account_id' => $accountId,
        ':amount' => number_format(
            $totalRefund,
            2,
            '.',
            ''
        ),
        ':currency' => $currency,
        ':description' =>
            'Refund for rejected withdrawal ' . $reference
    ]);

    /*
     * Everything succeeded.
     */
    $pdo->commit();

    /*
     * Notify the user only after the transaction commits.
     */
    notify_user_of_event(
        $pdo,
        $config,
        $userId,
        'Withdrawal request rejected',
        'Your withdrawal request was rejected and the withdrawn funds were returned to your available balance.',
        [
            'Reference' => $reference,
            'Withdrawal amount' => number_format(
                $amount,
                2,
                '.',
                ''
            ) . ' ' . $currency,
            'Fee returned' => number_format(
                $fee,
                2,
                '.',
                ''
            ) . ' ' . $currency,
            'Total returned' => number_format(
                $totalRefund,
                2,
                '.',
                ''
            ) . ' ' . $currency,
            'Status' => 'Rejected'
        ]
    );

    if (!$isJson) {
        header(
            'Location: ' .
            ((string) (
                $body['_admin_redirect']
                ?? '/admin/withdrawals/'
            ))
        );
        exit;
    }

    respond([
        'message' => 'Withdrawal rejected and funds refunded.',
        'requestId' => $id,
        'status' => 'rejected',
        'refunded' => number_format(
            $totalRefund,
            2,
            '.',
            ''
        ),
        'currency' => $currency
    ]);

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        '[admin-withdrawal-action] ' . $e->getMessage()
    );

    if ($e instanceof RuntimeException) {
        $message = $e->getMessage();
    } else {
        $message =
            'Unable to process the withdrawal right now. Please try again.';
    }

    if (!$isJson) {
        header(
            'Location: /admin/withdrawals/?error=' .
            urlencode($message)
        );
        exit;
    }

    respond([
        'error' => $message
    ], 500);
}