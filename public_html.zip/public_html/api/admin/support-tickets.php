<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = $pdo->query("
        SELECT
            t.id,
            t.user_id,
            t.subject,
            t.category,
            t.status,
            t.created_at,
            t.updated_at,
            u.first_name,
            u.last_name,
            u.email
        FROM support_tickets t
        JOIN users u
            ON u.id = t.user_id
        ORDER BY t.updated_at DESC, t.id DESC
    ");

    respond([
        'tickets' => $q->fetchAll(),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'error' => 'Method not allowed.',
    ], 405);
}

require_csrf();

$isJson = str_contains(
    strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? '')),
    'application/json'
);

$body = $isJson
    ? (json_decode(
        (string) file_get_contents('php://input'),
        true
    ) ?: [])
    : $_POST;

$ticketId = filter_var(
    $body['ticketId'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$ticketId || $ticketId <= 0) {
    respond([
        'error' => 'Invalid ticket.',
    ], 422);
}

$status = array_key_exists('status', $body)
    ? (string) $body['status']
    : null;

$message = isset($body['message'])
    ? trim((string) $body['message'])
    : '';

$allowedStatuses = [
    'open',
    'in_progress',
    'resolved',
    'closed',
];

$hasAttachment =
    isset($_FILES['attachment']) &&
    is_array($_FILES['attachment']) &&
    (int) ($_FILES['attachment']['error'] ?? UPLOAD_ERR_NO_FILE)
        !== UPLOAD_ERR_NO_FILE;

$uploadedFilePath = null;

$pdo->beginTransaction();

try {

    /*
     * Lock the ticket while updating it.
     */
    $ticketQuery = $pdo->prepare("
        SELECT id
        FROM support_tickets
        WHERE id = :id
        FOR UPDATE
    ");

    $ticketQuery->execute([
        'id' => $ticketId,
    ]);

    if (!$ticketQuery->fetch()) {
        throw new RuntimeException(
            'Ticket not found.'
        );
    }

    /*
     * Validate status.
     */
    if ($status !== null) {

        if (!in_array(
            $status,
            $allowedStatuses,
            true
        )) {
            throw new RuntimeException(
                'Invalid status.'
            );
        }

        $statusQuery = $pdo->prepare("
            UPDATE support_tickets
            SET
                status = :status,
                updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
        ");

        $statusQuery->execute([
            'status' => $status,
            'id' => $ticketId,
        ]);
    }

    /*
     * Validate message.
     */
    if (strlen($message) > 5000) {
        throw new RuntimeException(
            'Reply is too long.'
        );
    }

    /*
     * If there is an attachment, a message is required
     * because attachments belong to messages.
     */
    if ($hasAttachment && $message === '') {
        throw new RuntimeException(
            'Write a reply before attaching a file.'
        );
    }

    /*
     * Nothing to update.
     */
    if (
        $status === null &&
        $message === '' &&
        !$hasAttachment
    ) {
        throw new RuntimeException(
            'Nothing to update.'
        );
    }

    /*
     * Create the message first.
     */
    $messageId = null;

    if ($message !== '') {

        $messageQuery = $pdo->prepare("
            INSERT INTO support_ticket_messages
                (
                    ticket_id,
                    author_user_id,
                    message
                )
            VALUES
                (
                    :ticket,
                    :author,
                    :message
                )
        ");

        $messageQuery->execute([
            'ticket' => $ticketId,
            'author' => (int) $_SESSION['user_id'],
            'message' => $message,
        ]);

        $messageId = (int) $pdo->lastInsertId();

        $updateTicket = $pdo->prepare("
            UPDATE support_tickets
            SET updated_at = CURRENT_TIMESTAMP
            WHERE id = :id
        ");

        $updateTicket->execute([
            'id' => $ticketId,
        ]);
    }

    /*
     * Hardened attachment upload.
     */
    if ($hasAttachment) {

        if ($messageId === null) {
            throw new RuntimeException(
                'Attachment requires a message.'
            );
        }

        $file = $_FILES['attachment'];

        if ((int) $file['error'] !== UPLOAD_ERR_OK) {
            throw new RuntimeException(
                'Attachment upload failed.'
            );
        }

        if (!is_uploaded_file(
            (string) $file['tmp_name']
        )) {
            throw new RuntimeException(
                'Invalid uploaded file.'
            );
        }

        if (!is_file((string) $file['tmp_name'])) {
            throw new RuntimeException(
                'Uploaded file was not found.'
            );
        }

        if (!is_readable((string) $file['tmp_name'])) {
            throw new RuntimeException(
                'Uploaded file cannot be read.'
            );
        }

        $fileSize = filesize(
            (string) $file['tmp_name']
        );

        if (
            $fileSize === false ||
            $fileSize <= 0
        ) {
            throw new RuntimeException(
                'Invalid attachment size.'
            );
        }

        if ($fileSize > 5 * 1024 * 1024) {
            throw new RuntimeException(
                'Attachment must be smaller than 5 MB.'
            );
        }

        /*
         * Detect the real MIME type from file contents.
         */
        $finfo = new finfo(FILEINFO_MIME_TYPE);

        $detectedMime = $finfo->file(
            (string) $file['tmp_name']
        );

        if (!is_string($detectedMime)) {
            throw new RuntimeException(
                'Could not determine attachment type.'
            );
        }

        $allowedMimeTypes = [
            'image/jpeg' => 'jpg',
            'image/png'  => 'png',
            'image/gif'  => 'gif',
            'image/webp' => 'webp',
        ];

        if (
            !array_key_exists(
                $detectedMime,
                $allowedMimeTypes
            )
        ) {
            throw new RuntimeException(
                'Only JPEG, PNG, GIF, and WEBP images are allowed.'
            );
        }

        /*
         * Verify that the file is actually an image.
         */
        $imageInfo = @getimagesize(
            (string) $file['tmp_name']
        );

        if ($imageInfo === false) {
            throw new RuntimeException(
                'Attachment is not a valid image.'
            );
        }

        $imageMime = isset($imageInfo['mime'])
            ? (string) $imageInfo['mime']
            : '';

        if ($imageMime !== $detectedMime) {
            throw new RuntimeException(
                'Attachment MIME type validation failed.'
            );
        }

        $width = isset($imageInfo[0])
            ? (int) $imageInfo[0]
            : 0;

        $height = isset($imageInfo[1])
            ? (int) $imageInfo[1]
            : 0;

        if (
            $width <= 0 ||
            $height <= 0 ||
            $width > 10000 ||
            $height > 10000
        ) {
            throw new RuntimeException(
                'Attachment dimensions are invalid.'
            );
        }

        /*
         * Sanitize the original filename.
         *
         * The filename is NEVER used as the stored filename.
         */
        $originalName = basename(
            (string) ($file['name'] ?? '')
        );

        $originalName = preg_replace(
            '/[\x00-\x1F\x7F]/',
            '',
            $originalName
        );

        if (!is_string($originalName)) {
            $originalName = '';
        }

        $originalName = trim($originalName);

        if ($originalName === '') {
            $originalName = 'attachment';
        }

        if (strlen($originalName) > 255) {
            $originalName = substr(
                $originalName,
                0,
                255
            );
        }

        /*
         * Use an extension derived ONLY from the
         * server-detected MIME type.
         */
        $extension =
            $allowedMimeTypes[$detectedMime];

        /*
         * Storage directory.
         */
        $storageDirectory = realpath(
            __DIR__ . '/../../storage/uploads/support'
        );

        if ($storageDirectory === false) {

            $storageDirectoryPath =
                __DIR__ .
                '/../../storage/uploads/support';

            if (!is_dir($storageDirectoryPath)) {

                if (!mkdir(
                    $storageDirectoryPath,
                    0755,
                    true
                )) {
                    throw new RuntimeException(
                        'Could not create attachment storage directory.'
                    );
                }
            }

            @chmod(
                $storageDirectoryPath,
                0755
            );

            $storageDirectory = realpath(
                $storageDirectoryPath
            );
        }

        if (
            $storageDirectory === false ||
            !is_dir($storageDirectory) ||
            !is_writable($storageDirectory)
        ) {
            throw new RuntimeException(
                'Attachment storage is not writable.'
            );
        }

        /*
         * Generate a random server-side filename.
         */
        $storedName =
            bin2hex(random_bytes(32)) .
            '.' .
            $extension;

        $destination =
            $storageDirectory .
            DIRECTORY_SEPARATOR .
            $storedName;

        /*
         * Final path safety check.
         */
        $parentDirectory = realpath(
            dirname($destination)
        );

        if (
            $parentDirectory === false ||
            $parentDirectory !== $storageDirectory
        ) {
            throw new RuntimeException(
                'Invalid attachment storage path.'
            );
        }

        if (file_exists($destination)) {
            throw new RuntimeException(
                'Attachment storage collision.'
            );
        }

        /*
         * Move the validated upload.
         */
        if (!move_uploaded_file(
            (string) $file['tmp_name'],
            $destination
        )) {
            throw new RuntimeException(
                'Could not store attachment.'
            );
        }

        $uploadedFilePath = $destination;

        /*
         * Restrictive file permissions.
         */
        @chmod(
            $destination,
            0640
        );

        if (
            !is_file($destination) ||
            !is_readable($destination)
        ) {
            throw new RuntimeException(
                'Stored attachment could not be verified.'
            );
        }

        /*
         * Store only the internal relative path.
         */
        $filePath =
            'storage/uploads/support/' .
            $storedName;

        $attachmentQuery = $pdo->prepare("
            INSERT INTO support_ticket_attachments
                (
                    ticket_id,
                    message_id,
                    uploaded_by_user_id,
                    original_name,
                    stored_name,
                    file_path,
                    mime_type,
                    file_size
                )
            VALUES
                (
                    :ticket_id,
                    :message_id,
                    :uploaded_by,
                    :original_name,
                    :stored_name,
                    :file_path,
                    :mime_type,
                    :file_size
                )
        ");

        $attachmentQuery->execute([
            'ticket_id' => $ticketId,
            'message_id' => $messageId,
            'uploaded_by' =>
                (int) $_SESSION['user_id'],
            'original_name' => $originalName,
            'stored_name' => $storedName,
            'file_path' => $filePath,
            'mime_type' => $detectedMime,
            'file_size' => $fileSize,
        ]);
    }

    $pdo->commit();

    /*
     * Normal browser form submission.
     */
    if (!$isJson) {

        header(
            'Location: ' .
            (
                (string) (
                    $body['_admin_redirect'] ??
                    '/admin/support/'
                )
            )
        );

        exit;
    }

    respond([
        'message' => 'Support ticket updated.',
        'ticketId' => $ticketId,
    ]);

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    /*
     * If the database transaction failed after the physical
     * file was moved, remove the orphaned file.
     */
    if (
        $uploadedFilePath !== null &&
        is_file($uploadedFilePath)
    ) {
        @unlink($uploadedFilePath);
    }

    respond([
        'error' => $e->getMessage(),
    ], 422);
}