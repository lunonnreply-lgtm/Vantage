<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] !== 'GET') {
    respond([
        'error' => 'Method not allowed.',
    ], 405);
}

$id = filter_var(
    $_GET['id'] ?? null,
    FILTER_VALIDATE_INT
);

if (!$id || $id <= 0) {
    respond([
        'error' => 'Invalid ticket.',
    ], 422);
}

/*
 * Ticket.
 */
$ticketQuery = $pdo->prepare("
    SELECT
        t.id,
        t.user_id,
        t.subject,
        t.category,
        t.status,
        t.created_at,
        t.updated_at,
        u.first_name,
        u.last_name,
        u.email,
        u.username
    FROM support_tickets t
    JOIN users u
        ON u.id = t.user_id
    WHERE t.id = :id
    LIMIT 1
");

$ticketQuery->execute([
    'id' => $id,
]);

$ticket = $ticketQuery->fetch();

if (!$ticket) {
    respond([
        'error' => 'Support ticket not found.',
    ], 404);
}

/*
 * Messages.
 */
$messageQuery = $pdo->prepare("
    SELECT
        m.id,
        m.ticket_id,
        m.author_user_id,
        m.message,
        m.created_at,
        u.first_name,
        u.last_name,
        u.email
    FROM support_ticket_messages m
    LEFT JOIN users u
        ON u.id = m.author_user_id
    WHERE m.ticket_id = :id
    ORDER BY m.created_at ASC, m.id ASC
");

$messageQuery->execute([
    'id' => $id,
]);

$messages = $messageQuery->fetchAll();

/*
 * Attachments.
 */
$attachmentQuery = $pdo->prepare("
    SELECT
        id,
        ticket_id,
        message_id,
        uploaded_by_user_id,
        original_name,
        mime_type,
        file_size,
        created_at
    FROM support_ticket_attachments
    WHERE ticket_id = :id
    ORDER BY id ASC
");

$attachmentQuery->execute([
    'id' => $id,
]);

$attachments = $attachmentQuery->fetchAll();

respond([
    'ticket' => $ticket,
    'messages' => $messages,
    'attachments' => $attachments,
]);