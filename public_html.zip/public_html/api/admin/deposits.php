<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_once __DIR__ . '/../../backend/src/notifications.php';

require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $q = $pdo->query(
        "SELECT
            fr.id,
            fr.user_id,
            fr.account_id,
            fr.amount,
            fr.fee,
            fr.currency,
            fr.gateway,
            fr.payment_method_id,
            fr.status,
            fr.reference,
            fr.notes,
            fr.screenshot_path,
            fr.created_at,
            fr.updated_at,
            u.first_name,
            u.last_name,
            u.email,
            pm.name AS payment_name
         FROM financial_requests fr
         JOIN users u ON u.id = fr.user_id
         LEFT JOIN payment_methods pm ON pm.id = fr.payment_method_id
         WHERE fr.type = 'deposit'
         ORDER BY fr.created_at DESC, fr.id DESC"
    );

    respond([
        'requests' => $q->fetchAll(),
    ]);
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond([
        'error' => 'Method not allowed.',
    ], 405);
}

require_csrf();

$isJson = str_contains(
    strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? '')),
    'application/json'
);

$body = $isJson
    ? (json_decode((string) file_get_contents('php://input'), true) ?: [])
    : $_POST;

$id = filter_var(
    $body['requestId'] ?? null,
    FILTER_VALIDATE_INT
);

$action = (string) ($body['action'] ?? '');

if (!$id || !in_array($action, ['approved', 'rejected'], true)) {
    respond([
        'error' => 'Invalid request.',
    ], 422);
}

try {
    $pdo->beginTransaction();

    /*
     * Lock the deposit request first.
     *
     * This is important for idempotency:
     * two simultaneous approval requests cannot both
     * process the same pending deposit.
     */
    $requestQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            account_id,
            amount,
            currency,
            status,
            reference
         FROM financial_requests
         WHERE id = :id
           AND type = 'deposit'
         FOR UPDATE"
    );

    $requestQuery->execute([
        'id' => $id,
    ]);

    $request = $requestQuery->fetch();

    if (!$request) {
        $pdo->rollBack();

        respond([
            'error' => 'Deposit not found.',
        ], 404);
    }

    /*
     * A deposit can only be processed once.
     */
    if ((string) $request['status'] !== 'pending') {
        $pdo->rollBack();

        respond([
            'error' => 'Deposit has already been processed.',
            'requestId' => (int) $request['id'],
            'status' => (string) $request['status'],
        ], 409);
    }

    /*
     * Rejection does not touch the wallet and does not
     * create a ledger transaction.
     */
    if ($action === 'rejected') {
        $update = $pdo->prepare(
            "UPDATE financial_requests
             SET status = 'rejected'
             WHERE id = :id
               AND status = 'pending'"
        );

        $update->execute([
            'id' => $id,
        ]);

        if ($update->rowCount() !== 1) {
            throw new RuntimeException(
                'Deposit could not be rejected.'
            );
        }

        $pdo->commit();

        notify_user_of_event(
            $pdo,
            $config,
            (int) $request['user_id'],
            'Deposit request rejected',
            'Your deposit request was rejected.',
            [
                'Reference' => (string) $request['reference'],
                'Amount' => number_format((float) $request['amount'], 2, '.', '') . ' ' . (string) $request['currency'],
                'Status' => 'Rejected',
            ]
        );

        if (!$isJson) {
            header(
                'Location: ' .
                (string) ($body['_admin_redirect'] ?? '/admin/deposits/')
            );
            exit;
        }

        respond([
            'message' => 'Deposit rejected.',
            'requestId' => (int) $request['id'],
            'status' => 'rejected',
        ]);
    }

    /*
     * APPROVAL
     *
     * Use the account_id already stored on the financial request.
     * This guarantees that the exact wallet associated with the
     * deposit request is credited.
     */
    $accountQuery = $pdo->prepare(
        "SELECT
            id,
            user_id,
            currency,
            wallet_type,
            available_balance
         FROM accounts
         WHERE id = :account_id
         FOR UPDATE"
    );

    $accountQuery->execute([
        'account_id' => (int) $request['account_id'],
    ]);

    $account = $accountQuery->fetch();

    if (!$account) {
        throw new RuntimeException(
            'The wallet associated with this deposit does not exist.'
        );
    }

    /*
     * Verify that the account belongs to the same user as the
     * financial request.
     */
    if ((int) $account['user_id'] !== (int) $request['user_id']) {
        throw new RuntimeException(
            'Deposit wallet does not belong to the requesting user.'
        );
    }

    /*
     * Make sure the currency on the request and wallet match.
     */
    if ((string) $account['currency'] !== (string) $request['currency']) {
        throw new RuntimeException(
            'Deposit currency does not match the wallet currency.'
        );
    }

    /*
     * Only the main wallet should receive deposits.
     */
    if ((string) $account['wallet_type'] !== 'main') {
        throw new RuntimeException(
            'Deposits can only be credited to the main wallet.'
        );
    }

    $amount = (float) $request['amount'];

    if ($amount <= 0) {
        throw new RuntimeException(
            'Deposit amount must be greater than zero.'
        );
    }

    /*
     * Credit the wallet.
     *
     * The account row is locked with FOR UPDATE, so concurrent
     * balance changes cannot overwrite each other.
     */
    $credit = $pdo->prepare(
        "UPDATE accounts
         SET available_balance = available_balance + :amount
         WHERE id = :account_id"
    );

    $credit->execute([
        'amount' => $amount,
        'account_id' => (int) $account['id'],
    ]);

    if ($credit->rowCount() !== 1) {
        throw new RuntimeException(
            'Wallet could not be credited.'
        );
    }

    /*
     * Record the completed deposit in the live ledger table.
     */
    $ledger = $pdo->prepare(
        "INSERT INTO ledger_transactions (
            user_id,
            account_id,
            type,
            amount,
            currency,
            status,
            description
         ) VALUES (
            :user_id,
            :account_id,
            :type,
            :amount,
            :currency,
            'completed',
            :description
         )"
    );

    $ledger->execute([
        'user_id' => (int) $request['user_id'],
        'account_id' => (int) $account['id'],
        'type' => 'deposit',
        'amount' => $amount,
        'currency' => (string) $request['currency'],
        'description' => 'Deposit approved - ' . (string) $request['reference'],
    ]);

    /*
     * Finally mark the financial request as approved.
     */
    $update = $pdo->prepare(
        "UPDATE financial_requests
         SET status = 'approved'
         WHERE id = :id
           AND status = 'pending'"
    );

    $update->execute([
        'id' => $id,
    ]);

    if ($update->rowCount() !== 1) {
        throw new RuntimeException(
            'Deposit status could not be updated.'
        );
    }

    /*
     * Everything succeeded:
     *
     * wallet credit
     * + ledger entry
     * + approved status
     *
     * are committed together.
     */
    $pdo->commit();

    notify_user_of_event(
        $pdo,
        $config,
        (int) $request['user_id'],
        'Deposit request approved',
        'Your deposit was approved and credited to your wallet.',
        [
            'Reference' => (string) $request['reference'],
            'Amount' => number_format($amount, 2, '.', '') . ' ' . (string) $request['currency'],
            'Status' => 'Approved',
        ]
    );

    if (!$isJson) {
        header(
            'Location: ' .
            (string) ($body['_admin_redirect'] ?? '/admin/deposits/')
        );
        exit;
    }

    respond([
        'message' => 'Deposit approved and wallet credited.',
        'requestId' => (int) $request['id'],
        'status' => 'approved',
        'amount' => number_format($amount, 2, '.', ''),
        'currency' => (string) $request['currency'],
    ]);

} catch (Throwable $e) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    error_log(
        'Admin deposit processing failed: ' .
        $e->getMessage()
    );

    if (!$isJson) {
        http_response_code(500);
        header(
            'Location: ' .
            (string) ($body['_admin_redirect'] ?? '/admin/deposits/')
        );
        exit;
    }

    respond([
        'error' => 'Deposit could not be processed.',
    ], 500);
}