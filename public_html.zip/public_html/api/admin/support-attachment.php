<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

require_admin();

$attachmentId = filter_input(
    INPUT_GET,
    'id',
    FILTER_VALIDATE_INT
);

if (!$attachmentId || $attachmentId <= 0) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Find the attachment and make sure its ticket exists.
 */
$query = $pdo->prepare("
    SELECT
        sta.id,
        sta.ticket_id,
        sta.original_name,
        sta.stored_name,
        sta.file_path,
        sta.mime_type,
        sta.file_size
    FROM support_ticket_attachments sta
    INNER JOIN support_tickets st
        ON st.id = sta.ticket_id
    WHERE sta.id = :attachment_id
    LIMIT 1
");

$query->execute([
    'attachment_id' => $attachmentId,
]);

$attachment = $query->fetch();

if (!$attachment) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Resolve the actual storage directory.
 */
$storageDirectory = realpath(
    __DIR__ . '/../../storage/uploads/support'
);

if ($storageDirectory === false) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Never trust the database value as a path.
 * Only use the basename of stored_name.
 */
$storedName = basename(
    (string) $attachment['stored_name']
);

if (
    $storedName === '' ||
    $storedName === '.' ||
    $storedName === '..'
) {
    http_response_code(404);
    exit('Attachment not found.');
}

$filePath =
    $storageDirectory .
    DIRECTORY_SEPARATOR .
    $storedName;

/*
 * Resolve the final file path.
 */
$realFilePath = realpath($filePath);

if ($realFilePath === false) {
    http_response_code(404);
    exit('Attachment not found.');
}

if (!is_file($realFilePath)) {
    http_response_code(404);
    exit('Attachment not found.');
}

if (!is_readable($realFilePath)) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Prevent path traversal outside the support
 * attachment directory.
 */
$storagePrefix =
    $storageDirectory .
    DIRECTORY_SEPARATOR;

if (!str_starts_with(
    $realFilePath,
    $storagePrefix
)) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Only serve MIME types that the upload system allows.
 */
$allowedMimeTypes = [
    'image/jpeg',
    'image/png',
    'image/gif',
    'image/webp',
];

$mimeType = (string) $attachment['mime_type'];

if (!in_array(
    $mimeType,
    $allowedMimeTypes,
    true
)) {
    http_response_code(403);
    exit('Attachment type not allowed.');
}

/*
 * Re-check the actual file contents before serving.
 */
$finfo = new finfo(FILEINFO_MIME_TYPE);

$actualMime = $finfo->file(
    $realFilePath
);

if (
    !is_string($actualMime) ||
    $actualMime !== $mimeType
) {
    http_response_code(403);
    exit('Attachment validation failed.');
}

$fileSize = filesize($realFilePath);

if ($fileSize === false) {
    http_response_code(404);
    exit('Attachment not found.');
}

/*
 * Prevent header injection through the original name.
 */
$downloadName = basename(
    (string) $attachment['original_name']
);

$downloadName = preg_replace(
    '/[\r\n"]/',
    '',
    $downloadName
);

if (!is_string($downloadName)) {
    $downloadName = '';
}

if ($downloadName === '') {
    $downloadName = 'attachment';
}

/*
 * Response headers.
 */
header(
    'Content-Type: ' . $mimeType
);

header(
    'Content-Length: ' .
    (string) $fileSize
);

header(
    'Content-Disposition: inline; filename="' .
    $downloadName .
    '"'
);

header(
    'X-Content-Type-Options: nosniff'
);

header(
    'Cache-Control: private, no-store, max-age=0'
);

header(
    'Pragma: no-cache'
);

readfile($realFilePath);

exit;