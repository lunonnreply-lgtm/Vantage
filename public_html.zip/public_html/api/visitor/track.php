<?php

declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_once __DIR__ . '/../../backend/src/mailer.php';

if (session_status() === PHP_SESSION_ACTIVE) {
    session_write_close();
}

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    respond(['error' => 'POST is required.'], 405);
}

$contentType = strtolower((string) ($_SERVER['CONTENT_TYPE'] ?? ''));
if (!str_contains($contentType, 'application/json')) {
    respond(['error' => 'JSON requests are required.'], 415);
}

$origin = trim((string) ($_SERVER['HTTP_ORIGIN'] ?? ''));
$originHost = $origin !== '' ? parse_url($origin, PHP_URL_HOST) : false;
$requestHost = parse_url('http://' . (string) ($_SERVER['HTTP_HOST'] ?? ''), PHP_URL_HOST);
if (
    !is_string($originHost)
    || !is_string($requestHost)
    || !hash_equals(strtolower($requestHost), strtolower($originHost))
) {
    respond(['error' => 'Same-origin requests are required.'], 403);
}

$input = json_input();
$rawVisitorId = $input['visitor_id'] ?? '';
if (!is_string($rawVisitorId) || !preg_match('/^[a-f0-9]{64}$/', $rawVisitorId)) {
    respond(['error' => 'Invalid visitor identifier.'], 422);
}

$visitorKey = hash('sha256', $rawVisitorId);
$userAgent = substr((string) ($_SERVER['HTTP_USER_AGENT'] ?? 'Unknown'), 0, 512);
$ipAddress = filter_var(
    $_SERVER['REMOTE_ADDR'] ?? '',
    FILTER_VALIDATE_IP
);
$ipAddress = is_string($ipAddress) ? $ipAddress : null;

function visitor_page_path(mixed $value): string
{
    if (!is_string($value) || $value === '') {
        return '/';
    }

    $parts = parse_url($value);
    $path = is_array($parts) && isset($parts['path'])
        ? (string) $parts['path']
        : '/';

    if ($path === '' || $path[0] !== '/') {
        $path = '/' . ltrim($path, '/');
    }

    return substr(preg_replace('/[\x00-\x1F\x7F]/', '', $path) ?: '/', 0, 2048);
}

function visitor_referrer(mixed $value): ?string
{
    if (!is_string($value) || $value === '') {
        return null;
    }

    $parts = parse_url($value);
    if (!is_array($parts)) {
        return null;
    }

    $host = isset($parts['host']) ? (string) $parts['host'] : '';
    if ($host !== '') {
        $scheme = isset($parts['scheme']) && in_array(strtolower((string) $parts['scheme']), ['http', 'https'], true)
            ? strtolower((string) $parts['scheme']) . '://'
            : '';
        $path = isset($parts['path']) ? (string) $parts['path'] : '/';
        $referrer = $scheme . $host . $path;
    } else {
        $referrer = isset($parts['path']) ? (string) $parts['path'] : '';
    }

    $referrer = preg_replace('/[\x00-\x1F\x7F]/', '', $referrer) ?: '';
    return $referrer !== '' ? substr($referrer, 0, 2048) : null;
}

function visitor_device(string $userAgent): string
{
    if (preg_match('/iPad|Tablet|Kindle|Silk/i', $userAgent)) {
        return 'Tablet';
    }
    if (preg_match('/Mobile|Android|iPhone|iPod/i', $userAgent)) {
        return 'Mobile';
    }
    return 'Desktop';
}

function visitor_operating_system(string $userAgent): string
{
    if (preg_match('/Windows NT/i', $userAgent)) {
        return 'Windows';
    }
    if (preg_match('/Android/i', $userAgent)) {
        return 'Android';
    }
    if (preg_match('/iPhone|iPad|iPod/i', $userAgent)) {
        return 'iOS';
    }
    if (preg_match('/CrOS/i', $userAgent)) {
        return 'Chrome OS';
    }
    if (preg_match('/Mac OS X|Macintosh/i', $userAgent)) {
        return 'macOS';
    }
    if (preg_match('/Linux/i', $userAgent)) {
        return 'Linux';
    }
    return 'Unknown';
}

function visitor_browser(string $userAgent): string
{
    if (preg_match('/Edg(?:e|ios|a)?\//i', $userAgent)) {
        return 'Microsoft Edge';
    }
    if (preg_match('/OPR\//i', $userAgent)) {
        return 'Opera';
    }
    if (preg_match('/SamsungBrowser\//i', $userAgent)) {
        return 'Samsung Internet';
    }
    if (preg_match('/Firefox\//i', $userAgent)) {
        return 'Firefox';
    }
    if (preg_match('/(?:Chrome|CriOS)\//i', $userAgent)) {
        return 'Google Chrome';
    }
    if (preg_match('/Safari\//i', $userAgent)) {
        return 'Safari';
    }
    if (preg_match('/MSIE|Trident\//i', $userAgent)) {
        return 'Internet Explorer';
    }
    return 'Unknown';
}

function visitor_notification_recipients(PDO $pdo, array $config): array
{
    $configuredEmail = trim((string) ($config['app']['visitor_notification_email'] ?? ''));
    if ($configuredEmail !== '' && filter_var($configuredEmail, FILTER_VALIDATE_EMAIL)) {
        return [['email' => $configuredEmail, 'name' => 'Site Administrator']];
    }

    $query = $pdo->query(
        "SELECT first_name, last_name, email
         FROM users
         WHERE role = 'admin' AND status = 'active'
         ORDER BY id"
    );

    $recipients = [];
    $seen = [];
    foreach ($query->fetchAll() as $admin) {
        $email = trim((string) $admin['email']);
        $emailKey = strtolower($email);
        if (!filter_var($email, FILTER_VALIDATE_EMAIL) || isset($seen[$emailKey])) {
            continue;
        }
        $seen[$emailKey] = true;
        $name = trim((string) $admin['first_name'] . ' ' . (string) $admin['last_name']);
        $recipients[] = [
            'email' => $email,
            'name' => $name !== '' ? $name : 'Administrator',
        ];
    }

    return $recipients;
}

$pagePath = visitor_page_path($input['page'] ?? '/');
$referrer = visitor_referrer($input['referrer'] ?? null);
$device = visitor_device($userAgent);
$browser = visitor_browser($userAgent);
$operatingSystem = visitor_operating_system($userAgent);
$cooldownMinutes = max(1, min(10080, (int) ($config['app']['visitor_notification_cooldown_minutes'] ?? 30)));
$pendingNotifications = [];

try {
    $pdo->beginTransaction();

    $insertVisitor = $pdo->prepare(
        'INSERT IGNORE INTO site_visitors (visitor_key, first_seen_at, last_seen_at)
         VALUES (:visitor_key, CURRENT_TIMESTAMP, CURRENT_TIMESTAMP)'
    );
    $insertVisitor->execute(['visitor_key' => $visitorKey]);
    $isNewVisitor = $insertVisitor->rowCount() === 1;

    $visitorQuery = $pdo->prepare(
        'SELECT id,
                (last_notification_at IS NULL OR TIMESTAMPDIFF(SECOND, last_notification_at, CURRENT_TIMESTAMP) >= :cooldown_seconds) AS cooldown_elapsed
         FROM site_visitors
         WHERE visitor_key = :visitor_key
         FOR UPDATE'
    );
    $visitorQuery->execute([
        'cooldown_seconds' => $cooldownMinutes * 60,
        'visitor_key' => $visitorKey,
    ]);
    $visitor = $visitorQuery->fetch();
    if (!$visitor) {
        throw new RuntimeException('Visitor record could not be loaded.');
    }

    $visitorId = (int) $visitor['id'];
    $updateVisitor = $pdo->prepare(
        'UPDATE site_visitors
         SET last_seen_at = CURRENT_TIMESTAMP,
             visit_count = visit_count + 1,
             latest_ip_address = :ip_address,
             latest_device = :device,
             latest_browser = :browser,
             latest_operating_system = :operating_system,
             latest_page_path = :page_path,
             latest_referrer = :referrer
         WHERE id = :id'
    );
    $updateVisitor->execute([
        'ip_address' => $ipAddress,
        'device' => $device,
        'browser' => $browser,
        'operating_system' => $operatingSystem,
        'page_path' => $pagePath,
        'referrer' => $referrer,
        'id' => $visitorId,
    ]);

    $insertVisit = $pdo->prepare(
        'INSERT INTO site_visitor_visits (
            visitor_id, ip_address, device, browser, operating_system,
            user_agent, page_path, referrer, visitor_status
         ) VALUES (
            :visitor_id, :ip_address, :device, :browser, :operating_system,
            :user_agent, :page_path, :referrer, :visitor_status
         )'
    );
    $insertVisit->execute([
        'visitor_id' => $visitorId,
        'ip_address' => $ipAddress,
        'device' => $device,
        'browser' => $browser,
        'operating_system' => $operatingSystem,
        'user_agent' => $userAgent,
        'page_path' => $pagePath,
        'referrer' => $referrer,
        'visitor_status' => $isNewVisitor ? 'new' : 'returning',
    ]);
    $visitId = (int) $pdo->lastInsertId();

    if ((int) $visitor['cooldown_elapsed'] === 1) {
        try {
            $recipients = visitor_notification_recipients($pdo, $config);
        } catch (Throwable $recipientException) {
            error_log('[visitor-notification] Recipient lookup failed: ' . $recipientException->getMessage());
            $recipients = [];
        }
        $pdo->prepare(
            'UPDATE site_visitors SET last_notification_at = CURRENT_TIMESTAMP WHERE id = :id'
        )->execute(['id' => $visitorId]);

        if (!$recipients) {
            $pdo->prepare(
                "INSERT INTO site_visitor_notifications (visitor_id, visit_id, recipient_email, status)
                 VALUES (:visitor_id, :visit_id, NULL, 'no_recipient')"
            )->execute([
                'visitor_id' => $visitorId,
                'visit_id' => $visitId,
            ]);
        } else {
            $notificationInsert = $pdo->prepare(
                "INSERT INTO site_visitor_notifications (visitor_id, visit_id, recipient_email, status)
                 VALUES (:visitor_id, :visit_id, :recipient_email, 'queued')"
            );
            foreach ($recipients as $recipient) {
                $notificationInsert->execute([
                    'visitor_id' => $visitorId,
                    'visit_id' => $visitId,
                    'recipient_email' => $recipient['email'],
                ]);
                $pendingNotifications[] = [
                    'id' => (int) $pdo->lastInsertId(),
                    'recipient' => $recipient,
                ];
            }
        }
    }

    $pdo->commit();
} catch (Throwable $exception) {
    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }
    error_log('[visitor-tracker] ' . $exception->getMessage());
    respond(['error' => 'Visit could not be recorded.'], 500);
}

$notificationDetails = [
    'Visitor type' => $isNewVisitor ? 'New visitor' : 'Returning visitor',
    'IP address' => $ipAddress ?? 'Unavailable',
    'Device' => $device,
    'Browser' => $browser,
    'Operating system' => $operatingSystem,
    'Page visited' => $pagePath,
    'Referrer' => $referrer ?? 'Direct visit',
    'Date and time (UTC)' => gmdate('Y-m-d H:i:s'),
];

$notificationUpdate = $pdo->prepare(
    'UPDATE site_visitor_notifications
     SET status = :status, error_message = :error_message, completed_at = CURRENT_TIMESTAMP
     WHERE id = :id'
);

foreach ($pendingNotifications as $pending) {
    try {
        send_notification_email(
            $config,
            (string) $pending['recipient']['email'],
            (string) $pending['recipient']['name'],
            'Website visitor: ' . ($isNewVisitor ? 'New visitor' : 'Returning visitor'),
            'A visitor viewed a page on Vantage Institutional.',
            $notificationDetails
        );
        $notificationUpdate->execute([
            'status' => 'sent',
            'error_message' => null,
            'id' => $pending['id'],
        ]);
    } catch (Throwable $exception) {
        error_log('[visitor-notification] ' . $exception->getMessage());
        $notificationUpdate->execute([
            'status' => 'failed',
            'error_message' => substr($exception->getMessage(), 0, 2000),
            'id' => $pending['id'],
        ]);
    }
}

respond(['recorded' => true]);
