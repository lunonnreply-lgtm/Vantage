<?php
declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';
require_once __DIR__ . '/../../backend/src/notifications.php';
require_csrf();

$input = json_input();

$required = ['firstName', 'lastName', 'email', 'username', 'country', 'password', 'confirmPassword'];

foreach ($required as $field) {
    if (!isset($input[$field]) || !is_string($input[$field]) || trim($input[$field]) === '') {
        respond(['error' => 'All registration fields are required.'], 422);
    }
}

$email = strtolower(trim($input['email']));
$username = trim($input['username']);
$password = $input['password'];

$referralCode = isset($input['ref']) && is_string($input['ref'])
    ? trim($input['ref'])
    : '';

if (
    !filter_var($email, FILTER_VALIDATE_EMAIL)
    || strlen($email) > 255
    || !preg_match('/^[A-Za-z0-9_.-]{3,50}$/', $username)
    || strlen(trim($input['firstName'])) > 100
    || strlen(trim($input['lastName'])) > 100
    || strlen(trim($input['country'])) > 100
) {
    respond(['error' => 'Enter a valid email and username.'], 422);
}

if (strlen($password) < 6 || !hash_equals($password, $input['confirmPassword'])) {
    respond(['error' => 'Passwords must match and contain at least 6 characters.'], 422);
}

$check = $pdo->prepare(
    'SELECT id FROM users
     WHERE email = :email OR username = :username
     LIMIT 1'
);
$check->execute([
    'email' => $email,
    'username' => $username,
]);

if ($check->fetch()) {
    respond(['error' => 'That email or username is already registered.'], 409);
}

$referrerId = null;
$referrer = null;

if ($referralCode !== '') {
    $referrerQuery = $pdo->prepare(
        'SELECT id, first_name, last_name, email FROM users
         WHERE referral_code = :referral_code
         AND status = :status
         LIMIT 1'
    );

    $referrerQuery->execute([
        'referral_code' => $referralCode,
        'status' => 'active',
    ]);

    $referrer = $referrerQuery->fetch() ?: null;
    $referrerId = $referrer !== null ? (int)$referrer['id'] : null;
}

try {
    $pdo->beginTransaction();

    $insert = $pdo->prepare(
        'INSERT INTO users
            (first_name, last_name, email, username, country, password_hash, referral_code, rank_id)
         VALUES
            (:first_name, :last_name, :email, :username, :country, :password_hash, :referral_code, :rank_id)'
    );

    $insert->execute([
        'first_name' => trim($input['firstName']),
        'last_name' => trim($input['lastName']),
        'email' => $email,
        'username' => $username,
        'country' => trim($input['country']),
        'password_hash' => password_hash($password, PASSWORD_DEFAULT),
        'referral_code' => '',
        'rank_id' => 1,
    ]);

    $newUserId = (int) $pdo->lastInsertId();

    $newReferralCode = 'VC' . str_pad((string) $newUserId, 8, '0', STR_PAD_LEFT);

    $updateReferralCode = $pdo->prepare(
        'UPDATE users
         SET referral_code = :referral_code
         WHERE id = :id'
    );

    $updateReferralCode->execute([
        'referral_code' => $newReferralCode,
        'id' => $newUserId,
    ]);

    $account = $pdo->prepare(
        'INSERT INTO accounts (user_id, wallet_type)
         VALUES (:user_id, :wallet_type)'
    );

    $account->execute([
        'user_id' => $newUserId,
        'wallet_type' => 'main',
    ]);

    $account->execute([
        'user_id' => $newUserId,
        'wallet_type' => 'profit',
    ]);

    if ($referrerId !== null && $referrerId !== $newUserId) {
        $referralInsert = $pdo->prepare(
            'INSERT INTO referrals (referrer_user_id, referred_user_id)
             VALUES (:referrer_user_id, :referred_user_id)'
        );

        $referralInsert->execute([
            'referrer_user_id' => $referrerId,
            'referred_user_id' => $newUserId,
        ]);
    }

    $pdo->commit();

    $newUserName = trim(trim($input['firstName']) . ' ' . trim($input['lastName']));
    send_email_best_effort(
        $config,
        $email,
        $newUserName,
        'Welcome to Vantage Institutional',
        'Your account has been created successfully. You can now sign in and access your dashboard.',
        ['Username' => $username, 'Referral code' => $newReferralCode]
    );

    if ($referrer !== null && $referrerId !== $newUserId) {
        $referrerName = trim((string)$referrer['first_name'] . ' ' . (string)$referrer['last_name']);
        send_email_best_effort(
            $config,
            (string)$referrer['email'],
            $referrerName,
            'Someone joined using your referral link',
            'A new user registered using your referral link.',
            ['Referred user' => $newUserName, 'Username' => $username]
        );
    }

} catch (PDOException $exception) {

    if ($pdo->inTransaction()) {
        $pdo->rollBack();
    }

    if ((int) ($exception->errorInfo[1] ?? 0) === 1062) {
        respond(['error' => 'That email or username is already registered.'], 409);
    }

    respond(['error' => 'The account could not be created.'], 500);
}

respond([
    'message' => 'Your account has been created.',
], 201);
