<?php
declare(strict_types=1);
require __DIR__ . '/../../../backend/src/bootstrap.php';
require_admin();

$adminId = (int)($_SESSION['user_id'] ?? 0);
$adminName = 'Administrator';
if ($adminId > 0) {
    $q = $pdo->prepare('SELECT first_name, last_name, email FROM users WHERE id = :id LIMIT 1');
    $q->execute(['id' => $adminId]);
    $admin = $q->fetch() ?: [];
    $adminName = trim(($admin['first_name'] ?? '') . ' ' . ($admin['last_name'] ?? '')) ?: ($admin['email'] ?? 'Administrator');
}
$pageTitle = 'Ticket Conversation';
$pageEyebrow = 'Support';
require __DIR__ . '/../../includes/header.php';
?>
<section class="admin-card ticket-detail-card">
    <div class="panel-heading">
        <div><span class="eyebrow">Client conversation</span><h2 id="ticket-subject">Loading ticket...</h2><p id="ticket-meta"></p></div>
        <a class="admin-button secondary" href="/admin/support/">Back to Inbox</a>
    </div>
    <div class="ticket-detail-info">
        <div><span>Reference</span><strong id="ticket-reference">—</strong></div>
        <div><span>Client</span><strong id="ticket-client">—</strong></div>
        <div><span>Email</span><strong id="ticket-email">—</strong></div>
        <div><span>Category</span><strong id="ticket-category">—</strong></div>
        <div><span>Status</span><select id="ticket-status"><option value="open">Open</option><option value="in_progress">In progress</option><option value="resolved">Resolved</option><option value="closed">Closed</option></select></div>
    </div>
    <div class="ticket-conversation" id="ticket-conversation"><div class="ticket-loading">Loading conversation...</div></div>
    <div class="ticket-reply-box">
        <textarea id="ticket-reply" maxlength="5000" placeholder="Write a reply to the client..."></textarea>
        <div class="ticket-reply-actions"><span>Maximum 5000 characters</span><button class="admin-button" id="send-reply" type="button">Send Reply</button></div>
    </div>
</section>
<script>window.__ADMIN_USER_ID = <?= $adminId ?>;</script>
<script>
const ticketId = new URLSearchParams(location.search).get('id');
const esc = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
async function csrf(){const r=await fetch('/api/auth/csrf.php',{credentials:'include'});const d=await r.json();if(!r.ok)throw Error(d.error||'CSRF request failed.');return d.csrfToken;}
async function load(){
 if(!ticketId) throw Error('Invalid ticket.');
 const r=await fetch('/api/admin/support-ticket.php?id='+encodeURIComponent(ticketId),{credentials:'include'}); const d=await r.json(); if(!r.ok)throw Error(d.error||'Unable to load ticket.');
 const t=d.ticket; document.getElementById('ticket-subject').textContent=t.subject||'Support ticket'; document.getElementById('ticket-meta').textContent='Created '+t.created_at+' · Updated '+t.updated_at; document.getElementById('ticket-reference').textContent=t.reference||('#'+t.id); document.getElementById('ticket-client').textContent=((t.first_name||'')+' '+(t.last_name||'')).trim()||'—'; document.getElementById('ticket-email').textContent=t.email||'—'; document.getElementById('ticket-category').textContent=t.category||'—'; document.getElementById('ticket-status').value=t.status||'open';
 const adminId=Number(window.__ADMIN_USER_ID||-1); const box=document.getElementById('ticket-conversation'); const msgs=d.messages||[]; box.innerHTML=msgs.length?msgs.map(m=>{const mine=Number(m.author_user_id)===adminId;const name=((m.first_name||'')+' '+(m.last_name||'')).trim()||m.email||'Unknown';return `<div class="ticket-message ${mine?'admin-message':'client-message'}"><div class="ticket-message-header"><strong>${esc(name)}</strong><span>${esc(m.created_at)}</span></div><div class="ticket-message-body">${esc(m.message).replace(/\n/g,'<br>')}</div></div>`}).join(''):'<div class="ticket-empty">No messages yet.</div>'; box.scrollTop=box.scrollHeight;
}
async function update(body){const token=await csrf();const r=await fetch('/api/admin/support-tickets.php',{method:'POST',credentials:'include',headers:{'Content-Type':'application/json','X-CSRF-Token':token},body:JSON.stringify({...body,ticketId:Number(ticketId)})});const d=await r.json();if(!r.ok)throw Error(d.error||'Update failed.');await load();}
document.getElementById('ticket-status').addEventListener('change',e=>update({status:e.target.value}).catch(alert));
document.getElementById('send-reply').addEventListener('click',async()=>{const el=document.getElementById('ticket-reply');const message=el.value.trim();if(!message)return alert('Write a reply first.');const b=document.getElementById('send-reply');b.disabled=true;try{await update({message});el.value='';}catch(e){alert(e.message)}finally{b.disabled=false}});
load().catch(e=>document.getElementById('ticket-conversation').innerHTML='<div class="ticket-error">'+esc(e.message)+'</div>');
</script>
<?php require __DIR__ . '/../../includes/footer.php'; ?>
