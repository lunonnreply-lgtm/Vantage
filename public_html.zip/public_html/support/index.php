<?php
declare(strict_types=1);
require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();

$adminName = 'Administrator';
$adminId = (int)($_SESSION['user_id'] ?? 0);
if ($adminId > 0) {
    $q = $pdo->prepare('SELECT first_name, last_name, email FROM users WHERE id = :id LIMIT 1');
    $q->execute(['id' => $adminId]);
    $admin = $q->fetch() ?: [];
    $adminName = trim(($admin['first_name'] ?? '') . ' ' . ($admin['last_name'] ?? '')) ?: ($admin['email'] ?? 'Administrator');
}
$pageTitle = 'Support Centre';
$pageEyebrow = 'Operations';
$adminFooterScripts = ['/admin/admin-support.js'];
require __DIR__ . '/../includes/header.php';
?>
<section class="admin-card support-page">
    <div class="panel-heading">
        <div>
            <span class="eyebrow">Client service</span>
            <h2>Support inbox</h2>
            <p>Review client tickets and open each conversation.</p>
        </div>
    </div>
    <div id="support-inbox" class="ticket-loading">Loading support tickets...</div>
</section>
<script>
window.__ADMIN_USER_ID = <?= (int)$adminId ?>;
(async function () {
    const root = document.getElementById('support-inbox');
    const esc = v => String(v ?? '').replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#039;');
    try {
        const r = await fetch('/api/admin/support-tickets.php', {credentials:'include'});
        const data = await r.json();
        if (!r.ok) throw new Error(data.error || 'Unable to load tickets.');
        const tickets = data.tickets || [];
        if (!tickets.length) { root.innerHTML = '<div class="ticket-empty">No support tickets found.</div>'; return; }
        root.innerHTML = `<div class="support-table-wrap"><table class="support-table"><thead><tr><th>Ticket</th><th>Subject</th><th>Client</th><th>Category</th><th>Status</th><th>Updated</th><th></th></tr></thead><tbody>${tickets.map(t => `<tr><td>${esc(t.reference || ('#'+t.id))}</td><td>${esc(t.subject)}</td><td>${esc(((t.first_name||'')+' '+(t.last_name||'')).trim() || t.email)}</td><td>${esc(t.category)}</td><td><span class="status-badge status-${esc(t.status)}">${esc(t.status)}</span></td><td>${esc(t.updated_at || t.created_at)}</td><td><a class="admin-button" href="/admin/support/view/?id=${encodeURIComponent(t.id)}">Open</a></td></tr>`).join('')}</tbody></table></div>`;
    } catch (e) { root.innerHTML = `<div class="ticket-error">${esc(e.message)}</div>`; }
})();
</script>
<?php require __DIR__ . '/../includes/footer.php'; ?>
