<?php
require __DIR__ . '/../../backend/src/bootstrap.php';
require_admin();
$userId = (int)($_SESSION['user_id'] ?? 0);
$adminQuery = $pdo->prepare('SELECT first_name,last_name,email FROM users WHERE id=:id LIMIT 1');
$adminQuery->execute(['id'=>$userId]);
$admin = $adminQuery->fetch() ?: [];
$adminName = trim((string)($admin['first_name'] ?? '').' '.(string)($admin['last_name'] ?? '')) ?: 'Administrator';

$pageTitle='Deposits'; $pageEyebrow='Financial Operations'; $adminFooterScripts=[];
require __DIR__.'/../../includes/header.php';
?>
<section class="admin-card management-card"><div class="panel-heading"><div><span class="eyebrow">Operations</span><h2>Deposits</h2><p>Review client deposit requests. Approvals should only be used after verifying the payment evidence.</p></div><a class="admin-action secondary" href="/admin/payments/">Payment methods</a></div><div id="notice" class="notice" hidden></div><div class="table-scroll"><table class="data-table"><thead><tr><th>ID</th><th>Client</th><th>Amount</th><th>Method</th><th>Status</th><th>Created</th><th>Action</th></tr></thead><tbody id="rows"><tr><td colspan="7">Loading…</td></tr></tbody></table></div></section>
<script>
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#039;'}[c]));
async function load(){const r=await fetch('/api/admin/deposits.php',{credentials:'same-origin'});const d=await r.json();if(!r.ok)throw Error(d.error||'Failed');document.querySelector('#rows').innerHTML=(d.items||[]).map(x=>`<tr><td>${esc(x.id)}</td><td>${esc(x.client)}</td><td>${esc(x.amount)}</td><td>${esc(x.method)}</td><td>${esc(x.status)}</td><td>${esc(x.created_at)}</td><td><select onchange="act(${x.id},this.value)"><option value="">Action</option><option value="approved">Approve</option><option value="rejected">Reject</option><option value="pending">Set pending</option></select></td></tr>`).join('')||'<tr><td colspan="7">No deposit records found.</td></tr>';}
async function act(id,status){if(!status)return;if(!confirm('Change this deposit status to '+status+'?'))return;const r=await fetch('/api/admin/deposits.php',{method:'POST',credentials:'same-origin',headers:{'Content-Type':'application/json','X-CSRF-Token':await csrf()},body:JSON.stringify({id,status})});const d=await r.json();if(!r.ok)alert(d.error||'Update failed');else load();}
async function csrf(){const r=await fetch('/api/auth/csrf',{credentials:'same-origin'});const d=await r.json();return d.token||d.csrfToken||'';}
load().catch(e=>document.querySelector('#rows').innerHTML='<tr><td colspan="7">'+esc(e.message)+'</td></tr>');
</script>
<?php require __DIR__.'/../../includes/footer.php'; ?>
