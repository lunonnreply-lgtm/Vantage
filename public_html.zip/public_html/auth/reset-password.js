const apiRoot = "../../api/auth";

async function requestJson(path, options = {}) {
  const response = await fetch(`${apiRoot}/${path}`, {
    credentials: "include",
    headers: {
      "Content-Type": "application/json",
      ...(options.headers || {})
    },
    ...options,
  });

  const payload = await response.json().catch(() => ({}));

  if (!response.ok) {
    throw new Error(
      payload.error || "The account service returned an error."
    );
  }

  return payload;
}

function showMessage(form, text, isError = false) {
  const message = form.querySelector(".auth-message");
  if (!message) return;

  message.textContent = text;
  message.classList.toggle("error", isError);
  message.classList.add("visible");
}

const form = document.getElementById("reset-form");

if (form) {
  form.addEventListener("submit", async (event) => {
    event.preventDefault();

    const submit = form.querySelector('button[type="submit"]');

    if (submit) {
      submit.disabled = true;
    }

    try {
      const token = new URLSearchParams(window.location.search).get("token");

      if (!token) {
        throw new Error("Invalid or missing password reset link.");
      }

      const password = document.getElementById("password").value;
      const confirmPassword = document.getElementById("confirm-password").value;

      if (password !== confirmPassword) {
        throw new Error("Passwords do not match.");
      }

      const { csrfToken } = await requestJson("csrf.php");

      const result = await requestJson("reset-password.php", {
        method: "POST",
        headers: {
          "X-CSRF-Token": csrfToken
        },
        body: JSON.stringify({
          token,
          password,
          confirmPassword
        }),
      });

      showMessage(
        form,
        result.message || "Your password has been reset successfully."
      );

      form.reset();

      window.setTimeout(() => {
        window.location.assign("../login/");
      }, 1200);

    } catch (error) {
      showMessage(form, error.message, true);
    } finally {
      if (submit) {
        submit.disabled = false;
      }
    }
  });
}
