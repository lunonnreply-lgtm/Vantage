<?php
declare(strict_types=1);

require __DIR__ . '/../../backend/src/bootstrap.php';

$token = isset($_GET['token']) && is_string($_GET['token'])
    ? trim($_GET['token'])
    : '';

$validToken = false;

if (preg_match('/^[a-f0-9]{64}$/i', $token)) {
    $query = $pdo->prepare(
        'SELECT id
         FROM password_reset_tokens
         WHERE token_hash = :token_hash
           AND used_at IS NULL
           AND expires_at > NOW()
         LIMIT 1'
    );

    $query->execute([
        'token_hash' => hash('sha256', $token),
    ]);

    $validToken = (bool) $query->fetchColumn();
}
?>
<!doctype html>
<html lang="en-GB">
  <head>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1" />
    <title>Reset Password | Vantage Institutional</title>
    <link rel="icon" type="image/svg+xml" href="/assets/branding/favicon.svg" />
    <link rel="icon" type="image/png" sizes="48x48" href="/assets/branding/favicon-48.png" />
    <link rel="icon" type="image/png" sizes="32x32" href="/assets/branding/favicon-32.png" />
    <link rel="icon" type="image/png" sizes="16x16" href="/assets/branding/favicon-16.png" />
    <link rel="shortcut icon" href="/assets/branding/favicon.ico" />
    <link rel="apple-touch-icon" sizes="180x180" href="/assets/branding/apple-touch-icon.png" />
    <link rel="manifest" href="/assets/branding/site.webmanifest" />
    <meta name="msapplication-TileImage" content="/assets/branding/mstile-270.png" />
    <meta name="msapplication-config" content="/browserconfig.xml" />
    <meta name="msapplication-TileColor" content="#0B1F3A" />
    <meta name="theme-color" content="#0B1F3A" />
    <link rel="stylesheet" href="../auth.css" />
    <link rel="stylesheet" href="../../assets/css/site-navigation.css?v=20260926-04">
  </head>

  <body>
    <main class="auth-shell">
      <a class="auth-brand" href="../../">Vantage Institutional</a>

      <section class="auth-card">
        <?php if (!$validToken): ?>

          <h1>Invalid or expired link</h1>

          <p>
            This password reset link is invalid or has expired.
            Please request a new password reset link.
          </p>

          <div class="auth-links">
            <a href="../forgot-password/">Request a new reset link</a>
            <a href="../login/">Back to login</a>
          </div>

        <?php else: ?>

          <h1>Reset your password</h1>

          <p>Choose a new password for your account.</p>

          <form id="reset-form">
            <div class="field">
              <label for="password">New password</label>
              <input
                id="password"
                name="password"
                type="password"
                minlength="6"
                maxlength="200"
                required
                autocomplete="new-password"
              />
            </div>

            <div class="field">
              <label for="confirm-password">Confirm new password</label>
              <input
                id="confirm-password"
                name="confirmPassword"
                type="password"
                minlength="6"
                maxlength="200"
                required
                autocomplete="new-password"
              />
            </div>

            <button class="button" type="submit">
              Reset password
            </button>

            <p class="auth-message" role="status"></p>
          </form>

          <div class="auth-links">
            <a href="../login/">Back to login</a>
          </div>

        <?php endif; ?>
      </section>
    </main>

    <?php if ($validToken): ?>
      <script src="../reset-password.js"></script>
    <?php endif; ?>

    <script src="../../assets/js/site-navigation.js"></script>
    <script src="/assets/global/js/visitor-tracker.js" defer></script>
  </body>
</html>